"use client";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export default function ActivityChart({ data }: { data: { day: string; Teaching: number; Learning: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} barGap={4}>
                                <CartesianGrid vertical={false} stroke="#e6e8f0" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: "#585f78", fontSize: 12 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: "#585f78", fontSize: 12 }} allowDecimals={false} width={28} />
                <Tooltip cursor={{ fill: "rgba(35,53,84,0.05)" }} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 8px 24px rgba(35,53,84,.15)" }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="Teaching" fill="#1f2547" radius={[6, 6, 0, 0]} maxBarSize={22} animationDuration={900} />
                <Bar dataKey="Learning" fill="#7b68f0" radius={[6, 6, 0, 0]} maxBarSize={22} animationDuration={900} />
              </BarChart>
            </ResponsiveContainer>
  );
}
