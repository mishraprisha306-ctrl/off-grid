# PeerUp, Peer Learning with Rating (P23)

A peer-to-peer skill-exchange platform for students across colleges, fields and years: teach what you know, learn what you don't, get matched both ways, book sessions, rate completed sessions, and build a transparent trust score.

Live demo: https://pwr-peer-learning.vercel.app

## Features

| Area | What works |
|---|---|
| Opening & public site | Animated logo opening shot (once per visit, skippable, off for reduced motion), landing page, About, Contact form, FAQ, Privacy, Terms, Community & Safety guidelines |
| Auth | Email + password sign-in/sign-up (password strength, confirmation, terms & privacy consent, duplicate-account check), forgot password, Google OAuth, email verification. Google, verification and reset emails need Supabase (see below). |
| Onboarding & profiles | 5-step onboarding with photo upload, academics, interests, per-skill levels (never inferred from year), mode, session types, availability; privacy controls; portfolio links; certificates labelled *self-reported / evidence attached / verified by admin* |
| Discovery | Explore skill cards and students with search and filters (field, college, branch, year, level, rating, online/offline, session type, mentors) and sorting |
| Matching | Mutual match only when both directions match; one-way opportunities listed separately; match % = 50 × share of your wishes they cover + 50 × share of theirs you cover; skill-name normalisation; plain-English explanation |
| Connections | Send, accept, reject, cancel, remove, block/unblock; duplicates prevented |
| Senior Mentors | Transparent eligibility (year or proven experience + completed sessions + rating from enough reviews + no open reports), admin approval/rejection, mentor categories, availability, mentorship-specific ratings. Separate from trust score. |
| Sessions | Request (skill, date, time, duration, Online/Offline, One-to-One/Group, objective, message), accept, reject, cancel, reschedule (back to Pending), clash detection, expiry of stale requests, 1-hour reminders, live/“starts in” states, calendar, learning room (notes, external meeting link or location, shared resources) |
| Completion | Both teacher and learner must confirm after the start time; stops fake completions |
| Ratings | Learner-only, once per session, no self-rating; overall stars + 4 categories + qualities; edit within 7 days; helpful votes; report; skill-wise averages (need 2+ reviews); distribution; learner feedback kept private and separate |
| Trust & leaderboard | Trust 0–100 = rating 50 + sessions 20 (log scale) + consistency 15 + reliability 15, with evidence thresholds; new users shown as “building trust”. Leaderboard: 5 categories × week/month/overall × skill/field/branch/college, deterministic tie-breaks |
| Community | Messaging with connection/privacy rules, blocking, unread counts, rate-limit, reports; notification bell, history, preferences |
| Learning | Progress tracker with milestones, resources library (with permission confirmation), 7-day challenges, achievements from real activity, skill recommendations |
| Admin | Overview, users (suspend/restore), reports & moderation (remove reviews/messages), mentor review, certificate verification, skill categories, session monitor, analytics, support inbox, platform settings, audit log |

## Tech stack
Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS v4 · Framer Motion · Recharts · Lucide · Supabase (Auth, Postgres, Storage)

## Run locally
```bash
npm install
npm run dev        # http://localhost:5930
npm run build && npm start
```
Without env vars the app runs in **demo mode**. All data is stored in the browser (localStorage) and seeded with **clearly labelled sample profiles**. Every sample account uses the password `demo1234`:
- Student: `rahul.sharma@kiit.edu.in` (or click “Try the demo instantly”)
- Admin: `admin@peerup.edu`
- Settings → Account → Demo tools lets you switch accounts or reset the data.

## Supabase setup (real auth + database)
1. Create a project at supabase.com.
2. SQL Editor → run `supabase/schema.sql`. It creates every table, constraint, index, trigger (session transitions, rating eligibility, protected role columns), Row Level Security policy, reputation view and storage bucket.
3. Copy `.env.example` → `.env.local` and fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Auth → URL configuration: Site URL = your domain; add redirect URLs `https://your-domain/auth/callback` and `https://your-domain/auth/reset`.
5. Auth → Providers → Google: enable it and paste the OAuth client ID and secret from Google Cloud (authorised redirect `https://<project>.supabase.co/auth/v1/callback`).
6. Make yourself admin: `update profiles set role = 'admin' where email = 'you@…';`

With keys set, sign-up, sign-in, Google, email verification and password reset run through Supabase Auth.

## Deploy (Vercel)
Push to GitHub → import the repo in Vercel → add the two env vars → deploy. Add the Vercel URL to the Supabase redirect URLs.

## Known limitations
- **Data layer:** in demo mode every feature persists in localStorage, so data is per-browser. `supabase/schema.sql` mirrors the data model table for table with RLS, and auth is wired to Supabase, but the feature data calls (sessions, messages and so on) still go through the local `repo` in `lib/store.tsx`. Moving them to Supabase queries is the next step and has not been done or tested against a live project.
- Video calls aren't built in. Online sessions use an external meeting link, and the UI says so.
- Contact/support messages land in the admin inbox. Sending email needs an email provider.
- In demo mode, uploaded photos and certificates are compressed and stored in the browser (certificates up to about 300 KB). Supabase Storage buckets are defined in the schema.
- Legal pages are templates and need review before a public launch.
