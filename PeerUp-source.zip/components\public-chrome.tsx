"use client";
import { Menu, X } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { Logo } from "./logo";
import { Button } from "./ui";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/#how", label: "How It Works" },
  { href: "/explore", label: "Explore Skills" },
  { href: "/mentors", label: "Senior Mentors" },
  { href: "/leaderboard", label: "Leaderboard" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function PublicNav() {
  const { me } = useStore();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-white/60 bg-white/75">
      <div className="mx-auto flex h-[4.25rem] max-w-7xl items-center gap-6 px-5 sm:px-8">
        <Logo href="/" />
        <nav className="ml-4 hidden items-center gap-1 lg:flex" aria-label="Public">
          {LINKS.map((l) => <Link key={l.href} href={l.href} className="rounded-lg px-3 py-2 text-sm font-semibold text-subtle hover:text-navy">{l.label}</Link>)}
        </nav>
        <div className="ml-auto hidden items-center gap-2 sm:flex">
          {me ? (
            <Button href={me.role === "admin" ? "/admin" : "/dashboard"}>Open dashboard</Button>
          ) : (
            <>
              <Button href="/login" variant="ghost">Sign In</Button>
              <Button href="/signup" variant="accent">Get Started</Button>
            </>
          )}
        </div>
        <button className="ml-auto rounded-xl p-2 lg:hidden sm:ml-2" onClick={() => setOpen(!open)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {open && (
        <nav className="border-t border-line bg-ivory px-5 pt-2 pb-5 lg:hidden" aria-label="Public mobile">
          {LINKS.map((l) => <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="block rounded-lg px-2 py-3 font-semibold text-ink">{l.label}</Link>)}
          <div className="mt-3 grid grid-cols-2 gap-2">
            {me ? <Button href="/dashboard" className="col-span-2">Open dashboard</Button> : <><Button href="/login" variant="secondary">Sign In</Button><Button href="/signup" variant="accent">Get Started</Button></>}
          </div>
        </nav>
      )}
    </header>
  );
}

export function PublicFooter() {
  const cols = [
    { t: "Product", l: [["How It Works", "/#how"], ["Explore Skills", "/explore"], ["Senior Mentors", "/mentors"], ["Leaderboard", "/leaderboard"]] },
    { t: "Company", l: [["About Us", "/about"], ["Contact Us", "/contact"], ["Help Center", "/faq"]] },
    { t: "Trust & Safety", l: [["Community Guidelines", "/guidelines"], ["Safety Guidelines", "/safety"], ["Privacy Policy", "/privacy"], ["Terms & Conditions", "/terms"]] },
  ];
  return (
    <footer className="mt-24 bg-navy text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo href="/" light />
          <p className="mt-4 max-w-xs text-sm text-white/70">Peer learning with honest ratings. Teach what you know, learn what you don't, and build a reputation that's earned.</p>
        </div>
        {cols.map((c) => (
          <div key={c.t}>
            <p className="text-xs font-bold tracking-[0.14em] text-white/60 uppercase">{c.t}</p>
            <ul className="mt-3 space-y-2">{c.l.map(([label, href]) => <li key={href}><Link href={href} className="text-sm text-white/85 hover:text-white">{label}</Link></li>)}</ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/60">© {new Date().getFullYear()} PeerUp · Peer Learning with Rating. All rights reserved.</div>
    </footer>
  );
}

export function PublicPage({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-5 pt-14 sm:px-8">
      <h1 className="text-3xl font-extrabold tracking-tight text-navy sm:text-4xl">{title}</h1>
      {subtitle && <p className="mt-3 text-lg text-subtle">{subtitle}</p>}
      <div className="prose-pr mt-10 space-y-8 text-[0.98rem] leading-relaxed text-ink">{children}</div>
    </div>
  );
}
