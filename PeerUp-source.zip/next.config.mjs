export default { reactStrictMode: true };
