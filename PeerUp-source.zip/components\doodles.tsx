/** Hand-drawn baby-pink arrow motifs, solid strokes with a soft glow, purely decorative. */
const glow = { filter: "drop-shadow(0 0 6px rgb(246 201 204 / .95))" };

export function LoopArrow({ className, color = "#eeb4b6" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 160 90" fill="none" className={className} style={glow} aria-hidden>
      <path d="M6 70c22-6 40-22 46-40 4-14-8-22-16-12-9 11 4 32 28 38 26 7 52-4 70-26" stroke={color} strokeWidth="3.2" strokeLinecap="round" />
      <path d="m124 22 12 8-2 14" stroke={color} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function CurveArrow({ className, color = "#eeb4b6" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 120 60" fill="none" className={className} style={glow} aria-hidden>
      <path d="M4 50C30 8 78 2 108 22" stroke={color} strokeWidth="3" strokeLinecap="round" strokeDasharray="1 8" />
      <path d="m98 12 12 10-14 6" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Sparkle({ className, color = "#f3c0c2" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={glow} aria-hidden>
      <path d="M12 1.5c.8 5.6 2.9 7.7 8.5 8.5-5.6.8-7.7 2.9-8.5 8.5-.8-5.6-2.9-7.7-8.5-8.5 5.6-.8 7.7-2.9 8.5-8.5Z" fill={color} />
    </svg>
  );
}
