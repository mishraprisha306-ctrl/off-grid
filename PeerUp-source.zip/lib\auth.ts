"use client";
import type { SupabaseClient } from "@supabase/supabase-js";

/**
 * Supabase Auth adapter. Active only when NEXT_PUBLIC_SUPABASE_URL and
 * NEXT_PUBLIC_SUPABASE_ANON_KEY are set; otherwise the app runs in local demo mode.
 * Only the public anon key is ever used in the browser, never the service-role key.
 */
const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL;
const KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
export const isSupabaseConfigured = !!(URL_ && KEY);

let client: SupabaseClient | null = null;
/** Loaded lazily so demo mode never downloads the Supabase client. */
export async function supabase() {
  if (!isSupabaseConfigured) return null;
  if (!client) {
    const { createClient } = await import("@supabase/supabase-js");
    client = createClient(URL_!, KEY!, { auth: { persistSession: true, autoRefreshToken: true } });
  }
  return client;
}

export interface AuthUser { id: string; email: string; name?: string; avatar?: string; emailVerified: boolean }
type R<T = object> = ({ ok: true } & T) | { ok: false; error: string };

const toUser = (u: { id: string; email?: string; email_confirmed_at?: string | null; user_metadata?: Record<string, string> }): AuthUser => ({
  id: u.id,
  email: u.email ?? "",
  name: u.user_metadata?.full_name || u.user_metadata?.name,
  avatar: u.user_metadata?.avatar_url,
  emailVerified: !!u.email_confirmed_at,
});
const origin = () => (typeof window !== "undefined" ? window.location.origin : "");

export const auth = {
  async currentUser(): Promise<AuthUser | null> {
    const sb = await supabase();
    if (!sb) return null;
    const { data } = await sb.auth.getUser();
    return data.user ? toUser(data.user) : null;
  },
  async signIn(email: string, password: string): Promise<R<{ user: AuthUser }>> {
    const { data, error } = await (await supabase())!.auth.signInWithPassword({ email, password });
    if (error) return { ok: false, error: error.message === "Email not confirmed" ? "Verify your email first. Check your inbox for the link." : "Invalid email or password." };
    return { ok: true, user: toUser(data.user) };
  },
  async signUp(email: string, password: string, name: string): Promise<R<{ user: AuthUser }>> {
    const { data, error } = await (await supabase())!.auth.signUp({ email, password, options: { data: { full_name: name }, emailRedirectTo: `${origin()}/auth/callback` } });
    if (error) return { ok: false, error: error.message };
    if (!data.user) return { ok: false, error: "Sign-up failed. Try again." };
    return { ok: true, user: toUser(data.user) };
  },
  async google(): Promise<R> {
    const { error } = await (await supabase())!.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${origin()}/auth/callback` } });
    return error ? { ok: false, error: error.message } : { ok: true };
  },
  async resetPassword(email: string): Promise<R> {
    const { error } = await (await supabase())!.auth.resetPasswordForEmail(email, { redirectTo: `${origin()}/auth/reset` });
    return error ? { ok: false, error: error.message } : { ok: true };
  },
  async updatePassword(password: string): Promise<R> {
    const { error } = await (await supabase())!.auth.updateUser({ password });
    return error ? { ok: false, error: error.message } : { ok: true };
  },
  async signOut() {
    await (await supabase())?.auth.signOut();
  },
};
