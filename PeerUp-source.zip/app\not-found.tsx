import Link from "next/link";
export default function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 p-6 text-center">
      <p className="text-6xl font-extrabold text-navy">404</p>
      <p className="text-subtle">This page doesn't exist.</p>
      <Link href="/dashboard" className="rounded-xl bg-navy px-5 py-3 font-semibold text-white">Back to dashboard</Link>
    </div>
  );
}
