"use client";
import { Ban, Check, MessageCircle, UserMinus, UserPlus, X } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { SampleTag } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Button, Card, EmptyState, Modal, PageHeader, Tabs } from "@/components/ui";
import { yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";

export default function Connections() {
  const { db, me, byId, respondConnection, cancelConnection, unblock } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState<"connected" | "incoming" | "sent" | "blocked">("connected");
  const [remove, setRemove] = useState<string | null>(null);
  if (!me) return null;
  const mine = db.connections.filter((c) => c.fromId === me.id || c.toId === me.id);
  const connected = mine.filter((c) => c.status === "Accepted");
  const incoming = mine.filter((c) => c.status === "Pending" && c.toId === me.id);
  const sent = mine.filter((c) => c.status === "Pending" && c.fromId === me.id);
  const run = (r: { ok: boolean; error?: string }, m: string) => toast(r.ok ? m : r.error!, r.ok ? "success" : "error");
  const rows = tab === "connected" ? connected : tab === "incoming" ? incoming : tab === "sent" ? sent : [];

  return (
    <div>
      <PageHeader title="Connections" subtitle="Students you're connected with, and requests waiting on you." />
      <div className="mb-6"><Tabs value={tab} onChange={setTab} tabs={[{ value: "connected", label: "Connected", count: connected.length }, { value: "incoming", label: "Requests", count: incoming.length }, { value: "sent", label: "Sent", count: sent.length }, { value: "blocked", label: "Blocked", count: me.blocked.length }]} /></div>
      {tab === "blocked" ? (
        me.blocked.length ? (
          <ul className="grid gap-4 md:grid-cols-2">
            {me.blocked.map((id) => { const s = byId(id); return (
              <li key={id} className="neu flex items-center gap-3 p-4">
                <Avatar name={s?.name ?? "?"} src={s?.avatar} size={44} />
                <span className="flex-1 font-bold text-navy">{s?.name ?? "Deleted account"}</span>
                <Button size="sm" variant="secondary" onClick={() => run(unblock(id), "Unblocked.")}>Unblock</Button>
              </li>
            ); })}
          </ul>
        ) : <Card><EmptyState icon={Ban} title="No blocked users" text="You can block anyone from their profile. They won't be able to message, connect with or book you." /></Card>
      ) : rows.length ? (
        <ul className="grid gap-4 md:grid-cols-2">
          {rows.map((c) => {
            const s = byId(c.fromId === me.id ? c.toId : c.fromId);
            if (!s) return null;
            return (
              <li key={c.id} className="neu flex flex-wrap items-center gap-3 p-4">
                <Avatar name={s.name} src={s.avatar} size={48} />
                <div className="min-w-0 flex-1">
                  <Link href={`/profile/${s.id}`} className="flex items-center gap-2 font-bold text-navy hover:underline"><span className="truncate">{s.name}</span>{s.sample && <SampleTag />}</Link>
                  <p className="truncate text-sm text-subtle">{s.department} · {yearLabel(s.year)} · {s.privacy.showCollege ? s.college : s.field}</p>
                  <p className="text-xs text-subtle">{tab === "connected" ? "Connected" : tab === "incoming" ? "Wants to connect" : "Request sent"} {new Date(c.createdAt).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</p>
                </div>
                <div className="flex gap-2">
                  {tab === "connected" && <><Button size="sm" variant="secondary" href={`/messages?with=${s.id}`}><MessageCircle className="h-4 w-4" /> Message</Button><Button size="sm" variant="ghost" onClick={() => setRemove(c.id)} aria-label={`Remove ${s.name}`}><UserMinus className="h-4 w-4" /></Button></>}
                  {tab === "incoming" && <><Button size="sm" variant="accent" onClick={() => run(respondConnection(c.id, true), `Connected with ${s.name}.`)}><Check className="h-4 w-4" /> Accept</Button><Button size="sm" variant="danger" onClick={() => run(respondConnection(c.id, false), "Request declined.")}><X className="h-4 w-4" /> Reject</Button></>}
                  {tab === "sent" && <Button size="sm" variant="secondary" onClick={() => run(cancelConnection(c.id), "Request cancelled.")}>Cancel request</Button>}
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <Card><EmptyState icon={UserPlus} title={tab === "connected" ? "No connections yet" : tab === "incoming" ? "No pending requests" : "No sent requests"} text="Find students with complementary skills and send a request." action={<Button href="/matches">See your matches</Button>} /></Card>
      )}
      <Modal open={!!remove} onClose={() => setRemove(null)} title="Remove connection?">
        <p className="text-sm text-ink">You'll no longer be connected. Existing sessions and messages stay in your history.</p>
        <div className="mt-6 flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setRemove(null)}>Keep</Button><Button variant="danger" className="flex-1" onClick={() => { run(cancelConnection(remove!), "Connection removed."); setRemove(null); }}>Remove</Button></div>
      </Modal>
    </div>
  );
}
