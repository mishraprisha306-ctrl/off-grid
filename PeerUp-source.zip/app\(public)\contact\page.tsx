"use client";
import { CheckCircle2, Send } from "lucide-react";
import { useState } from "react";
import { PublicPage } from "@/components/public-chrome";
import { Button, Field, Input, Select, Textarea } from "@/components/ui";
import { useStore } from "@/lib/store";

export default function Contact() {
  const { submitSupport, me } = useStore();
  const [f, setF] = useState({ name: me?.name ?? "", email: me?.email ?? "", subject: "General question", message: "" });
  const [err, setErr] = useState("");
  const [sent, setSent] = useState(false);
  return (
    <PublicPage title="Contact Us" subtitle="Questions, feedback or a problem to report. We read every message.">
      {sent ? (
        <div className="rounded-[20px] bg-ivory p-8 text-center shadow-[var(--shadow-raised)]" role="status">
          <CheckCircle2 className="mx-auto h-12 w-12 text-teal-strong" />
          <p className="mt-3 text-lg font-bold text-navy">Message received</p>
          <p className="mt-1 text-subtle">It's in our support queue. In this demo it appears in the admin dashboard; email delivery needs a backend.</p>
          <Button className="mt-6" variant="secondary" onClick={() => { setSent(false); setF({ ...f, message: "" }); }}>Send another</Button>
        </div>
      ) : (
        <form
          className="space-y-4 rounded-[20px] bg-ivory p-6 shadow-[var(--shadow-raised)] sm:p-8"
          noValidate
          onSubmit={(e) => {
            e.preventDefault();
            const r = submitSupport(f);
            if (!r.ok) return setErr(r.error);
            setErr("");
            setSent(true);
          }}
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Name" htmlFor="c-n"><Input id="c-n" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoComplete="name" /></Field>
            <Field label="Email" htmlFor="c-e"><Input id="c-e" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} autoComplete="email" /></Field>
          </div>
          <Field label="Subject" htmlFor="c-s">
            <Select id="c-s" value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })}>
              {["General question", "Report a problem", "Report a user", "Account help", "Partnership", "Feedback"].map((x) => <option key={x}>{x}</option>)}
            </Select>
          </Field>
          <Field label="Message" htmlFor="c-m"><Textarea id="c-m" rows={6} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} maxLength={2000} /></Field>
          {err && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err}</p>}
          <Button type="submit" variant="accent"><Send className="h-4 w-4" /> Send message</Button>
        </form>
      )}
    </PublicPage>
  );
}
