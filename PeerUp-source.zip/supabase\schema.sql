-- =====================================================================
-- PeerUp, Supabase PostgreSQL schema with Row Level Security
-- Run in Supabase → SQL Editor (or `supabase db push`). Idempotent-ish:
-- safe to run on an empty project.
-- =====================================================================
create extension if not exists "pgcrypto";

-- ---------- enums ----------
do $$ begin
  create type level_t as enum ('Beginner','Intermediate','Advanced');
  create type mode_t as enum ('online','offline','both');
  create type session_mode_t as enum ('Online','Offline');
  create type session_format_t as enum ('One-to-One','Group');
  create type session_status_t as enum ('Pending','Accepted','Rejected','Completed','Cancelled');
  create type role_t as enum ('student','admin');
  create type cert_status_t as enum ('self','evidence','verified');
  create type mentor_status_t as enum ('none','pending','approved','rejected');
  create type report_status_t as enum ('open','resolved','dismissed');
exception when duplicate_object then null; end $$;

-- ---------- reference tables ----------
create table if not exists educational_fields (id serial primary key, name text unique not null);
insert into educational_fields(name) values ('Engineering'),('Medical'),('Management'),('Law'),('Science'),('Commerce'),('Arts'),('Design'),('Other') on conflict do nothing;

create table if not exists educational_institutions (id uuid primary key default gen_random_uuid(), name text unique not null, created_at timestamptz default now());

create table if not exists skill_categories (id serial primary key, name text unique not null);
insert into skill_categories(name) values ('Programming'),('Web Development'),('Design'),('Mathematics'),('Science'),('Communication'),('Business & Management'),('Legal Studies'),('Medical & Health'),('Finance'),('Data Science'),('Video Editing'),('Other') on conflict do nothing;

create table if not exists skills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  normalized text generated always as (lower(regexp_replace(trim(name), '\s+', ' ', 'g'))) stored,
  category_id int references skill_categories(id),
  unique (normalized)
);

-- ---------- profiles (1:1 with auth.users) ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 2 and 80),
  email text not null,
  role role_t not null default 'student',
  avatar_url text,
  institution_id uuid references educational_institutions(id),
  field_id int references educational_fields(id),
  department text,
  academic_year smallint check (academic_year between 0 and 5), -- 0 = Other
  student_id text,
  bio text check (char_length(bio) <= 240),
  interests text[] default '{}',
  preferred_mode mode_t default 'both',
  preferred_formats session_format_t[] default '{One-to-One}',
  links jsonb default '{}'::jsonb,
  mentor_categories text[] default '{}',
  mentor_status mentor_status_t not null default 'none',
  mentor_available boolean not null default true,
  privacy jsonb not null default '{"showEmail":false,"showCollege":true,"showStudentId":false,"showLinks":true,"messagesFrom":"connections"}'::jsonb,
  suspended boolean not null default false,
  onboarded boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists profiles_field_idx on profiles(field_id);
create index if not exists profiles_institution_idx on profiles(institution_id);

-- auto-create a profile when someone signs up
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, full_name, email, avatar_url)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), new.email, new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$;

-- students can never change their own role, mentor status or suspension
create or replace function protect_profile_columns() returns trigger language plpgsql as $$
begin
  if not is_admin() then
    new.role := old.role; new.mentor_status := case when new.mentor_status = 'pending' and old.mentor_status = 'none' then 'pending' else old.mentor_status end;
    new.suspended := old.suspended;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists profiles_protect on profiles;
create trigger profiles_protect before update on profiles for each row execute function protect_profile_columns();

-- ---------- skills of a student ----------
create table if not exists student_teaching_skills (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  skill_id uuid not null references skills(id),
  level level_t not null,
  description text check (char_length(description) <= 200),
  mode mode_t default 'both',
  portfolio_url text check (portfolio_url is null or portfolio_url ~ '^https?://'),
  unique (profile_id, skill_id)
);
create table if not exists student_learning_goals (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  skill_id uuid not null references skills(id),
  current_level level_t,
  unique (profile_id, skill_id)
);
create index if not exists teach_skill_idx on student_teaching_skills(skill_id);
create index if not exists learn_skill_idx on student_learning_goals(skill_id);

create table if not exists session_availability (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  day text not null check (day in ('Mon','Tue','Wed','Thu','Fri','Sat','Sun')),
  starts time not null, ends time not null, check (ends > starts)
);

create table if not exists portfolio_links (id uuid primary key default gen_random_uuid(), profile_id uuid not null references profiles(id) on delete cascade, kind text not null check (kind in ('github','linkedin','portfolio','other')), url text not null check (url ~ '^https://'));
create table if not exists skill_certificates (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  title text not null, file_path text, url text,
  status cert_status_t not null default 'self',
  verified_by uuid references profiles(id), verified_at timestamptz,
  created_at timestamptz default now()
);

-- ---------- connections ----------
create table if not exists connection_requests (
  id uuid primary key default gen_random_uuid(),
  from_id uuid not null references profiles(id) on delete cascade,
  to_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'Pending' check (status in ('Pending','Accepted')),
  created_at timestamptz default now(),
  check (from_id <> to_id)
);
-- one request/connection per pair regardless of direction
create unique index if not exists connection_pair_uniq on connection_requests (least(from_id,to_id), greatest(from_id,to_id));
create or replace view connections as select * from connection_requests where status = 'Accepted';

create table if not exists blocks (blocker_id uuid references profiles(id) on delete cascade, blocked_id uuid references profiles(id) on delete cascade, created_at timestamptz default now(), primary key (blocker_id, blocked_id));

-- ---------- mentorship ----------
create table if not exists mentor_profiles (profile_id uuid primary key references profiles(id) on delete cascade, headline text, categories text[] default '{}', available boolean default true);
create table if not exists mentor_requests (id uuid primary key default gen_random_uuid(), profile_id uuid not null references profiles(id) on delete cascade, note text, status mentor_status_t default 'pending', decided_by uuid references profiles(id), created_at timestamptz default now());

-- ---------- sessions ----------
create table if not exists sessions (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references profiles(id),
  learner_id uuid not null references profiles(id),
  requester_id uuid not null references profiles(id),
  awaiting_id uuid references profiles(id),
  skill_id uuid not null references skills(id),
  starts_at timestamptz not null,
  duration_min smallint not null check (duration_min between 15 and 240),
  mode session_mode_t not null, format session_format_t not null,
  mentorship boolean not null default false,
  objective text not null check (char_length(objective) >= 5),
  message text, meeting_link text check (meeting_link is null or meeting_link ~ '^https://'), location text, notes text,
  status session_status_t not null default 'Pending',
  was_accepted boolean not null default false,
  teacher_confirmed boolean not null default false,
  learner_confirmed boolean not null default false,
  created_at timestamptz default now(), updated_at timestamptz default now(),
  check (teacher_id <> learner_id)
);
create index if not exists sessions_teacher_idx on sessions(teacher_id, status);
create index if not exists sessions_learner_idx on sessions(learner_id, status);
-- no duplicate open request for the same teacher/learner/skill
create unique index if not exists sessions_open_uniq on sessions(teacher_id, learner_id, skill_id) where status in ('Pending','Accepted');

create table if not exists session_participants (session_id uuid references sessions(id) on delete cascade, profile_id uuid references profiles(id) on delete cascade, primary key (session_id, profile_id));
create table if not exists session_resources (id uuid primary key default gen_random_uuid(), session_id uuid not null references sessions(id) on delete cascade, added_by uuid not null references profiles(id), title text not null, url text not null check (url ~ '^https?://'), created_at timestamptz default now());

create or replace function is_participant(s uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from sessions where id = s and auth.uid() in (teacher_id, learner_id))
      or exists (select 1 from session_participants where session_id = s and profile_id = auth.uid());
$$;

-- valid status transitions; completion only after start and when BOTH confirm
create or replace function enforce_session_transition() returns trigger language plpgsql as $$
begin
  if old.status in ('Rejected','Completed','Cancelled') and new.status <> old.status then raise exception 'Session is closed'; end if;
  if new.status = 'Accepted' and old.status <> 'Accepted' then
    if auth.uid() is distinct from old.awaiting_id then raise exception 'Only the invited participant can accept'; end if;
    new.was_accepted := true;
  end if;
  if new.status = 'Rejected' and auth.uid() is distinct from old.awaiting_id then raise exception 'Only the invited participant can reject'; end if;
  if (new.teacher_confirmed and not old.teacher_confirmed and auth.uid() <> old.teacher_id)
     or (new.learner_confirmed and not old.learner_confirmed and auth.uid() <> old.learner_id) then raise exception 'You can only confirm for yourself'; end if;
  if (new.teacher_confirmed or new.learner_confirmed) and (old.status <> 'Accepted' or now() < old.starts_at) then raise exception 'Confirm only accepted sessions after they start'; end if;
  if new.teacher_confirmed and new.learner_confirmed then new.status := 'Completed'; end if;
  if new.status = 'Completed' and not (new.teacher_confirmed and new.learner_confirmed) then raise exception 'Both participants must confirm'; end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists sessions_transition on sessions;
create trigger sessions_transition before update on sessions for each row execute function enforce_session_transition();

-- ---------- ratings & feedback ----------
create table if not exists teacher_ratings (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  reviewer_id uuid not null references profiles(id),
  reviewee_id uuid not null references profiles(id),
  skill_id uuid not null references skills(id),
  stars smallint not null check (stars between 1 and 5),
  teaching smallint check (teaching between 1 and 5), knowledge smallint check (knowledge between 1 and 5),
  communication smallint check (communication between 1 and 5), experience smallint check (experience between 1 and 5),
  qualities text[] default '{}',
  comment text not null check (char_length(comment) between 10 and 500),
  mentorship boolean not null default false,
  created_at timestamptz default now(), edited_at timestamptz,
  unique (session_id, reviewer_id),           -- one rating per participant per session
  check (reviewer_id <> reviewee_id)          -- no self-rating
);
create table if not exists review_helpful (review_id uuid references teacher_ratings(id) on delete cascade, profile_id uuid references profiles(id) on delete cascade, primary key (review_id, profile_id));

-- rating must come from a learner of a completed session, about its teacher; edits allowed for 7 days
create or replace function enforce_rating() returns trigger language plpgsql as $$
declare s sessions;
begin
  select * into s from sessions where id = new.session_id;
  if s.status <> 'Completed' then raise exception 'Session not completed'; end if;
  if new.reviewee_id <> s.teacher_id then raise exception 'You can only rate the teacher'; end if;
  if new.reviewer_id <> s.learner_id and not exists (select 1 from session_participants where session_id = s.id and profile_id = new.reviewer_id) then raise exception 'Only learners can rate'; end if;
  if tg_op = 'UPDATE' then
    if now() > old.created_at + interval '7 days' then raise exception 'Edit window closed'; end if;
    new.edited_at := now();
  end if;
  new.skill_id := s.skill_id; new.mentorship := s.mentorship;
  return new;
end $$;
drop trigger if exists rating_rules on teacher_ratings;
create trigger rating_rules before insert or update on teacher_ratings for each row execute function enforce_rating();

create table if not exists learner_feedback (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  teacher_id uuid not null references profiles(id), learner_id uuid not null references profiles(id),
  progress smallint check (progress between 1 and 5),
  comment text not null, suggestions text, is_private boolean not null default true,
  created_at timestamptz default now(),
  unique (session_id, teacher_id)
);

-- ---------- derived reputation (views, never stored by hand) ----------
create or replace view rating_summary as
  select reviewee_id as profile_id, count(*) as review_count, avg(stars)::numeric(3,2) as average
  from teacher_ratings group by reviewee_id;
create or replace view skill_rating_summary as
  select reviewee_id as profile_id, skill_id, count(*) as review_count, avg(stars)::numeric(3,2) as average
  from teacher_ratings group by reviewee_id, skill_id;

-- trust score mirrors lib/engines.ts → trustScore (50 rating · 20 sessions · 15 consistency · 15 reliability)
create or replace view trust_scores as
with t as (
  select p.id,
    coalesce(r.review_count,0) n, r.average avg,
    (select count(*) from sessions s where s.teacher_id = p.id and s.status = 'Completed') done,
    (select count(*) from sessions s where s.teacher_id = p.id and s.was_accepted and s.status in ('Completed','Cancelled')) committed,
    (select count(*) from teacher_ratings x where x.reviewee_id = p.id and x.stars >= 4) positive
  from profiles p left join rating_summary r on r.profile_id = p.id)
select id as profile_id,
  least(100, round(
    coalesce(avg/5*50*least(1, n/3.0),0)
    + least(20, 20*ln(1+done)/ln(21))
    + case when n >= 3 then positive::numeric/n*15 else 0 end
    + case when committed > 0 then least(15, 15*done::numeric/committed*least(1, committed/3.0)) else 0 end))::int as score,
  (n >= 3 and done >= 3) as established
from t;

-- ---------- learning ----------
create table if not exists learning_progress (id uuid primary key default gen_random_uuid(), profile_id uuid not null references profiles(id) on delete cascade, skill text not null, percent smallint default 0 check (percent between 0 and 100), goal text, notes text, milestones jsonb default '[]', completed boolean default false, updated_at timestamptz default now());
create table if not exists learning_challenges (id text primary key, title text not null, kind text, days smallint not null);
create table if not exists challenge_participation (id uuid primary key default gen_random_uuid(), profile_id uuid references profiles(id) on delete cascade, challenge_id text references learning_challenges(id), started_at timestamptz default now(), days_done smallint[] default '{}', unique (profile_id, challenge_id));
create table if not exists student_achievements (profile_id uuid references profiles(id) on delete cascade, achievement text, earned_at timestamptz default now(), primary key (profile_id, achievement));
create table if not exists learning_resources (id uuid primary key default gen_random_uuid(), owner_id uuid not null references profiles(id) on delete cascade, title text not null, url text not null check (url ~ '^https?://'), kind text not null, skill text, created_at timestamptz default now());

-- ---------- messaging & notifications ----------
create table if not exists conversations (id uuid primary key default gen_random_uuid(), a uuid not null references profiles(id) on delete cascade, b uuid not null references profiles(id) on delete cascade, created_at timestamptz default now(), check (a < b), unique (a,b));
create table if not exists messages (id uuid primary key default gen_random_uuid(), conversation_id uuid not null references conversations(id) on delete cascade, sender_id uuid not null references profiles(id) on delete cascade, body text not null check (char_length(body) between 1 and 1000), read_at timestamptz, created_at timestamptz default now());
create index if not exists messages_conv_idx on messages(conversation_id, created_at);
create table if not exists notifications (id uuid primary key default gen_random_uuid(), profile_id uuid not null references profiles(id) on delete cascade, kind text not null, text text not null, href text, read boolean default false, created_at timestamptz default now());
create index if not exists notifications_user_idx on notifications(profile_id, read, created_at desc);

-- ---------- safety, support, admin ----------
create table if not exists user_reports (id uuid primary key default gen_random_uuid(), reporter_id uuid not null references profiles(id) on delete cascade, target_type text not null check (target_type in ('user','review','message')), target_id uuid not null, reason text not null check (char_length(reason) >= 10), status report_status_t default 'open', created_at timestamptz default now(), unique (reporter_id, target_id, status));
create table if not exists support_requests (id uuid primary key default gen_random_uuid(), name text not null, email text not null, subject text not null, message text not null, status text default 'open', created_at timestamptz default now());
create table if not exists admin_audit_logs (id uuid primary key default gen_random_uuid(), admin_id uuid not null references profiles(id), action text not null, created_at timestamptz default now());

-- =====================================================================
-- Row Level Security
-- =====================================================================
alter table profiles enable row level security;
alter table student_teaching_skills enable row level security;
alter table student_learning_goals enable row level security;
alter table session_availability enable row level security;
alter table portfolio_links enable row level security;
alter table skill_certificates enable row level security;
alter table connection_requests enable row level security;
alter table blocks enable row level security;
alter table mentor_profiles enable row level security;
alter table mentor_requests enable row level security;
alter table sessions enable row level security;
alter table session_participants enable row level security;
alter table session_resources enable row level security;
alter table teacher_ratings enable row level security;
alter table review_helpful enable row level security;
alter table learner_feedback enable row level security;
alter table learning_progress enable row level security;
alter table challenge_participation enable row level security;
alter table learning_resources enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table notifications enable row level security;
alter table user_reports enable row level security;
alter table support_requests enable row level security;
alter table admin_audit_logs enable row level security;
alter table skills enable row level security;

-- public catalogue
create policy "skills readable" on skills for select using (true);
create policy "skills insert by users" on skills for insert with check (auth.uid() is not null);

-- profiles: everyone signed-in can read non-suspended profiles; privacy is enforced in the profile_public view below
create policy "profiles read" on profiles for select using (auth.uid() is not null and (not suspended or id = auth.uid() or is_admin()));
create policy "profiles update own" on profiles for update using (id = auth.uid() or is_admin());
create policy "profiles delete own" on profiles for delete using (id = auth.uid());

create or replace view profile_public with (security_invoker = true) as
  select id, full_name, avatar_url, field_id, department, academic_year, bio, interests, preferred_mode, preferred_formats, mentor_categories, mentor_status, mentor_available,
    case when (privacy->>'showEmail')::boolean or id = auth.uid() then email end as email,
    case when (privacy->>'showCollege')::boolean or id = auth.uid() then institution_id end as institution_id,
    case when (privacy->>'showStudentId')::boolean or id = auth.uid() then student_id end as student_id,
    case when (privacy->>'showLinks')::boolean or id = auth.uid() then links end as links
  from profiles;

-- owner-managed child tables
create policy "teach read" on student_teaching_skills for select using (auth.uid() is not null);
create policy "teach write" on student_teaching_skills for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "learn read" on student_learning_goals for select using (auth.uid() is not null);
create policy "learn write" on student_learning_goals for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "slots read" on session_availability for select using (auth.uid() is not null);
create policy "slots write" on session_availability for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "links read" on portfolio_links for select using (auth.uid() is not null);
create policy "links write" on portfolio_links for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "certs read" on skill_certificates for select using (auth.uid() is not null);
create policy "certs insert own" on skill_certificates for insert with check (profile_id = auth.uid() and status <> 'verified');
create policy "certs delete own" on skill_certificates for delete using (profile_id = auth.uid());
create policy "certs verify admin" on skill_certificates for update using (is_admin());

-- connections: only the two people involved
create policy "conn read" on connection_requests for select using (auth.uid() in (from_id, to_id));
create policy "conn request" on connection_requests for insert with check (from_id = auth.uid() and status = 'Pending'
  and not exists (select 1 from blocks where (blocker_id = to_id and blocked_id = auth.uid()) or (blocker_id = auth.uid() and blocked_id = to_id)));
create policy "conn accept" on connection_requests for update using (to_id = auth.uid()) with check (status = 'Accepted');
create policy "conn remove" on connection_requests for delete using (auth.uid() in (from_id, to_id));
create policy "blocks own" on blocks for all using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create policy "mentor profiles read" on mentor_profiles for select using (true);
create policy "mentor profiles own" on mentor_profiles for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "mentor req own" on mentor_requests for insert with check (profile_id = auth.uid());
create policy "mentor req read" on mentor_requests for select using (profile_id = auth.uid() or is_admin());
create policy "mentor req decide" on mentor_requests for update using (is_admin());

-- sessions: participants only (admins can monitor)
create policy "sessions read" on sessions for select using (is_participant(id) or is_admin());
create policy "sessions request" on sessions for insert with check (requester_id = auth.uid() and auth.uid() in (teacher_id, learner_id) and status = 'Pending' and starts_at > now());
create policy "sessions update" on sessions for update using (is_participant(id));
create policy "participants read" on session_participants for select using (is_participant(session_id) or is_admin());
create policy "participants add" on session_participants for insert with check (exists (select 1 from sessions where id = session_id and requester_id = auth.uid()));
create policy "resources read" on session_resources for select using (is_participant(session_id));
create policy "resources add" on session_resources for insert with check (added_by = auth.uid() and is_participant(session_id));

-- ratings: public to read, written only by eligible learners (trigger enforces eligibility)
create policy "ratings read" on teacher_ratings for select using (auth.uid() is not null);
create policy "ratings insert" on teacher_ratings for insert with check (reviewer_id = auth.uid());
create policy "ratings edit own" on teacher_ratings for update using (reviewer_id = auth.uid());
create policy "ratings admin delete" on teacher_ratings for delete using (is_admin());
create policy "helpful own" on review_helpful for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

-- learner feedback: private between teacher & learner unless shared
create policy "feedback read" on learner_feedback for select using (auth.uid() in (teacher_id, learner_id) or (not is_private and auth.uid() is not null));
create policy "feedback write" on learner_feedback for insert with check (teacher_id = auth.uid() and exists (select 1 from sessions where id = session_id and teacher_id = auth.uid() and status = 'Completed'));

create policy "progress own" on learning_progress for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "challenge own" on challenge_participation for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "resources public read" on learning_resources for select using (auth.uid() is not null);
create policy "resources own write" on learning_resources for insert with check (owner_id = auth.uid());
create policy "resources own delete" on learning_resources for delete using (owner_id = auth.uid() or is_admin());

-- messaging: only the two members of a conversation; blocked users can't post
create policy "conv read" on conversations for select using (auth.uid() in (a, b));
create policy "conv create" on conversations for insert with check (auth.uid() in (a, b));
create policy "msg read" on messages for select using (exists (select 1 from conversations c where c.id = conversation_id and auth.uid() in (c.a, c.b)) or is_admin());
create policy "msg send" on messages for insert with check (sender_id = auth.uid() and exists (
  select 1 from conversations c where c.id = conversation_id and auth.uid() in (c.a, c.b)
  and not exists (select 1 from blocks bl where (bl.blocker_id = c.a and bl.blocked_id = c.b) or (bl.blocker_id = c.b and bl.blocked_id = c.a))));
create policy "msg mark read" on messages for update using (exists (select 1 from conversations c where c.id = conversation_id and auth.uid() in (c.a, c.b)) and sender_id <> auth.uid());
create policy "msg admin delete" on messages for delete using (is_admin());

create policy "notif own" on notifications for select using (profile_id = auth.uid());
create policy "notif mark" on notifications for update using (profile_id = auth.uid());

create policy "reports create" on user_reports for insert with check (reporter_id = auth.uid());
create policy "reports admin" on user_reports for select using (is_admin() or reporter_id = auth.uid());
create policy "reports resolve" on user_reports for update using (is_admin());
create policy "support create" on support_requests for insert with check (true);
create policy "support admin" on support_requests for all using (is_admin());
create policy "audit admin" on admin_audit_logs for all using (is_admin()) with check (admin_id = auth.uid());

-- =====================================================================
-- Storage buckets (profile pictures, certificates)
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars','avatars', true, 2097152, array['image/jpeg','image/png','image/webp']),
       ('certificates','certificates', false, 5242880, array['application/pdf','image/jpeg','image/png'])
on conflict (id) do nothing;
create policy "avatar read" on storage.objects for select using (bucket_id = 'avatars');
create policy "avatar write own" on storage.objects for insert with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatar update own" on storage.objects for update using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "cert read own or admin" on storage.objects for select using (bucket_id = 'certificates' and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()));
create policy "cert write own" on storage.objects for insert with check (bucket_id = 'certificates' and (storage.foldername(name))[1] = auth.uid()::text);

-- Make yourself an admin (run once, with your own user id):
-- update profiles set role = 'admin' where email = 'you@college.edu';
