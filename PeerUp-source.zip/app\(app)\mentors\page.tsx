"use client";
import { Check, CircleDot, GraduationCap, Info, MessageCircle, X } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { ConnectButton, ProfileModal, RequestSessionModal, SampleTag } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Badge, Button, Card, EmptyState, MentorBadge, Modal, PageHeader, Select, SkillChip, Stars, cn } from "@/components/ui";
import { isMentor, mentorCheck, ratingSummary, trustScore, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FIELDS, MENTOR_CATEGORIES, type Student } from "@/lib/types";

export default function Mentors() {
  const { db, me, requestMentorBadge } = useStore();
  const toast = useToast();
  const [field, setField] = useState("");
  const [dept, setDept] = useState("");
  const [cat, setCat] = useState("");
  const [avail, setAvail] = useState("");
  const [q, setQ] = useState("");
  const [view, setView] = useState<Student | null>(null);
  const [req, setReq] = useState<Student | null>(null);
  const [how, setHow] = useState(false);
  const list = useMemo(
    () => db.students
      .filter((s) => s.id !== me?.id && isMentor(s, db) && !me?.blocked.includes(s.id))
      .filter((s) => (!field || s.field === field) && (!dept || s.department === dept) && (!cat || s.mentorCategories.includes(cat)) && (!avail || s.mentorAvailable) &&
        (!q || s.name.toLowerCase().includes(q.toLowerCase()) || s.teach.some((t) => t.name.toLowerCase().includes(q.toLowerCase()))))
      .map((s) => ({ s, r: ratingSummary(s.id, db.reviews), mr: ratingSummary(s.id, db.reviews, { mentorship: true }), t: trustScore(s.id, db), mSessions: db.sessions.filter((x) => x.teacherId === s.id && x.mentorship && x.status === "Completed").length }))
      .sort((a, b) => (b.mr.average ?? b.r.average ?? 0) - (a.mr.average ?? a.r.average ?? 0)),
    [db, me, field, dept, cat, avail, q],
  );
  const depts = [...new Set(db.students.map((s) => s.department))].sort();
  const myCheck = me ? mentorCheck(me, db) : null;

  return (
    <div>
      <PageHeader title="Senior Mentors" subtitle="Guidance from experienced students who've already been through your academic journey." action={<Button variant="secondary" onClick={() => setHow(true)}><Info className="h-4 w-4" /> How mentors are chosen</Button>} />
      <Card className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search mentor or skill" className="field col-span-2 md:col-span-1" aria-label="Search mentors" />
        <Select value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Mentor category"><option value="">All mentor types</option>{MENTOR_CATEGORIES.map((c) => <option key={c} value={c}>{c} Mentors</option>)}</Select>
        <Select value={field} onChange={(e) => setField(e.target.value)} aria-label="Field"><option value="">All fields</option>{FIELDS.map((f) => <option key={f}>{f}</option>)}</Select>
        <Select value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Branch"><option value="">All branches</option>{depts.map((d) => <option key={d}>{d}</option>)}</Select>
        <Select value={avail} onChange={(e) => setAvail(e.target.value)} aria-label="Availability"><option value="">Any availability</option><option value="1">Accepting mentees</option></Select>
      </Card>
      {list.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {list.map(({ s, r, mr, t, mSessions }) => (
            <Card key={s.id} hover className="flex flex-col">
              <div className="flex items-start gap-3.5">
                <Avatar name={s.name} src={s.avatar} size={56} />
                <div className="min-w-0 flex-1">
                  <button onClick={() => setView(s)} className="flex items-center gap-2 text-left text-[1.05rem] font-bold text-navy hover:underline"><span className="truncate">{s.name}</span>{s.sample && <SampleTag />}</button>
                  <p className="truncate text-sm text-subtle">{s.field} · {s.department} · {yearLabel(s.year)}</p>
                  <p className="truncate text-xs text-subtle">{s.privacy.showCollege ? s.college : "College hidden"}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1.5"><MentorBadge small />{s.mentorStatus === "approved" && <Badge tone="green">Admin approved</Badge>}</div>
                </div>
              </div>
              <p className="mt-3 line-clamp-2 text-sm text-ink">{s.bio}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">{s.mentorCategories.map((c) => <Badge key={c} tone="teal">{c}</Badge>)}</div>
              <div className="mt-3 flex flex-wrap gap-1.5">{s.teach.map((x) => <SkillChip key={x.name}>{x.name}</SkillChip>)}</div>
              <div className="neu-inset mt-5 grid grid-cols-3 rounded-2xl py-3 text-center">
                <div><p className="font-extrabold text-navy">{mr.count ? mr.average!.toFixed(1) : "-"}</p><p className="text-[0.68rem] text-subtle">Mentor rating</p></div>
                <div><p className="font-extrabold text-navy">{mSessions}</p><p className="text-[0.68rem] text-subtle">Mentorships</p></div>
                <div><p className="font-extrabold text-navy">{t.established ? t.total : "New"}</p><p className="text-[0.68rem] text-subtle">Trust</p></div>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs"><Stars value={r.average} size={12} showValue count={r.count} /><span className={cn("inline-flex items-center gap-1 font-semibold", s.mentorAvailable ? "text-teal-strong" : "text-subtle")}><CircleDot className="h-3 w-3" />{s.mentorAvailable ? "Accepting mentees" : "Not accepting now"}</span></div>
              {(s.privacy.showLinks && (s.links.github || s.links.linkedin || s.links.portfolio)) && <p className="mt-2 flex gap-3 text-xs">{Object.entries(s.links).filter(([, v]) => v).map(([k2, v]) => <a key={k2} href={v} target="_blank" rel="noreferrer" className="font-semibold text-teal-strong capitalize hover:underline">{k2}</a>)}</p>}
              <div className="mt-auto flex flex-wrap gap-2 pt-5">
                <Button size="sm" variant="accent" className="flex-1" disabled={!s.mentorAvailable} onClick={() => setReq(s)}><GraduationCap className="h-4 w-4" /> Request guidance</Button>
                <ConnectButton student={s} className="flex-1" />
                <Button size="sm" variant="ghost" href={`/messages?with=${s.id}`} aria-label={`Message ${s.name}`}><MessageCircle className="h-4 w-4" /></Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card><EmptyState icon={GraduationCap} title="No mentors match" text="Try another field, branch or mentor type." action={<Button variant="secondary" onClick={() => { setField(""); setDept(""); setCat(""); setAvail(""); setQ(""); }}>Clear filters</Button>} /></Card>
      )}

      {me && me.role !== "admin" && myCheck && (
        <Card className="mt-10">
          <h2 className="font-bold text-navy">Your Senior Mentor status</h2>
          <p className="mt-1 text-sm text-subtle">{isMentor(me, db) ? "You're a Senior Mentor. Thank you for guiding others!" : me.mentorStatus === "pending" ? "Your request is with an admin for review." : "Meet every criterion to earn the badge automatically, or ask an admin to review your experience."}</p>
          <ul className="mt-4 grid gap-2 sm:grid-cols-2">{myCheck.criteria.map((c) => <li key={c.label} className="flex items-center gap-2 text-sm">{c.met ? <Check className="h-4 w-4 text-teal-strong" /> : <X className="h-4 w-4 text-muted" />}<span className={c.met ? "text-ink" : "text-subtle"}>{c.label}</span></li>)}</ul>
          {!isMentor(me, db) && me.mentorStatus !== "pending" && <Button className="mt-5" variant="secondary" onClick={() => { const r = requestMentorBadge(); toast(r.ok ? "Request sent to the admin team." : r.error, r.ok ? "success" : "error"); }}>Request admin review</Button>}
        </Card>
      )}

      <Modal open={how} onClose={() => setHow(false)} title="How Senior Mentors are chosen">
        <div className="space-y-3 text-sm text-ink">
          <p>The badge needs <b>all</b> of these: seniority (year {db.settings.mentorMinYear}+, or proven Advanced-level experience), {db.settings.mentorMinSessions}+ completed teaching sessions, an average of {db.settings.mentorMinRating.toFixed(1)}★ or more from at least 3 reviews, and no unresolved conduct reports.</p>
          <p>Admins can approve someone with strong evidence, or withdraw the badge. Being in a higher year alone never earns it.</p>
          <p className="text-subtle">The mentor badge is separate from the <Link href="/trust" className="font-semibold text-teal-strong">trust score</Link>, which never looks at academic year.</p>
        </div>
      </Modal>
      <ProfileModal student={view} onClose={() => setView(null)} />
      <RequestSessionModal open={!!req} other={req} onClose={() => setReq(null)} role="learn" mentorship title={req ? `Request guidance from ${req.name.split(" ")[0]}` : undefined} />
    </div>
  );
}
