import { PublicPage } from "@/components/public-chrome";
import { Figures } from "@/components/logo";

export const metadata = { title: "About Us" };

const S = ({ h, children }: { h: string; children: React.ReactNode }) => (
  <section>
    <h2 className="text-xl font-extrabold text-navy">{h}</h2>
    <div className="mt-2 space-y-3 text-subtle">{children}</div>
  </section>
);

export default function About() {
  return (
    <PublicPage title="About PeerUp" subtitle="Peer Learning with Rating: a skill exchange built by students, for students.">
      <div className="mx-auto w-48 rounded-[28px] bg-ivory p-6 shadow-[0_0_60px_10px_rgb(246_201_204/.6)]"><Figures /></div>
      <S h="What is PeerUp?"><p>PeerUp connects students who can teach a skill with students who want to learn it, across colleges, branches, years and fields of study. Sessions are arranged in the app, and every completed session can be rated.</p></S>
      <S h="Why was it created?"><p>Students already help each other in hostels, libraries and group chats, but that help is invisible and hard to find. The student who explained recursion perfectly at 2 a.m. gets no credit, and the student who needed it most never finds them.</p></S>
      <S h="What problem does it solve?"><p>It makes peer expertise discoverable and trustworthy. Mutual matching surfaces fair trades. Ratings only come from real, completed sessions. Trust scores explain exactly how they're calculated.</p></S>
      <S h="Our mission"><p>Make every student both a learner and a teacher, and make that contribution count.</p></S>
      <S h="How peer learning works"><p>You list what you can teach and what you want to learn. PeerUp finds students whose lists complement yours. You connect, agree a time, meet online or in person, and the learner rates the session afterwards.</p></S>
      <S h="Benefits of skill exchange"><ul className="list-disc space-y-1 pl-5"><li>Learn from someone who remembers what was hard.</li><li>Teaching deepens your own understanding.</li><li>Build a verified record of skills beyond your transcript.</li><li>Meet students outside your own department and college.</li></ul></S>
      <S h="Platform vision"><p>A campus-wide, then inter-campus, network where reputation is earned through helping others, and where seniors pass on what they learned to the students who come after them.</p></S>
    </PublicPage>
  );
}
