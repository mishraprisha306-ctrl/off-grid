"use client";
import { CalendarDays, CalendarPlus, CalendarRange } from "lucide-react";
import { useState } from "react";
import { RequestSessionModal, SessionCard } from "@/components/domain";
import { Button, Card, EmptyState, Field, Modal, PageHeader, Select, Tabs } from "@/components/ui";
import { participants, sessionStart, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { Student } from "@/lib/types";

export default function Sessions() {
  const { db, me, byId, now } = useStore();
  const [tab, setTab] = useState<"requests" | "upcoming" | "past">("requests");
  const [type, setType] = useState("");
  const [pick, setPick] = useState(false);
  const [pickId, setPickId] = useState("");
  const [other, setOther] = useState<Student | null>(null);
  if (!me) return null;
  const mine = db.sessions.filter((s) => participants(s).includes(me.id) && (!type || `${s.mode} ${s.format}` === type || (type === "mentorship" && s.mentorship)));
  const requests = mine.filter((s) => s.status === "Pending").sort((a, b) => Number(b.awaitingId === me.id) - Number(a.awaitingId === me.id) || +sessionStart(a) - +sessionStart(b));
  const upcoming = mine.filter((s) => s.status === "Accepted").sort((a, b) => +sessionStart(a) - +sessionStart(b));
  const past = mine.filter((s) => ["Completed", "Rejected", "Cancelled"].includes(s.status)).sort((a, b) => +sessionStart(b) - +sessionStart(a));
  const list = { requests, upcoming, past }[tab];
  const peers = db.students.filter((s) => s.id !== me.id && s.role !== "admin" && !s.suspended && !me.blocked.includes(s.id)).sort((a, b) => a.name.localeCompare(b.name));
  const needConfirm = upcoming.filter((s) => sessionStart(s).getTime() < now && !s.completedBy.includes(me.id)).length;

  return (
    <div>
      <PageHeader title="Sessions" subtitle="Request, accept, reschedule and complete your learning sessions." action={<div className="flex gap-2"><Button variant="secondary" href="/calendar"><CalendarRange className="h-4 w-4" /> Calendar</Button><Button variant="accent" onClick={() => { setPickId(peers[0]?.id ?? ""); setPick(true); }}><CalendarPlus className="h-4 w-4" /> Book a session</Button></div>} />
      {needConfirm > 0 && <p className="mb-4 rounded-xl bg-[#f7ecd6] px-4 py-3 text-sm font-semibold text-[#7a520b]">{needConfirm} session{needConfirm > 1 ? "s have" : " has"} started or ended. Confirm completion so ratings can open.</p>}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={tab} onChange={setTab} tabs={[{ value: "requests", label: "Requests", count: requests.length }, { value: "upcoming", label: "Upcoming", count: upcoming.length }, { value: "past", label: "History", count: past.length }]} />
        <Select value={type} onChange={(e) => setType(e.target.value)} className="sm:w-56" aria-label="Session type">
          <option value="">All session types</option>
          {["Online One-to-One", "Offline One-to-One", "Online Group", "Offline Group"].map((t) => <option key={t}>{t}</option>)}
          <option value="mentorship">Mentorship only</option>
        </Select>
      </div>
      {list.length ? <div className="space-y-4">{list.map((s) => <SessionCard key={s.id} session={s} />)}</div> : (
        <Card><EmptyState icon={CalendarDays} title={tab === "requests" ? "No pending requests" : tab === "upcoming" ? "Nothing scheduled" : "No history yet"} text={tab === "past" ? "Completed, rejected and cancelled sessions stay here for every participant." : "Find a match and request a session."} action={<Button href="/matches">See your matches</Button>} /></Card>
      )}
      <Modal open={pick} onClose={() => setPick(false)} title="Who do you want a session with?">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); const s = byId(pickId); if (s) { setPick(false); setOther(s); } }}>
          <Field label="Student" htmlFor="pk"><Select id="pk" value={pickId} onChange={(e) => setPickId(e.target.value)}>{peers.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.department}, {yearLabel(s.year)} · teaches {s.teach.map((t) => t.name).join(", ")}</option>)}</Select></Field>
          <Button type="submit" className="w-full">Continue</Button>
        </form>
      </Modal>
      <RequestSessionModal open={!!other} other={other} onClose={() => setOther(null)} />
    </div>
  );
}
