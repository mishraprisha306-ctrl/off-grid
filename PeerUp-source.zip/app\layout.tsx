import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-jakarta", display: "swap" });

export const metadata: Metadata = {
  title: { default: "PeerUp | Peer Learning with Rating", template: "%s · PeerUp" },
  description: "Your skills have value. Share them. Teach, learn and exchange skills with students across colleges, with honest ratings and transparent trust scores.",
};
export const viewport: Viewport = { themeColor: "#1f2547" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={jakarta.variable}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
