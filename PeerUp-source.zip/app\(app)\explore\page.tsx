"use client";
import { RotateCcw, Search, SearchX } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";
import { ProfileModal, RequestSessionModal, SkillCard, StudentCard } from "@/components/domain";
import { Button, Card, EmptyState, Input, PageHeader, Select, Tabs } from "@/components/ui";
import { computeMatch, isMentor, ratingSummary, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FIELDS, FORMATS, LEVELS, type Student, type TeachSkill, YEARS } from "@/lib/types";

const INIT = { field: "", college: "", dept: "", year: "", level: "", rating: "0", mode: "", format: "", mentor: "", sort: "relevance" };

function Explore() {
  const { db, me } = useStore();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [f, setF] = useState(INIT);
  const [view, setView] = useState<"skills" | "students">("skills");
  const [profile, setProfile] = useState<Student | null>(null);
  const [req, setReq] = useState<{ s: Student; skill?: string } | null>(null);
  useEffect(() => setQ(params.get("q") ?? ""), [params]);

  const pool = useMemo(() => db.students.filter((s) => s.id !== me?.id && s.role !== "admin" && !s.suspended && !me?.blocked.includes(s.id) && !s.blocked.includes(me?.id ?? "")), [db.students, me]);
  const colleges = useMemo(() => [...new Set(pool.map((s) => s.college))].sort(), [pool]);
  const depts = useMemo(() => [...new Set(pool.map((s) => s.department))].sort(), [pool]);
  const k = q.trim().toLowerCase();

  const passStudent = (s: Student, avg: number | null) =>
    (!f.field || s.field === f.field) && (!f.college || s.college === f.college) && (!f.dept || s.department === f.dept) && (!f.year || s.year === Number(f.year)) &&
    (Number(f.rating) === 0 || (avg ?? 0) >= Number(f.rating)) && (!f.mode || s.mode === f.mode || s.mode === "both") &&
    (!f.format || s.formats.includes(f.format as Student["formats"][number])) && (!f.mentor || isMentor(s, db));

  const students = useMemo(() => pool
    .map((s) => {
      const r = ratingSummary(s.id, db.reviews);
      const m = me ? computeMatch(me, s) : null;
      const nameHit = s.name.toLowerCase().includes(k);
      const skillHit = s.teach.some((t) => t.name.toLowerCase().includes(k));
      const otherHit = s.learn.some((t) => t.name.toLowerCase().includes(k)) || s.college.toLowerCase().includes(k) || s.department.toLowerCase().includes(k) || s.field.toLowerCase().includes(k);
      return { s, r, rel: (m?.percent ?? 0) + (k && nameHit ? 60 : 0) + (k && skillHit ? 50 : 0) + (s.field === me?.field ? 5 : 0), hit: !k || nameHit || skillHit || otherHit };
    })
    .filter(({ s, r, hit }) => hit && passStudent(s, r.average) && (!f.level || s.teach.some((t) => t.level === f.level)))
    .sort((a, b) => (f.sort === "rating" ? (b.r.average ?? 0) - (a.r.average ?? 0) || b.r.count - a.r.count : b.rel - a.rel || (b.r.average ?? 0) - (a.r.average ?? 0))),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  [pool, db, me, k, f]);

  const skills = useMemo(() => students.flatMap(({ s, r }) => s.teach
    .filter((t) => (!k || t.name.toLowerCase().includes(k) || s.name.toLowerCase().includes(k) || t.category.toLowerCase().includes(k) || s.college.toLowerCase().includes(k)) && (!f.level || t.level === f.level))
    .map((t) => ({ s, t, avg: r.bySkill.find((b) => b.skill === t.name)?.average ?? null })))
    .sort((a, b) => (f.sort === "rating" ? (b.avg ?? 0) - (a.avg ?? 0) : 0)), [students, k, f.level, f.sort]);

  const set = (key: keyof typeof INIT) => (e: React.ChangeEvent<HTMLSelectElement>) => setF({ ...f, [key]: e.target.value });
  const dirty = q || JSON.stringify(f) !== JSON.stringify(INIT);
  const reset = () => { setQ(""); setF(INIT); };

  return (
    <div>
      <PageHeader title="Explore Skills" subtitle="Find skills, students and mentors across colleges and fields." action={<Tabs value={view} onChange={setView} tabs={[{ value: "skills", label: "Skill cards", count: skills.length }, { value: "students", label: "Students", count: students.length }]} />} />
      <Card className="mb-8 space-y-4">
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a skill, student, college, branch or field…" className="pl-10" aria-label="Search" />
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
          <Select value={f.field} onChange={set("field")} aria-label="Educational field"><option value="">All fields</option>{FIELDS.map((x) => <option key={x}>{x}</option>)}</Select>
          <Select value={f.college} onChange={set("college")} aria-label="College"><option value="">All colleges</option>{colleges.map((x) => <option key={x}>{x}</option>)}</Select>
          <Select value={f.dept} onChange={set("dept")} aria-label="Branch"><option value="">All branches</option>{depts.map((x) => <option key={x}>{x}</option>)}</Select>
          <Select value={f.year} onChange={set("year")} aria-label="Year"><option value="">All years</option>{YEARS.map((y) => <option key={y} value={y}>{yearLabel(y)}</option>)}</Select>
          <Select value={f.level} onChange={set("level")} aria-label="Experience"><option value="">Any level</option>{LEVELS.map((l) => <option key={l}>{l}</option>)}</Select>
          <Select value={f.rating} onChange={set("rating")} aria-label="Minimum rating"><option value="0">Any rating</option><option value="4">4.0+ ★</option><option value="4.5">4.5+ ★</option><option value="4.8">4.8+ ★</option></Select>
          <Select value={f.mode} onChange={set("mode")} aria-label="Online or offline"><option value="">Online or offline</option><option value="online">Online</option><option value="offline">Offline</option></Select>
          <Select value={f.format} onChange={set("format")} aria-label="Session type"><option value="">Any session type</option>{FORMATS.map((x) => <option key={x}>{x}</option>)}</Select>
          <Select value={f.mentor} onChange={set("mentor")} aria-label="Mentors"><option value="">Everyone</option><option value="1">Senior Mentors only</option></Select>
          <Select value={f.sort} onChange={set("sort")} aria-label="Sort"><option value="relevance">Sort: Relevance</option><option value="rating">Sort: Highest rating</option></Select>
        </div>
        <div className="flex items-center justify-between text-sm text-subtle">
          <span aria-live="polite">{view === "skills" ? `${skills.length} skill cards` : `${students.length} students`}</span>
          {dirty && <button onClick={reset} className="inline-flex items-center gap-1 font-semibold text-teal-strong hover:underline"><RotateCcw className="h-3.5 w-3.5" /> Reset filters</button>}
        </div>
      </Card>
      {(view === "skills" ? skills.length : students.length) ? (
        <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {view === "skills"
            ? skills.map(({ s, t }: { s: Student; t: TeachSkill }) => <SkillCard key={s.id + t.name} student={s} skill={t} onView={() => setProfile(s)} onRequest={() => setReq({ s, skill: t.name })} />)
            : students.map(({ s }) => <StudentCard key={s.id} student={s} highlight={q.trim()} onView={() => setProfile(s)} onRequest={() => setReq({ s })} />)}
        </div>
      ) : (
        <Card><EmptyState icon={SearchX} title="Nothing matches yet" text="Try another skill or loosen the filters." action={<Button variant="secondary" onClick={reset}>Clear search</Button>} /></Card>
      )}
      <ProfileModal student={profile} onClose={() => setProfile(null)} />
      <RequestSessionModal open={!!req} other={req?.s ?? null} skill={req?.skill} role="learn" onClose={() => setReq(null)} />
    </div>
  );
}

export default function Page() {
  return <Suspense><Explore /></Suspense>;
}
