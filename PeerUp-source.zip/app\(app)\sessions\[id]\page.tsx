"use client";
import { ArrowLeft, CalendarClock, ExternalLink, Link2, Lock, MapPin, MonitorSmartphone, NotebookPen, Plus, Target, Users } from "lucide-react";
import Link from "next/link";
import { use, useState } from "react";
import { CancelModal, RescheduleModal, SampleTag, SessionActions, fmtDate, fmtTime, statusTone } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Badge, Button, Card, EmptyState, Field, Input, StarInput, Textarea, cn } from "@/components/ui";
import { participants, timeState, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";

export default function Room({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { db, me, byId, now, updateRoom, addSessionResource, submitFeedback } = useStore();
  const toast = useToast();
  const s = db.sessions.find((x) => x.id === id);
  const [notes, setNotes] = useState(s?.notes ?? "");
  const [link, setLink] = useState(s?.meetingLink ?? "");
  const [loc, setLoc] = useState(s?.location ?? "");
  const [res, setRes] = useState({ title: "", url: "" });
  const [fb, setFb] = useState({ progress: 0, comment: "", suggestions: "", private: true });
  const [fbErr, setFbErr] = useState("");
  const [resched, setResched] = useState(false);
  const [cancel, setCancel] = useState(false);
  if (!me) return null;
  if (!s || (!participants(s).includes(me.id) && me.role !== "admin"))
    return <Card><EmptyState icon={Lock} title="Session not available" text="Only participants can open this learning room." action={<Button href="/sessions">Back to sessions</Button>} /></Card>;

  const teacher = byId(s.teacherId);
  const learners = [s.learnerId, ...s.groupIds].map(byId).filter(Boolean);
  const isTeacher = me.id === s.teacherId;
  const ts = timeState(s, now);
  const feedback = db.feedback.find((f) => f.sessionId === s.id);
  const canSeeFeedback = feedback && (isTeacher || me.id === feedback.learnerId);
  const run = (r: { ok: boolean; error?: string }, m: string) => toast(r.ok ? m : r.error!, r.ok ? "success" : "error");
  const active = s.status === "Accepted" || s.status === "Pending";

  return (
    <div className="space-y-6">
      <Link href="/sessions" className="inline-flex items-center gap-1 text-sm font-semibold text-subtle hover:text-navy"><ArrowLeft className="h-4 w-4" /> Sessions</Link>
      <Card className={cn("relative overflow-hidden", s.status === "Accepted" && ts.kind === "live" && "glow-live")}>
        <span aria-hidden className="pink-orb pointer-events-none absolute -top-14 -right-10 h-32 w-32 rounded-full opacity-30" />
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-xs font-bold tracking-[0.14em] text-teal-strong uppercase">Learning room</p>
            <h1 className="mt-1 text-2xl font-extrabold text-navy sm:text-3xl">{s.skill}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Badge tone={statusTone[s.status]}>{s.status}</Badge>
              <Badge tone="navy">{s.mode} · {s.format}</Badge>
              {s.mentorship && <Badge tone="teal">Mentorship</Badge>}
              {active && <Badge tone={ts.kind === "live" ? "rose" : "neutral"}>{ts.label}</Badge>}
            </div>
            <p className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-subtle">
              <span className="inline-flex items-center gap-1.5"><CalendarClock className="h-4 w-4" /> {fmtDate(s)}, {fmtTime(s)} · {s.duration} min</span>
              <span className="inline-flex items-center gap-1.5">{s.mode === "Online" ? <MonitorSmartphone className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}{s.mode === "Online" ? (s.meetingLink ? "Meeting link set" : "No meeting link yet") : s.location || "Location not set"}</span>
            </p>
            {s.status === "Accepted" && s.completedBy.length > 0 && <p className="mt-2 text-sm font-semibold text-teal-strong">Completion confirmed by {s.completedBy.map((x) => byId(x)?.name.split(" ")[0]).join(" & ")}. Both teacher and learner must confirm.</p>}
            {s.note && <p className="mt-2 text-sm text-subtle">{s.note}</p>}
          </div>
          {participants(s).includes(me.id) && <SessionActions session={s} onReschedule={() => setResched(true)} onCancel={() => setCancel(true)} />}
        </div>
        {s.mode === "Online" && s.meetingLink && s.status === "Accepted" && (
          <a href={s.meetingLink} target="_blank" rel="noreferrer" className="relative mt-5 inline-flex items-center gap-2 rounded-xl bg-navy px-5 py-3 font-semibold text-white shadow-[0_0_24px_2px_rgb(246_201_204/.7)] hover:bg-navy-600"><ExternalLink className="h-4 w-4" /> Join meeting (external link)</a>
        )}
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><Target className="h-4 w-4 text-teal-strong" /> Learning objective</h2>
            <p className="mt-2 text-ink">{s.objective || "No objective set."}</p>
            {s.message && <p className="mt-3 neu-inset rounded-xl p-3 text-sm text-subtle">“{s.message}”</p>}
          </Card>
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><NotebookPen className="h-4 w-4 text-teal-strong" /> Shared notes</h2>
            <Textarea className="mt-3" rows={5} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Agenda, key points, homework… visible to all participants." maxLength={3000} />
            <Button size="sm" className="mt-3" onClick={() => run(updateRoom(s.id, { notes }), "Notes saved.")}>Save notes</Button>
          </Card>
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><Link2 className="h-4 w-4 text-teal-strong" /> Shared resources</h2>
            <ul className="mt-3 space-y-2">{s.resources.map((r) => <li key={r.id}><a href={r.url} target="_blank" rel="noreferrer" className="font-semibold text-teal-strong hover:underline">{r.title}</a><span className="text-xs text-subtle"> · added by {byId(r.addedBy)?.name.split(" ")[0]}</span></li>)}</ul>
            {!s.resources.length && <p className="mt-2 text-sm text-subtle">No resources yet. Share only material you have permission to share.</p>}
            <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_1.3fr_auto]">
              <Input placeholder="Title" value={res.title} onChange={(e) => setRes({ ...res, title: e.target.value })} aria-label="Resource title" />
              <Input placeholder="https://…" value={res.url} onChange={(e) => setRes({ ...res, url: e.target.value })} aria-label="Resource link" />
              <Button variant="secondary" onClick={() => { const r = addSessionResource(s.id, res.title, res.url); run(r, "Resource shared."); if (r.ok) setRes({ title: "", url: "" }); }}><Plus className="h-4 w-4" /> Add</Button>
            </div>
          </Card>
          {isTeacher && (
            <Card>
              <h2 className="font-bold text-navy">{s.mode === "Online" ? "Meeting link" : "Meeting location"}</h2>
              <p className="mt-1 text-sm text-subtle">{s.mode === "Online" ? "Paste a Google Meet, Zoom or Teams link. PeerUp doesn't host video calls." : "Pick a safe, public place like the library or a department lab."}</p>
              <div className="mt-3 flex gap-2">
                {s.mode === "Online" ? <Input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://meet.google.com/…" aria-label="Meeting link" /> : <Input value={loc} onChange={(e) => setLoc(e.target.value)} placeholder="e.g. Central Library, Room 2" aria-label="Location" />}
                <Button onClick={() => run(updateRoom(s.id, s.mode === "Online" ? { meetingLink: link.trim() || undefined } : { location: loc.trim() || undefined }), "Saved.")}>Save</Button>
              </div>
            </Card>
          )}
          {s.status === "Completed" && (isTeacher || canSeeFeedback) && (
            <Card id="feedback">
              <h2 className="font-bold text-navy">Learner feedback</h2>
              <p className="mt-1 text-sm text-subtle">Feedback from the teacher about the learner's effort and progress. It's kept separate from public ratings and never affects anyone's trust score.</p>
              {feedback ? (
                (canSeeFeedback || !feedback.private) && (
                  <div className="mt-4 neu-inset rounded-2xl p-4">
                    {feedback.progress ? <p className="text-sm font-semibold text-navy">Progress: {feedback.progress}/5</p> : null}
                    <p className="mt-1 text-ink">{feedback.comment}</p>
                    {feedback.suggestions && <p className="mt-2 text-sm text-subtle"><b>Next steps:</b> {feedback.suggestions}</p>}
                    <p className="mt-2 text-xs text-subtle">{feedback.private ? "Private: only teacher and learner can see this." : "Shared"}</p>
                  </div>
                )
              ) : isTeacher ? (
                <form className="mt-4 space-y-3" onSubmit={(e) => { e.preventDefault(); const r = submitFeedback(s.id, { progress: fb.progress || undefined, comment: fb.comment, suggestions: fb.suggestions, private: fb.private }); if (!r.ok) return setFbErr(r.error); toast("Feedback sent to the learner."); }}>
                  <StarInput label="Learning progress (optional)" value={fb.progress} onChange={(v) => setFb({ ...fb, progress: v })} />
                  <Field label="Feedback on participation and effort" htmlFor="fb-c"><Textarea id="fb-c" rows={3} value={fb.comment} onChange={(e) => setFb({ ...fb, comment: e.target.value })} /></Field>
                  <Field label="Improvement suggestions" htmlFor="fb-s"><Textarea id="fb-s" rows={2} value={fb.suggestions} onChange={(e) => setFb({ ...fb, suggestions: e.target.value })} /></Field>
                  <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={fb.private} onChange={(e) => setFb({ ...fb, private: e.target.checked })} /> Keep private between us</label>
                  {fbErr && <p className="text-sm font-semibold text-rose" role="alert">{fbErr}</p>}
                  <Button type="submit">Send feedback</Button>
                </form>
              ) : null}
            </Card>
          )}
        </div>
        <div className="space-y-6">
          <Card>
            <h2 className="font-bold text-navy">Teacher</h2>
            {teacher && <Link href={`/profile/${teacher.id}`} className="mt-3 flex items-center gap-3"><Avatar name={teacher.name} src={teacher.avatar} size={44} /><span><span className="flex items-center gap-2 font-bold text-navy">{teacher.name}{teacher.sample && <SampleTag />}</span><span className="text-xs text-subtle">{teacher.department} · {yearLabel(teacher.year)}</span></span></Link>}
          </Card>
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><Users className="h-4 w-4" /> Learner{learners.length > 1 ? "s" : ""}</h2>
            <ul className="mt-3 space-y-3">{learners.map((l) => l && <li key={l.id}><Link href={`/profile/${l.id}`} className="flex items-center gap-3"><Avatar name={l.name} src={l.avatar} size={40} className="ring-2" /><span><span className="block font-bold text-navy">{l.name}</span><span className="text-xs text-subtle">{l.department} · {yearLabel(l.year)}</span></span></Link></li>)}</ul>
          </Card>
          {participants(s).includes(me.id) && <Button variant="secondary" className="w-full" href={`/messages?with=${isTeacher ? s.learnerId : s.teacherId}`}>Message {isTeacher ? "learner" : "teacher"}</Button>}
        </div>
      </div>
      <RescheduleModal session={s} open={resched} onClose={() => setResched(false)} />
      <CancelModal session={s} open={cancel} onClose={() => setCancel(false)} />
    </div>
  );
}
