"use client";

import React, { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

/*
 * Animated noise-mesh background (WebGL2), adapted for PeerUp:
 *  - palette: soft ivory → lavender → peach instead of deep blues, so it sits
 *    almost invisibly behind the neumorphic UI
 *  - performance: 4 fbm octaves (was 10), rendered at 1/3 resolution and
 *    stretched by CSS (the softness is the point), ~24 fps cap, paused when
 *    the tab is hidden, a single still frame for prefers-reduced-motion
 *  - the animation loop is cancelled on unmount (the original leaked it)
 */

const ZOOM_FACTOR = 0.3;
const BASE_WAVE_AMPLITUDE = 0.2;
const RANDOM_WAVE_FACTOR = 0.15;
const WAVE_FREQUENCY = 4.0;
const TIME_FACTOR = 0.2; // a little slower than the original 0.25, but clearly moving
const BASE_SWIRL_STRENGTH = 1.0;
const SWIRL_TIME_MULT = 5.0;
const NOISE_SWIRL_FACTOR = 0.2;
const FBM_OCTAVES = 4;
const RESOLUTION_SCALE = 1 / 3;
const FRAME_INTERVAL_MS = 1000 / 24;

/**
 * 20 steps in the PeerUp theme: page base (index 0 = transparent) → soft indigo →
 * violet → baby pink. Deep enough that the motion reads, still pastel.
 */
const STOPS: [number, number, number][] = [
  [0.925, 0.937, 0.965], // page base #eceff6
  [0.80, 0.82, 0.97],    // soft indigo #ccd1f7
  [0.73, 0.69, 0.96],    // violet #bab0f5
  [0.96, 0.78, 0.80],    // baby pink #f5c7cc
];
const palette: [number, number, number][] = Array.from({ length: 20 }, (_, i) => {
  const t = (i / 19) * (STOPS.length - 1);
  const k = Math.min(STOPS.length - 2, Math.floor(t));
  const f = t - k;
  return [0, 1, 2].map((c) => +(STOPS[k][c] + (STOPS[k + 1][c] - STOPS[k][c]) * f).toFixed(3)) as [number, number, number];
});

function buildFragmentShader(): string {
  const colorArraySrc = palette.map((c) => `vec3(${c[0]}, ${c[1]}, ${c[2]})`).join(",\n  ");
  return `#version 300 es
precision mediump float;
out vec4 outColor;
uniform vec2 uResolution;
uniform float uTime;
#define NUM_COLORS 20
vec3 seaColors[NUM_COLORS] = vec3[](
  ${colorArraySrc}
);

vec3 permute(vec3 x) { return mod(((x * 34.0) + 1.0) * x, 289.0); }

float noise2D(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy), dot(x12.zw, x12.zw)), 0.0);
  m = m * m; m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.792843 - 0.853734 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}

float fbm(vec2 st) {
  float value = 0.0, amplitude = 0.5, freq = 1.0;
  for (int i = 0; i < ${Math.floor(FBM_OCTAVES)}; i++) { value += amplitude * noise2D(st * freq); freq *= 2.0; amplitude *= 0.5; }
  return value;
}

void main() {
  vec2 uv = (gl_FragCoord.xy / uResolution.xy) * 2.0 - 1.0;
  uv.x *= uResolution.x / uResolution.y;
  uv *= float(${ZOOM_FACTOR});
  float t = uTime * float(${TIME_FACTOR});
  float waveAmp = float(${BASE_WAVE_AMPLITUDE}) + float(${RANDOM_WAVE_FACTOR}) * noise2D(vec2(t, 27.7));
  uv.x += waveAmp * sin(uv.y * float(${WAVE_FREQUENCY}) + t);
  uv.y += waveAmp * sin(uv.x * float(${WAVE_FREQUENCY}) - t);
  float r = length(uv);
  float angle = atan(uv.y, uv.x);
  angle += float(${BASE_SWIRL_STRENGTH}) * (1.0 - smoothstep(0.0, 1.0, r)) * sin(uTime * 0.5 + r * float(${SWIRL_TIME_MULT}));
  uv = vec2(cos(angle), sin(angle)) * r;
  float n = fbm(uv);
  n += float(${NOISE_SWIRL_FACTOR}) * sin(t + n * 3.0);
  float idx = clamp(0.5 * (n + 1.0), 0.0, 1.0) * float(NUM_COLORS - 1);
  int iLow = int(floor(idx));
  int iHigh = int(min(float(iLow + 1), float(NUM_COLORS - 1)));
  vec3 color = mix(seaColors[iLow], seaColors[iHigh], fract(idx));
  outColor = (iLow == 0 && iHigh == 0) ? vec4(color, 0.0) : vec4(color, 1.0);
}
`;
}

const vertexShaderSource = `#version 300 es
precision mediump float;
in vec2 aPosition;
void main() { gl_Position = vec4(aPosition, 0.0, 1.0); }`;

function createShaderProgram(gl: WebGL2RenderingContext, vsSource: string, fsSource: string): WebGLProgram | null {
  const compile = (type: number, src: string) => {
    const sh = gl.createShader(type);
    if (!sh) return null;
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.error("Shader error:", gl.getShaderInfoLog(sh));
      gl.deleteShader(sh);
      return null;
    }
    return sh;
  };
  const vs = compile(gl.VERTEX_SHADER, vsSource);
  const fs = vs && compile(gl.FRAGMENT_SHADER, fsSource);
  if (!vs || !fs) return null;
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  gl.deleteShader(vs);
  gl.deleteShader(fs);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error("Could not link WebGL program:", gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }
  return program;
}

export default function WavyBackground({ children, className, canvasClassName }: { children?: React.ReactNode; className?: string; canvasClassName?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext("webgl2", { alpha: true, antialias: false, powerPreference: "low-power", premultipliedAlpha: false });
    if (!gl) return; // no WebGL2: the plain page background shows instead

    const program = createShaderProgram(gl, vertexShaderSource, buildFragmentShader());
    if (!program) return;
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.clearColor(0, 0, 0, 0);
    gl.useProgram(program);

    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(program, "aPosition");
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    const uRes = gl.getUniformLocation(program, "uResolution");
    const uTime = gl.getUniformLocation(program, "uTime");

    const size = () => {
      const w = Math.max(1, Math.round(canvas.clientWidth * RESOLUTION_SCALE));
      const h = Math.max(1, Math.round(canvas.clientHeight * RESOLUTION_SCALE));
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
        gl.viewport(0, 0, w, h);
      }
    };
    const start = performance.now();
    const draw = (now: number) => {
      size();
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uTime, (now - start) * 0.001 + 8); // start mid-motion, not at a symmetric t=0
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    };

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let last = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      if (document.hidden || now - last < FRAME_INTERVAL_MS) return;
      last = now;
      draw(now);
    };
    if (reduced) draw(performance.now());
    else raf = requestAnimationFrame(loop);

    const onResize = () => reduced && draw(performance.now());
    window.addEventListener("resize", onResize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      gl.deleteProgram(program);
      gl.deleteBuffer(vbo);
      gl.deleteVertexArray(vao);
    };
  }, []);

  return (
    <div className={cn("relative w-full overflow-hidden", className)}>
      <canvas ref={canvasRef} aria-hidden className={cn("absolute inset-0 h-full w-full", canvasClassName)} style={{ background: "transparent" }} />
      {children}
    </div>
  );
}
