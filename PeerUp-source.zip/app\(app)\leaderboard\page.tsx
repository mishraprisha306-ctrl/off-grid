"use client";
import { motion } from "framer-motion";
import { Crown, Info, Trophy } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { SampleTag } from "@/components/domain";
import { Avatar, Button, Card, EmptyState, MentorBadge, Modal, PageHeader, Select, Stars, Tabs, cn } from "@/components/ui";
import { TRUST_RULES, isMentor, participants, ratingSummary, trustScore, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FIELDS, type Student } from "@/lib/types";

type Cat = "teachers" | "mentors" | "rated" | "trust" | "learners";
const CATS: { value: Cat; label: string; metric: string }[] = [
  { value: "teachers", label: "Top Peer Teachers", metric: "Ranked by trust score, then rating, then sessions" },
  { value: "mentors", label: "Top Senior Mentors", metric: "Senior Mentors ranked by trust score" },
  { value: "rated", label: "Top Rated", metric: `Average rating, min ${TRUST_RULES.minReviews} reviews (ties → more reviews)` },
  { value: "trust", label: "Highest Trust", metric: "Established trust scores only" },
  { value: "learners", label: "Most Active Learners", metric: "Completed sessions attended as a learner" },
];

export default function Leaderboard() {
  const { db, me } = useStore();
  const [cat, setCat] = useState<Cat>("teachers");
  const [period, setPeriod] = useState("overall");
  const [skill, setSkill] = useState("");
  const [field, setField] = useState("");
  const [branch, setBranch] = useState("");
  const [college, setCollege] = useState("");
  const [how, setHow] = useState(false);
  const since = period === "week" ? Date.now() - 7 * 864e5 : period === "month" ? Date.now() - 30 * 864e5 : undefined;

  const rows = useMemo(() => {
    const pool = db.students.filter((s) => s.role !== "admin" && !s.suspended && (!field || s.field === field) && (!branch || s.department === branch) && (!college || s.college === college) && (!skill || s.teach.some((t) => t.name === skill)));
    const reviews = skill ? db.reviews.filter((r) => r.skill === skill) : db.reviews;
    const sessions = skill ? db.sessions.filter((s) => s.skill === skill) : db.sessions;
    return pool.map((s) => {
      const t = trustScore(s.id, { sessions, reviews }, since);
      const r = ratingSummary(s.id, reviews, { since });
      const learned = db.sessions.filter((x) => x.status === "Completed" && participants(x).includes(s.id) && x.teacherId !== s.id && (!since || new Date(`${x.date}T${x.time}`).getTime() >= since)).length;
      return { s, t, r, learned };
    }).filter((x) => {
      if (cat === "learners") return x.learned > 0;
      if (cat === "mentors") return isMentor(x.s, db) && x.t.verified;
      if (cat === "rated") return x.r.count >= TRUST_RULES.minReviews;
      if (cat === "trust") return x.t.established;
      return x.t.verified;
    }).sort((a, b) => {
      // deterministic tie-breaks: metric → secondary metric → reviews → name
      if (cat === "learners") return b.learned - a.learned || a.s.name.localeCompare(b.s.name);
      if (cat === "rated") return (b.r.average ?? 0) - (a.r.average ?? 0) || b.r.count - a.r.count || a.s.name.localeCompare(b.s.name);
      return b.t.total - a.t.total || (b.t.average ?? 0) - (a.t.average ?? 0) || b.t.completedTeaching - a.t.completedTeaching || a.s.name.localeCompare(b.s.name);
    });
  }, [db, cat, since, field, branch, college, skill]);

  const allSkills = [...new Set(db.students.flatMap((s) => s.teach.map((t) => t.name)))].sort();
  const branches = [...new Set(db.students.map((s) => s.department))].sort();
  const colleges = [...new Set(db.students.filter((s) => s.role !== "admin").map((s) => s.college))].sort();
  const metric = (x: (typeof rows)[number]) => cat === "learners" ? `${x.learned} sessions` : cat === "rated" ? `${x.r.average?.toFixed(2)}★` : `${x.t.total}`;
  const podium = rows.slice(0, 3);
  const order = [1, 0, 2].filter((i) => podium[i]);
  const myRank = me ? rows.findIndex((x) => x.s.id === me.id) : -1;

  return (
    <div>
      <PageHeader title="Leaderboard" subtitle="Recognising students who make learning better for everyone. Built from real, eligible data only." action={<Button variant="secondary" onClick={() => setHow(true)}><Info className="h-4 w-4" /> Ranking rules</Button>} />
      <div className="mb-4"><Tabs value={cat} onChange={setCat} tabs={CATS.map((c) => ({ value: c.value, label: c.label }))} /></div>
      <Card className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-5">
        <Select value={period} onChange={(e) => setPeriod(e.target.value)} aria-label="Period"><option value="overall">Overall</option><option value="month">This month</option><option value="week">This week</option></Select>
        <Select value={skill} onChange={(e) => setSkill(e.target.value)} aria-label="Skill"><option value="">All skills</option>{allSkills.map((s) => <option key={s}>{s}</option>)}</Select>
        <Select value={field} onChange={(e) => setField(e.target.value)} aria-label="Field"><option value="">All fields</option>{FIELDS.map((f) => <option key={f}>{f}</option>)}</Select>
        <Select value={branch} onChange={(e) => setBranch(e.target.value)} aria-label="Branch"><option value="">All branches</option>{branches.map((b) => <option key={b}>{b}</option>)}</Select>
        <Select value={college} onChange={(e) => setCollege(e.target.value)} aria-label="College"><option value="">All colleges</option>{colleges.map((c) => <option key={c}>{c}</option>)}</Select>
      </Card>
      <p className="mb-6 text-sm text-subtle">{CATS.find((c) => c.value === cat)!.metric}.{myRank >= 0 && <b className="text-navy"> You're #{myRank + 1}.</b>}</p>
      {!rows.length ? (
        <Card><EmptyState icon={Trophy} title="No one ranked here yet" text="Rankings only include students with eligible completed sessions and ratings in this period." /></Card>
      ) : (
        <>
          <div className="mb-10 grid grid-cols-3 items-end gap-3 sm:gap-6">
            {order.map((i) => {
              const x = podium[i];
              return (
                <motion.div key={x.s.id} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.12 }} className="flex flex-col items-center text-center">
                  {i === 0 && <Crown className="mb-1 h-7 w-7 text-amber drop-shadow-[0_0_8px_rgb(246_201_204/1)]" />}
                  <Link href={`/profile/${x.s.id}`}><Avatar name={x.s.name} src={x.s.avatar} size={i === 0 ? 76 : 60} /></Link>
                  <p className="mt-2 max-w-full truncate text-sm font-bold text-navy sm:text-base">{x.s.name}</p>
                  <p className="text-xs text-subtle">{x.s.department}</p>
                  <div className={cn("mt-3 flex w-full flex-col items-center rounded-[18px] pt-4", ["h-44 sm:h-56", "h-36 sm:h-44", "h-28 sm:h-36"][i], i === 0 ? "bg-navy text-white shadow-[0_18px_44px_-10px_rgb(240_170_170/.85)]" : "neu")}>
                    <span className={cn("text-3xl font-extrabold", i === 0 ? "text-white" : "text-navy")}>{i + 1}</span>
                    <span className={cn("mt-1 text-xs font-semibold", i === 0 ? "text-white/70" : "text-subtle")}>{metric(x)}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
          <Card className="hidden overflow-x-auto p-0 md:block">
            <table className="w-full text-left text-sm">
              <thead className="text-xs tracking-wide text-muted uppercase"><tr><th className="px-6 py-4">Rank</th><th className="px-3 py-4">Student</th><th className="px-3 py-4">Skills</th><th className="px-3 py-4">Rating</th><th className="px-3 py-4">Trust</th><th className="px-3 py-4">Sessions</th><th className="px-6 py-4" /></tr></thead>
              <tbody>
                {rows.map((x, i) => (
                  <tr key={x.s.id} className={cn("border-t border-line", x.s.id === me?.id && "bg-blush-soft/50")}>
                    <td className="px-6 py-4 font-extrabold text-navy">#{i + 1}</td>
                    <td className="px-3 py-4"><div className="flex items-center gap-3"><Avatar name={x.s.name} src={x.s.avatar} size={36} className="ring-2" /><div><p className="flex items-center gap-2 font-bold text-navy">{x.s.name}{x.s.id === me?.id && " (you)"}{x.s.sample && <SampleTag />}</p><p className="text-xs text-subtle">{x.s.field} · {x.s.department} · {yearLabel(x.s.year)}</p></div>{isMentor(x.s, db) && <MentorBadge small />}</div></td>
                    <td className="max-w-[180px] truncate px-3 py-4 text-xs text-subtle">{x.s.teach.map((t) => t.name).join(", ")}</td>
                    <td className="px-3 py-4"><Stars value={x.r.average} size={12} showValue count={x.r.count} /></td>
                    <td className="px-3 py-4 font-bold text-navy">{x.t.established ? x.t.total : <span className="text-xs font-semibold text-subtle">New</span>}</td>
                    <td className="px-3 py-4 font-semibold">{cat === "learners" ? x.learned : x.t.completedTeaching}</td>
                    <td className="px-6 py-4 text-right"><Button size="sm" variant="ghost" href={`/profile/${x.s.id}`}>View profile</Button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <ul className="space-y-3 md:hidden">
            {rows.map((x, i) => (
              <li key={x.s.id}>
                <Link href={`/profile/${x.s.id}`} className={cn("neu flex items-center gap-3 p-4", x.s.id === me?.id && "ring-2 ring-blush")}>
                  <span className="w-7 font-extrabold text-navy">#{i + 1}</span>
                  <Avatar name={x.s.name} src={x.s.avatar} size={38} className="ring-2" />
                  <span className="min-w-0 flex-1"><span className="block truncate font-bold text-navy">{x.s.name}</span><span className="block text-xs text-subtle">★ {x.r.average?.toFixed(1) ?? "-"} · {x.t.completedTeaching} taught</span></span>
                  <span className="rounded-xl bg-navy px-2.5 py-1.5 text-sm font-extrabold text-white">{metric(x)}</span>
                </Link>
              </li>
            ))}
          </ul>
        </>
      )}
      <Modal open={how} onClose={() => setHow(false)} title="How rankings work">
        <div className="space-y-3 text-sm text-ink">
          <p>Rankings use only eligible data: completed sessions and ratings from their learners. Popularity (connections, profile views) never counts.</p>
          <p><b>Ties</b> are broken consistently: the main metric, then average rating, then completed sessions, then name alphabetically.</p>
          <p><b>Weekly / Monthly</b> recompute ratings and sessions using only that window.</p>
          <p><b>By skill</b> uses only that skill's sessions and reviews.</p>
          <p className="text-subtle">Trust score formula: see the <Link href="/trust" className="font-semibold text-teal-strong">Trust Score</Link> page.</p>
        </div>
      </Modal>
    </div>
  );
}
