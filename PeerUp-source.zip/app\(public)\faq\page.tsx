"use client";
import { ChevronDown } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { PublicPage } from "@/components/public-chrome";
import { cn } from "@/components/ui";
import { FAQS } from "@/lib/content";


export default function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <PublicPage title="Frequently Asked Questions" subtitle="How PeerUp works, in plain words.">
      <div className="divide-y divide-line rounded-[20px] bg-ivory shadow-[var(--shadow-raised)]">
        {FAQS.map(([q, a], i) => (
          <div key={q}>
            <button onClick={() => setOpen(open === i ? -1 : i)} className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-bold text-navy" aria-expanded={open === i}>
              {q}<ChevronDown className={cn("h-4 w-4 shrink-0 transition-transform", open === i && "rotate-180")} />
            </button>
            {open === i && <p className="px-6 pb-5 text-subtle">{a}</p>}
          </div>
        ))}
      </div>
      <p className="text-subtle">Still stuck? <Link href="/contact" className="font-bold text-teal-strong hover:underline">Contact us</Link>.</p>
    </PublicPage>
  );
}
