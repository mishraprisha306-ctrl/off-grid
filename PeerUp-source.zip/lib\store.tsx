"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { auth, isSupabaseConfigured } from "./auth";
import { overlaps, participants, sessionStart } from "./engines";
import { blankStudent, buildSeed, DB_VERSION } from "./seed";
import type {
  AppSettings, Certificate, DB, LearnerFeedback, Notification, Progress, RatingSet, Report, Resource, Session, SessionFormat, SessionMode, Student,
} from "./types";

/* ------------------------------------------------------------------
 * Data adapter. In demo mode everything persists in localStorage.
 * supabase/schema.sql mirrors these collections table-for-table with RLS.
 * ------------------------------------------------------------------ */
const DB_KEY = "prapp.db.v2";
const AUTH_KEY = "prapp.auth.v2";
export const repo = {
  load(): DB {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (raw) {
        const db = JSON.parse(raw) as DB;
        if (db.version === DB_VERSION) return db;
      }
    } catch {}
    return repo.reset();
  },
  save(db: DB) {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(db));
    } catch {
      // quota (e.g. large avatars), surface instead of silently pretending
      throw new Error("Storage is full. Try a smaller profile picture.");
    }
  },
  reset(): DB {
    const seed = buildSeed();
    localStorage.setItem(DB_KEY, JSON.stringify(seed));
    return seed;
  },
};

export async function hashPassword(pw: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`pwr::${pw}`));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const uid = (p: string) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
const nowIso = () => new Date().toISOString();
const EDIT_WINDOW_MS = 7 * 24 * 3600_000;

export type Result = { ok: true; id?: string; info?: string } | { ok: false; error: string };
const fail = (error: string): Result => ({ ok: false, error });

export interface SessionRequest {
  otherId: string;
  role: "learn" | "teach";
  skill: string;
  date: string;
  time: string;
  duration: number;
  mode: SessionMode;
  format: SessionFormat;
  groupIds?: string[];
  objective: string;
  message?: string;
  mentorship?: boolean;
}
export interface SignupData {
  name: string; email: string; password: string; college: string; field: Student["field"]; department: string; year: number; studentId?: string;
}

interface Store {
  ready: boolean;
  now: number;
  db: DB;
  me: Student | null;
  supabase: boolean;
  byId: (id: string) => Student | undefined;
  // auth
  login: (email: string, pw: string) => Promise<Result>;
  signup: (d: SignupData) => Promise<Result>;
  loginWithGoogle: () => Promise<Result>;
  resetPassword: (email: string) => Promise<Result>;
  changePassword: (cur: string, next: string) => Promise<Result>;
  logout: () => Promise<void>;
  deleteAccount: () => Result;
  // profile
  updateMe: (patch: Partial<Student>) => Result;
  requestMentorBadge: () => Result;
  // connections
  connect: (otherId: string) => Result;
  respondConnection: (id: string, accept: boolean) => Result;
  cancelConnection: (id: string) => Result;
  connectionWith: (otherId: string) => DB["connections"][number] | undefined;
  block: (otherId: string) => Result;
  unblock: (otherId: string) => Result;
  // sessions
  requestSession: (r: SessionRequest) => Result;
  respondSession: (id: string, accept: boolean) => Result;
  cancelSession: (id: string) => Result;
  rescheduleSession: (id: string, date: string, time: string) => Result;
  /** `as` is only used by the demo-mode peer simulation */
  completeSession: (id: string, as?: string) => Result;
  simulatePeer: (id: string) => Result;
  updateRoom: (id: string, patch: Partial<Pick<Session, "notes" | "meetingLink" | "location" | "objective">>) => Result;
  addSessionResource: (id: string, title: string, url: string) => Result;
  // ratings
  submitReview: (sessionId: string, stars: number, ratings: RatingSet, qualities: string[], comment: string) => Result;
  editReview: (id: string, stars: number, comment: string) => Result;
  toggleHelpful: (id: string) => Result;
  submitFeedback: (sessionId: string, f: Pick<LearnerFeedback, "progress" | "comment" | "suggestions" | "private">) => Result;
  // community
  sendMessage: (toId: string, text: string) => Result;
  canMessage: (otherId: string) => { ok: boolean; reason?: string };
  readConversation: (otherId: string) => void;
  markRead: (id?: string) => void;
  report: (targetType: Report["targetType"], targetId: string, reason: string) => Result;
  submitSupport: (d: { name: string; email: string; subject: string; message: string }) => Result;
  // learning
  addResource: (r: Omit<Resource, "id" | "ownerId" | "createdAt">) => Result;
  removeResource: (id: string) => Result;
  saveProgress: (p: Omit<Progress, "id" | "userId" | "updatedAt"> & { id?: string }) => Result;
  removeProgress: (id: string) => Result;
  joinChallenge: (challengeId: string) => Result;
  toggleChallengeDay: (joinId: string, day: number) => Result;
  leaveChallenge: (joinId: string) => Result;
  addCertificate: (c: Omit<Certificate, "id" | "status">) => Result;
  removeCertificate: (id: string) => Result;
  // admin
  admin: {
    setSuspended: (userId: string, suspended: boolean) => Result;
    resolveReport: (id: string, status: "resolved" | "dismissed") => Result;
    mentorDecision: (userId: string, decision: "approved" | "rejected" | "none") => Result;
    verifyCertificate: (userId: string, certId: string, verified: boolean) => Result;
    addCategory: (name: string) => Result;
    removeCategory: (name: string) => Result;
    closeSupport: (id: string) => Result;
    deleteReview: (id: string) => Result;
    deleteMessage: (id: string) => Result;
  };
  updateSettings: (patch: Partial<AppSettings>) => void;
  resetDemo: () => void;
}

const Ctx = createContext<Store | null>(null);
const EMPTY: DB = { version: DB_VERSION, students: [], sessions: [], reviews: [], feedback: [], connections: [], messages: [], notifications: [], reports: [], support: [], audit: [], resources: [], progress: [], challenges: [], settings: { mentorMinYear: 3, mentorMinSessions: 3, mentorMinRating: 4, skillCategories: [], notify: { sessions: true, connections: true, reviews: true, messages: true, matches: true } } };

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [db, setDb] = useState<DB>(EMPTY);
  const [meId, setMeId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const dbRef = useRef(db);
  dbRef.current = db;

  const commit = useCallback((fn: (d: DB) => DB | void): Result => {
    const copy = structuredClone(dbRef.current);
    const next = fn(copy) ?? copy;
    try {
      repo.save(next);
    } catch (e) {
      return fail((e as Error).message);
    }
    dbRef.current = next;
    setDb(next);
    return { ok: true };
  }, []);

  /** Pending requests whose start time has passed are expired, never silently left pending. */
  const sweep = useCallback((d: DB, t: number) => {
    let changed = false;
    for (const s of d.sessions) {
      if (s.status === "Pending" && sessionStart(s).getTime() < t) {
        s.status = "Cancelled";
        s.note = "Expired. It wasn't confirmed before the start time.";
        s.updatedAt = new Date(t).toISOString();
        changed = true;
        for (const u of participants(s)) pushN(d, u, { kind: "session", text: `The ${s.skill} request for ${s.date} expired without confirmation.`, href: `/sessions/${s.id}` });
      }
      // reminder 60 min before an accepted session (once)
      const mins = (sessionStart(s).getTime() - t) / 60000;
      if (s.status === "Accepted" && mins > 0 && mins <= 60 && !d.notifications.some((n) => n.href === `/sessions/${s.id}` && n.text.startsWith("Reminder"))) {
        changed = true;
        for (const u of participants(s)) pushN(d, u, { kind: "session", text: `Reminder: ${s.skill} starts in ${Math.round(mins)} min.`, href: `/sessions/${s.id}` });
      }
    }
    return changed;
  }, []);

  useEffect(() => {
    const loaded = repo.load();
    setDb(loaded);
    dbRef.current = loaded;
    const stored = localStorage.getItem(AUTH_KEY);
    if (stored && loaded.students.some((s) => s.id === stored && !s.suspended)) setMeId(stored);
    // Supabase session (when configured) maps onto a local profile keyed by the auth user id
    if (isSupabaseConfigured) {
      auth.currentUser().then((u) => {
        if (!u) return;
        const d = structuredClone(dbRef.current);
        if (!d.students.some((s) => s.id === u.id)) {
          d.students.push(blankStudent({ id: u.id, name: u.name || u.email.split("@")[0], email: u.email, passwordHash: "", emailVerified: u.emailVerified, avatar: u.avatar }));
          repo.save(d);
          dbRef.current = d;
          setDb(d);
        }
        localStorage.setItem(AUTH_KEY, u.id);
        setMeId(u.id);
      });
    }
    setReady(true);
    const onStorage = (e: StorageEvent) => {
      if (e.key === DB_KEY && e.newValue) setDb(JSON.parse(e.newValue));
      if (e.key === AUTH_KEY) setMeId(e.newValue);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const tick = () => {
      const t = Date.now();
      setNow(t);
      const copy = structuredClone(dbRef.current);
      if (sweep(copy, t)) {
        dbRef.current = copy;
        repo.save(copy);
        setDb(copy);
      }
    };
    tick();
    const id = setInterval(tick, 30_000);
    const onVis = () => document.visibilityState === "visible" && tick();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [ready, sweep]);

  const me = useMemo(() => db.students.find((s) => s.id === meId) ?? null, [db.students, meId]);
  const byId = useCallback((id: string) => db.students.find((s) => s.id === id), [db.students]);
  const nameOf = (d: DB, id: string) => d.students.find((s) => s.id === id)?.name ?? "Someone";
  const audit = (d: DB, action: string) => me && d.audit.unshift({ id: uid("a"), adminId: me.id, action, createdAt: nowIso() });
  const isAdmin = () => me?.role === "admin";

  const findConn = (d: DB, a: string, b: string) => d.connections.find((c) => (c.fromId === a && c.toId === b) || (c.fromId === b && c.toId === a));

  const value: Store = {
    ready, now, db, me, byId, supabase: isSupabaseConfigured,

    /* ---------------- auth ---------------- */
    async login(email, pw) {
      const em = email.trim().toLowerCase();
      if (isSupabaseConfigured) {
        const r = await auth.signIn(em, pw);
        if (!r.ok) return r;
        const d = structuredClone(dbRef.current);
        if (!d.students.some((s) => s.id === r.user.id)) {
          d.students.push(blankStudent({ id: r.user.id, name: r.user.name || em.split("@")[0], email: em, passwordHash: "", emailVerified: r.user.emailVerified }));
          repo.save(d);
          dbRef.current = d;
          setDb(d);
        }
        localStorage.setItem(AUTH_KEY, r.user.id);
        setMeId(r.user.id);
        return { ok: true, id: r.user.id };
      }
      const s = dbRef.current.students.find((x) => x.email.toLowerCase() === em);
      if (!s) return fail("No account found with that email.");
      if ((await hashPassword(pw)) !== s.passwordHash) return fail("Incorrect password.");
      if (s.suspended) return fail("This account is suspended. Contact support.");
      localStorage.setItem(AUTH_KEY, s.id);
      setMeId(s.id);
      return { ok: true, id: s.id };
    },

    async signup(d) {
      const em = d.email.trim().toLowerCase();
      if (dbRef.current.students.some((x) => x.email.toLowerCase() === em)) return fail("An account with this email already exists. Sign in instead.");
      let id = uid("u");
      let verified = false;
      if (isSupabaseConfigured) {
        const r = await auth.signUp(em, d.password, d.name);
        if (!r.ok) return r;
        id = r.user.id;
        verified = r.user.emailVerified;
      }
      const passwordHash = isSupabaseConfigured ? "" : await hashPassword(d.password);
      const res = commit((db) => {
        db.students.push(blankStudent({ id, name: d.name.trim(), email: em, passwordHash, college: d.college.trim(), field: d.field, department: d.department.trim(), year: d.year, studentId: d.studentId?.trim() || undefined, emailVerified: verified }));
        pushN(db, id, { kind: "system", text: "Welcome to PeerUp! Finish onboarding to start getting matches.", href: "/onboarding" });
      });
      if (!res.ok) return res;
      if (isSupabaseConfigured && !verified) return { ok: true, id, info: "verify" };
      localStorage.setItem(AUTH_KEY, id);
      setMeId(id);
      return { ok: true, id };
    },

    async loginWithGoogle() {
      if (!isSupabaseConfigured) return fail("Google sign-in needs Supabase keys. Add them in .env.local (see README, Google OAuth).");
      return auth.google();
    },

    async resetPassword(email) {
      if (!/^\S+@\S+\.\S+$/.test(email)) return fail("Enter a valid email address.");
      if (!isSupabaseConfigured) return fail("Password-reset emails need Supabase keys (demo mode can't send email). Sample accounts use the password demo1234.");
      return auth.resetPassword(email);
    },

    async changePassword(cur, next) {
      if (!me) return fail("Not signed in.");
      if (next.length < 8 || !/\d/.test(next) || !/[A-Z]/.test(next) || !/[^A-Za-z0-9]/.test(next)) return fail("Use 8+ characters with an uppercase letter, a number and a symbol.");
      if (isSupabaseConfigured) return auth.updatePassword(next);
      if ((await hashPassword(cur)) !== me.passwordHash) return fail("Current password is incorrect.");
      const passwordHash = await hashPassword(next);
      return commit((d) => {
        d.students.find((s) => s.id === me.id)!.passwordHash = passwordHash;
      });
    },

    async logout() {
      if (isSupabaseConfigured) await auth.signOut();
      localStorage.removeItem(AUTH_KEY);
      setMeId(null);
    },

    deleteAccount() {
      if (!me) return fail("Not signed in.");
      if (me.role === "admin") return fail("Admin accounts can't be deleted from here.");
      const id = me.id;
      const r = commit((d) => {
        d.students = d.students.filter((s) => s.id !== id);
        d.connections = d.connections.filter((c) => c.fromId !== id && c.toId !== id);
        d.messages = d.messages.filter((m) => m.fromId !== id && m.toId !== id);
        d.notifications = d.notifications.filter((n) => n.userId !== id);
        d.progress = d.progress.filter((p) => p.userId !== id);
        d.challenges = d.challenges.filter((c) => c.userId !== id);
        d.resources = d.resources.filter((r) => r.ownerId !== id);
        // sessions & reviews stay as anonymised history for the other participant
        for (const s of d.sessions) if ((s.status === "Pending" || s.status === "Accepted") && participants(s).includes(id)) { s.status = "Cancelled"; s.note = "Participant deleted their account."; }
      });
      if (r.ok) {
        localStorage.removeItem(AUTH_KEY);
        setMeId(null);
      }
      return r;
    },

    /* ---------------- profile ---------------- */
    updateMe(patch) {
      if (!me) return fail("Not signed in.");
      if (patch.role && patch.role !== me.role) return fail("You can't change your own role.");
      if (patch.mentorStatus && patch.mentorStatus !== me.mentorStatus) return fail("Mentor status is set by the review process.");
      if (patch.email && dbRef.current.students.some((x) => x.id !== me.id && x.email.toLowerCase() === patch.email!.toLowerCase())) return fail("That email is used by another account.");
      if (patch.avatar && patch.avatar.length > 450_000) return fail("Profile picture is too large after compression.");
      const { role: _r, mentorStatus: _m, suspended: _s, ...safe } = patch;
      return commit((d) => {
        const s = d.students.find((x) => x.id === me.id)!;
        Object.assign(s, safe);
      });
    },

    requestMentorBadge() {
      if (!me) return fail("Not signed in.");
      if (me.mentorStatus === "pending") return fail("Your request is already under review.");
      return commit((d) => {
        d.students.find((s) => s.id === me.id)!.mentorStatus = "pending";
        d.students.filter((s) => s.role === "admin").forEach((a) => pushN(d, a.id, { kind: "mentor", text: `${me.name} requested Senior Mentor review.`, href: "/admin?tab=mentors" }));
      });
    },

    /* ---------------- connections ---------------- */
    connectionWith(otherId) {
      return me ? findConn(dbRef.current, me.id, otherId) : undefined;
    },
    connect(otherId) {
      if (!me) return fail("Not signed in.");
      if (otherId === me.id) return fail("You can't connect with yourself.");
      const other = byId(otherId);
      if (!other || other.suspended) return fail("This student isn't available.");
      if (me.blocked.includes(otherId) || other.blocked.includes(me.id)) return fail("You can't connect with this student.");
      if (findConn(dbRef.current, me.id, otherId)) return fail("A connection or request already exists.");
      return commit((d) => {
        const id = uid("c");
        d.connections.push({ id, fromId: me.id, toId: otherId, status: "Pending", createdAt: nowIso() });
        pushN(d, otherId, { kind: "connection", text: `${me.name} wants to connect with you.`, href: `/connections`, connectionId: id });
      });
    },
    respondConnection(id, accept) {
      const c = dbRef.current.connections.find((x) => x.id === id);
      if (!c || !me || c.toId !== me.id || c.status !== "Pending") return fail("Request no longer available.");
      return commit((d) => {
        if (accept) d.connections.find((x) => x.id === id)!.status = "Accepted";
        else d.connections = d.connections.filter((x) => x.id !== id);
        d.notifications = d.notifications.map((n) => (n.connectionId === id ? { ...n, connectionId: undefined, read: true } : n));
        pushN(d, c.fromId, { kind: "connection", text: `${me.name} ${accept ? "accepted" : "declined"} your connection request.`, href: `/connections` });
      });
    },
    cancelConnection(id) {
      const c = dbRef.current.connections.find((x) => x.id === id);
      if (!c || !me || (c.fromId !== me.id && c.toId !== me.id)) return fail("Connection not found.");
      return commit((d) => {
        d.connections = d.connections.filter((x) => x.id !== id);
        d.notifications = d.notifications.filter((n) => n.connectionId !== id);
      });
    },
    block(otherId) {
      if (!me || otherId === me.id) return fail("Can't block this account.");
      return commit((d) => {
        const s = d.students.find((x) => x.id === me.id)!;
        if (!s.blocked.includes(otherId)) s.blocked.push(otherId);
        d.connections = d.connections.filter((c) => !((c.fromId === me.id && c.toId === otherId) || (c.fromId === otherId && c.toId === me.id)));
        for (const x of d.sessions) if ((x.status === "Pending") && participants(x).includes(me.id) && participants(x).includes(otherId)) { x.status = "Cancelled"; x.note = "Cancelled because a participant was blocked."; }
      });
    },
    unblock(otherId) {
      if (!me) return fail("Not signed in.");
      return commit((d) => {
        const s = d.students.find((x) => x.id === me.id)!;
        s.blocked = s.blocked.filter((b) => b !== otherId);
      });
    },

    /* ---------------- sessions ---------------- */
    requestSession(r) {
      if (!me) return fail("Not signed in.");
      if (r.otherId === me.id) return fail("You can't book a session with yourself.");
      const other = byId(r.otherId);
      if (!other || other.suspended) return fail("This student isn't available.");
      if (me.blocked.includes(other.id) || other.blocked.includes(me.id)) return fail("You can't book with this student.");
      if (!r.skill) return fail("Choose a skill.");
      if (r.objective.trim().length < 5) return fail("Add a short learning objective (5+ characters).");
      if (!r.date || !r.time) return fail("Pick a date and time.");
      const start = new Date(`${r.date}T${r.time}:00`);
      if (start.getTime() < Date.now() + 5 * 60_000) return fail("Pick a time at least 5 minutes from now.");
      if (r.duration < 15 || r.duration > 240) return fail("Duration must be 15–240 minutes.");
      const teacherId = r.role === "learn" ? r.otherId : me.id;
      const learnerId = r.role === "learn" ? me.id : r.otherId;
      const dup = dbRef.current.sessions.find((s) => s.teacherId === teacherId && s.learnerId === learnerId && s.skill.toLowerCase() === r.skill.toLowerCase() && (s.status === "Pending" || s.status === "Accepted"));
      if (dup) return fail(`You already have ${dup.status === "Accepted" ? "an accepted" : "a pending"} ${r.skill} session with ${other.name}.`);
      const draft = { date: r.date, time: r.time, duration: r.duration } as Session;
      const clash = dbRef.current.sessions.find((s) => s.status === "Accepted" && (participants(s).includes(me.id) || participants(s).includes(other.id)) && overlaps(s, draft));
      if (clash) return fail(`That time clashes with an accepted ${clash.skill} session (${clash.time}). Pick another slot.`);
      const id = uid("s");
      const group = r.format === "Group" ? (r.groupIds ?? []).filter((g) => g !== teacherId && g !== learnerId) : [];
      const res = commit((d) => {
        d.sessions.push({
          id, teacherId, learnerId, groupIds: group, requesterId: me.id, awaitingId: r.otherId, skill: r.skill, date: r.date, time: r.time,
          duration: r.duration, mode: r.mode, format: r.format, mentorship: !!r.mentorship, objective: r.objective.trim(), message: r.message?.trim() || undefined,
          resources: [], status: "Pending", wasAccepted: false, completedBy: [], createdAt: nowIso(), updatedAt: nowIso(),
        });
        pushN(d, r.otherId, { kind: r.mentorship ? "mentor" : "session", text: `${me.name} requested ${r.mentorship ? "mentorship" : "a session"} for ${r.skill}.`, href: `/sessions/${id}` });
        group.forEach((g) => pushN(d, g, { kind: "session", text: `${me.name} added you to a group ${r.skill} session request.`, href: `/sessions/${id}` }));
      });
      return res.ok ? { ok: true, id } : res;
    },

    respondSession(id, accept) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me) return fail("Session not found.");
      if (s.status !== "Pending") return fail(`This session is already ${s.status.toLowerCase()}.`);
      if (s.awaitingId !== me.id) return fail("Only the invited participant can respond.");
      if (accept) {
        const clash = dbRef.current.sessions.find((x) => x.id !== s.id && x.status === "Accepted" && participants(x).includes(me.id) && overlaps(x, s));
        if (clash) return fail(`You already have ${clash.skill} at that time. Reschedule one of them.`);
      }
      return commit((d) => {
        const x = d.sessions.find((y) => y.id === id)!;
        x.status = accept ? "Accepted" : "Rejected";
        if (accept) x.wasAccepted = true;
        x.updatedAt = nowIso();
        participants(x).filter((p) => p !== me.id).forEach((p) =>
          pushN(d, p, { kind: x.mentorship ? "mentor" : "session", text: `${me.name} ${accept ? "accepted" : "declined"} the ${x.skill} ${x.mentorship ? "mentorship" : "session"} request.${accept ? ` Scheduled ${x.date} at ${x.time}.` : ""}`, href: `/sessions/${x.id}` }));
      });
    },

    simulatePeer(id) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me) return fail("Session not found.");
      const peer = s.teacherId === me.id ? s.learnerId : s.teacherId;
      if (isSupabaseConfigured) return fail("Simulation is only available in demo mode.");
      if (s.status === "Pending" && s.awaitingId === peer) {
        return commit((d) => {
          const x = d.sessions.find((y) => y.id === id)!;
          x.status = "Accepted";
          x.wasAccepted = true;
          x.updatedAt = nowIso();
          pushN(d, me.id, { kind: "session", text: `${nameOf(d, peer)} accepted the ${x.skill} session (demo simulation).`, href: `/sessions/${x.id}` });
        });
      }
      if (s.status === "Accepted" && s.completedBy.includes(me.id) && !s.completedBy.includes(peer)) {
        if (isSupabaseConfigured) return fail("Simulation is only available in demo mode.");
        return value.completeSession(id, peer);
      }
      return fail("Nothing to simulate for this session.");
    },

    cancelSession(id) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me || !participants(s).includes(me.id)) return fail("Session not found.");
      if (s.status !== "Pending" && s.status !== "Accepted") return fail("Only pending or accepted sessions can be cancelled.");
      return commit((d) => {
        const x = d.sessions.find((y) => y.id === id)!;
        x.status = "Cancelled";
        x.note = `Cancelled by ${me.name}.`;
        x.updatedAt = nowIso();
        participants(x).filter((p) => p !== me.id).forEach((p) => pushN(d, p, { kind: "session", text: `${me.name} cancelled the ${x.skill} session on ${x.date}.`, href: `/sessions/${x.id}` }));
      });
    },

    rescheduleSession(id, date, time) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me || !participants(s).includes(me.id)) return fail("Session not found.");
      if (s.status !== "Pending" && s.status !== "Accepted") return fail("Only pending or accepted sessions can be rescheduled.");
      if (new Date(`${date}T${time}:00`).getTime() < Date.now() + 5 * 60_000) return fail("Pick a time at least 5 minutes from now.");
      const draft = { ...s, date, time };
      const clash = dbRef.current.sessions.find((x) => x.id !== s.id && x.status === "Accepted" && participants(x).some((p) => participants(s).includes(p)) && overlaps(x, draft));
      if (clash) return fail(`That clashes with an accepted ${clash.skill} session.`);
      return commit((d) => {
        const x = d.sessions.find((y) => y.id === id)!;
        const other = x.teacherId === me.id ? x.learnerId : x.teacherId;
        x.date = date;
        x.time = time;
        x.status = "Pending";
        x.requesterId = me.id;
        x.awaitingId = other;
        x.completedBy = [];
        x.updatedAt = nowIso();
        participants(x).filter((p) => p !== me.id).forEach((p) => pushN(d, p, { kind: "session", text: `${me.name} proposed a new time for ${x.skill}: ${date} at ${time}.`, href: `/sessions/${x.id}` }));
      });
    },

    /** Completion needs BOTH teacher and learner to confirm after the start time, prevents fake completed sessions. */
    completeSession(id: string, as?: string) {
      const actor = as ?? me?.id;
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !actor) return fail("Session not found.");
      if (s.status !== "Accepted") return fail("Only accepted sessions can be marked completed.");
      if (actor !== s.teacherId && actor !== s.learnerId) return fail("Only the teacher or lead learner can confirm completion.");
      if (sessionStart(s).getTime() > Date.now()) return fail("You can confirm completion once the session has started.");
      if (s.completedBy.includes(actor)) return fail("You've already confirmed. Waiting for the other participant.");
      let finished = false;
      const r = commit((d) => {
        const x = d.sessions.find((y) => y.id === id)!;
        x.completedBy.push(actor);
        x.updatedAt = nowIso();
        const other = actor === x.teacherId ? x.learnerId : x.teacherId;
        if (x.completedBy.includes(x.teacherId) && x.completedBy.includes(x.learnerId)) {
          x.status = "Completed";
          finished = true;
          [x.learnerId, ...x.groupIds].forEach((l) => pushN(d, l, { kind: "review", text: `${x.skill} with ${nameOf(d, x.teacherId)} is complete. Rate your teacher.`, href: `/reviews?rate=${x.id}` }));
          pushN(d, x.teacherId, { kind: "review", text: `${x.skill} with ${nameOf(d, x.learnerId)} is complete. Leave learner feedback.`, href: `/sessions/${x.id}` });
        } else {
          pushN(d, other, { kind: "session", text: `${nameOf(d, actor)} marked ${x.skill} as completed. Confirm to finish it.`, href: `/sessions/${x.id}` });
        }
      });
      return r.ok ? { ok: true, info: finished ? "completed" : "waiting" } : r;
    },

    updateRoom(id, patch) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me || !participants(s).includes(me.id)) return fail("Only participants can edit this session.");
      if (patch.meetingLink && !/^https:\/\/\S+$/.test(patch.meetingLink)) return fail("Meeting link must start with https://");
      if ((patch.meetingLink !== undefined || patch.location !== undefined) && me.id !== s.teacherId) return fail("Only the teacher can set the meeting link or location.");
      return commit((d) => {
        Object.assign(d.sessions.find((y) => y.id === id)!, patch, { updatedAt: nowIso() });
      });
    },
    addSessionResource(id, title, url) {
      const s = dbRef.current.sessions.find((x) => x.id === id);
      if (!s || !me || !participants(s).includes(me.id)) return fail("Only participants can share resources.");
      if (title.trim().length < 3 || !/^https?:\/\/\S+$/.test(url)) return fail("Add a title and a valid link (https://…).");
      return commit((d) => {
        d.sessions.find((y) => y.id === id)!.resources.push({ id: uid("sr"), title: title.trim(), url, addedBy: me.id });
      });
    },

    /* ---------------- ratings & feedback ---------------- */
    submitReview(sessionId, stars, ratings, qualities, comment) {
      const s = dbRef.current.sessions.find((x) => x.id === sessionId);
      if (!s || !me) return fail("Session not found.");
      if (s.status !== "Completed") return fail("You can only rate completed sessions.");
      if (s.learnerId !== me.id && !s.groupIds.includes(me.id)) return fail("Only learners in this session can rate the teacher.");
      if (s.teacherId === me.id) return fail("You can't rate yourself.");
      if (dbRef.current.reviews.some((r) => r.sessionId === sessionId && r.reviewerId === me.id)) return fail("You already rated this session.");
      if (stars < 1 || stars > 5 || Object.values(ratings).some((v) => v < 1 || v > 5)) return fail("Give an overall star rating and rate every category.");
      if (comment.trim().length < 10) return fail("Write at least 10 characters of feedback.");
      return commit((d) => {
        d.reviews.unshift({ id: uid("r"), sessionId, reviewerId: me.id, revieweeId: s.teacherId, skill: s.skill, stars, ratings, qualities, comment: comment.trim(), helpful: [], mentorship: s.mentorship, createdAt: nowIso() });
        pushN(d, s.teacherId, { kind: "review", text: `${me.name} rated your ${s.skill} session ${stars}★. Your trust score was updated.`, href: "/reviews" });
      });
    },
    editReview(id, stars, comment) {
      const r = dbRef.current.reviews.find((x) => x.id === id);
      if (!r || !me || r.reviewerId !== me.id) return fail("You can only edit your own reviews.");
      if (Date.now() - new Date(r.createdAt).getTime() > EDIT_WINDOW_MS) return fail("Reviews can be edited for 7 days after submitting.");
      if (stars < 1 || stars > 5 || comment.trim().length < 10) return fail("Keep 1–5 stars and at least 10 characters.");
      return commit((d) => {
        Object.assign(d.reviews.find((x) => x.id === id)!, { stars, comment: comment.trim(), editedAt: nowIso() });
      });
    },
    toggleHelpful(id) {
      const r = dbRef.current.reviews.find((x) => x.id === id);
      if (!r || !me) return fail("Review not found.");
      if (r.reviewerId === me.id) return fail("You can't mark your own review helpful.");
      return commit((d) => {
        const x = d.reviews.find((y) => y.id === id)!;
        x.helpful = x.helpful.includes(me.id) ? x.helpful.filter((h) => h !== me.id) : [...x.helpful, me.id];
      });
    },
    submitFeedback(sessionId, f) {
      const s = dbRef.current.sessions.find((x) => x.id === sessionId);
      if (!s || !me) return fail("Session not found.");
      if (s.status !== "Completed") return fail("Feedback is available after the session is completed.");
      if (s.teacherId !== me.id) return fail("Only the teacher can give learner feedback.");
      if (dbRef.current.feedback.some((x) => x.sessionId === sessionId && x.teacherId === me.id)) return fail("You already gave feedback for this session.");
      if (f.comment.trim().length < 10) return fail("Write at least 10 characters.");
      return commit((d) => {
        d.feedback.unshift({ id: uid("f"), sessionId, teacherId: me.id, learnerId: s.learnerId, ...f, createdAt: nowIso() });
        pushN(d, s.learnerId, { kind: "review", text: `${me.name} left you learner feedback for ${s.skill}.`, href: "/reviews?tab=feedback" });
      });
    },

    /* ---------------- messaging ---------------- */
    canMessage(otherId) {
      if (!me) return { ok: false, reason: "Sign in to message." };
      const other = byId(otherId);
      if (!other || other.suspended) return { ok: false, reason: "This student isn't available." };
      if (me.blocked.includes(otherId)) return { ok: false, reason: "You blocked this student. Unblock them to message." };
      if (other.blocked.includes(me.id)) return { ok: false, reason: "You can't message this student." };
      const connected = findConn(dbRef.current, me.id, otherId)?.status === "Accepted";
      const shareSession = dbRef.current.sessions.some((s) => participants(s).includes(me.id) && participants(s).includes(otherId) && s.status !== "Rejected");
      if (other.privacy.messagesFrom === "connections" && !connected && !shareSession && me.role !== "admin") return { ok: false, reason: `${other.name.split(" ")[0]} only accepts messages from connections. Send a connection request first.` };
      return { ok: true };
    },
    sendMessage(toId, text) {
      const t = text.trim();
      if (!t) return fail("Type a message.");
      if (t.length > 1000) return fail("Messages are limited to 1000 characters.");
      const perm = value.canMessage(toId);
      if (!perm.ok) return fail(perm.reason!);
      const recent = dbRef.current.messages.filter((m) => m.fromId === me!.id && Date.now() - new Date(m.createdAt).getTime() < 60_000).length;
      if (recent >= 20) return fail("You're sending messages too quickly. Wait a minute.");
      return commit((d) => {
        d.messages.push({ id: uid("m"), fromId: me!.id, toId, text: t, read: false, createdAt: nowIso() });
        const already = d.notifications.some((n) => n.userId === toId && !n.read && n.kind === "message" && n.href === `/messages?with=${me!.id}`);
        if (!already) pushN(d, toId, { kind: "message", text: `${me!.name} sent you a message.`, href: `/messages?with=${me!.id}` });
      });
    },
    readConversation(otherId) {
      if (!me) return;
      if (!dbRef.current.messages.some((m) => m.fromId === otherId && m.toId === me.id && !m.read)) return;
      commit((d) => {
        d.messages.forEach((m) => m.fromId === otherId && m.toId === me.id && (m.read = true));
        d.notifications.forEach((n) => n.userId === me.id && n.href === `/messages?with=${otherId}` && (n.read = true));
      });
    },
    markRead(id) {
      if (!me) return;
      commit((d) => {
        d.notifications.forEach((n) => {
          if (n.userId === me.id && (!id || n.id === id)) n.read = true;
        });
      });
    },

    /* ---------------- safety & support ---------------- */
    report(targetType, targetId, reason) {
      if (!me) return fail("Sign in to report.");
      if (reason.trim().length < 10) return fail("Describe the problem in at least 10 characters.");
      if (dbRef.current.reports.some((r) => r.reporterId === me.id && r.targetId === targetId && r.status === "open")) return fail("You already reported this. Our team is reviewing it.");
      return commit((d) => {
        d.reports.unshift({ id: uid("rep"), reporterId: me.id, targetType, targetId, reason: reason.trim(), status: "open", createdAt: nowIso() });
        d.students.filter((s) => s.role === "admin").forEach((a) => pushN(d, a.id, { kind: "system", text: `New ${targetType} report from ${me.name}.`, href: "/admin?tab=reports" }));
      });
    },
    submitSupport(x) {
      if (x.name.trim().length < 2 || !/^\S+@\S+\.\S+$/.test(x.email) || x.subject.trim().length < 3 || x.message.trim().length < 10)
        return fail("Fill in your name, a valid email, a subject and a message of at least 10 characters.");
      return commit((d) => {
        d.support.unshift({ id: uid("sup"), ...x, status: "open", createdAt: nowIso() });
      });
    },

    /* ---------------- learning ---------------- */
    addResource(r) {
      if (!me) return fail("Not signed in.");
      if (r.title.trim().length < 3 || !/^https?:\/\/\S+$/.test(r.url)) return fail("Add a title and a valid link (https://…).");
      return commit((d) => {
        d.resources.unshift({ ...r, title: r.title.trim(), id: uid("res"), ownerId: me.id, createdAt: nowIso() });
      });
    },
    removeResource(id) {
      const r = dbRef.current.resources.find((x) => x.id === id);
      if (!r || !me || (r.ownerId !== me.id && !isAdmin())) return fail("You can only remove your own resources.");
      return commit((d) => {
        d.resources = d.resources.filter((x) => x.id !== id);
      });
    },
    saveProgress(p) {
      if (!me) return fail("Not signed in.");
      if (!p.skill.trim()) return fail("Name the skill you're tracking.");
      return commit((d) => {
        const done = p.milestones.length ? p.milestones.filter((m) => m.done).length / p.milestones.length : p.percent / 100;
        const percent = p.milestones.length ? Math.round(done * 100) : Math.max(0, Math.min(100, p.percent));
        const row = { ...p, percent, completed: percent === 100 || p.completed, userId: me.id, updatedAt: nowIso() };
        const existing = p.id && d.progress.find((x) => x.id === p.id && x.userId === me.id);
        if (existing) Object.assign(existing, row);
        else d.progress.unshift({ ...row, id: uid("p") });
      });
    },
    removeProgress(id) {
      if (!me) return fail("Not signed in.");
      return commit((d) => {
        d.progress = d.progress.filter((x) => !(x.id === id && x.userId === me.id));
      });
    },
    joinChallenge(challengeId) {
      if (!me) return fail("Not signed in.");
      if (dbRef.current.challenges.some((c) => c.userId === me.id && c.challengeId === challengeId)) return fail("You've already joined this challenge.");
      return commit((d) => {
        d.challenges.push({ id: uid("ch"), userId: me.id, challengeId, startedAt: nowIso(), daysDone: [] });
      });
    },
    toggleChallengeDay(joinId, day) {
      if (!me) return fail("Not signed in.");
      const c = dbRef.current.challenges.find((x) => x.id === joinId && x.userId === me.id);
      if (!c) return fail("Challenge not found.");
      const dayIndex = Math.floor((Date.now() - new Date(c.startedAt).getTime()) / 86_400_000) + 1;
      if (day > dayIndex) return fail(`Day ${day} unlocks ${day - dayIndex === 1 ? "tomorrow" : `in ${day - dayIndex} days`}.`);
      return commit((d) => {
        const x = d.challenges.find((y) => y.id === joinId)!;
        x.daysDone = x.daysDone.includes(day) ? x.daysDone.filter((n) => n !== day) : [...x.daysDone, day].sort();
      });
    },
    leaveChallenge(joinId) {
      if (!me) return fail("Not signed in.");
      return commit((d) => {
        d.challenges = d.challenges.filter((x) => !(x.id === joinId && x.userId === me.id));
      });
    },
    addCertificate(c) {
      if (!me) return fail("Not signed in.");
      if (c.title.trim().length < 3) return fail("Give the certificate a title.");
      if (c.url && !/^(https?:\/\/\S+|data:)/.test(c.url)) return fail("Add a valid link or upload a file.");
      if (c.url.length > 450_000) return fail("File is too large (max ~300 KB in demo mode).");
      return commit((d) => {
        d.students.find((s) => s.id === me.id)!.certificates.push({ ...c, title: c.title.trim(), id: uid("cert"), status: c.url ? "evidence" : "self" });
      });
    },
    removeCertificate(id) {
      if (!me) return fail("Not signed in.");
      return commit((d) => {
        const s = d.students.find((x) => x.id === me.id)!;
        s.certificates = s.certificates.filter((c) => c.id !== id);
      });
    },

    /* ---------------- admin (role-checked on every call) ---------------- */
    admin: {
      setSuspended(userId, suspended) {
        if (!isAdmin()) return fail("Admins only.");
        if (userId === me!.id) return fail("You can't suspend yourself.");
        return commit((d) => {
          d.students.find((s) => s.id === userId)!.suspended = suspended;
          audit(d, `${suspended ? "Suspended" : "Restored"} ${nameOf(d, userId)}`);
        });
      },
      resolveReport(id, status) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.reports.find((r) => r.id === id)!.status = status;
          audit(d, `Marked report ${id} ${status}`);
        });
      },
      mentorDecision(userId, decision) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.students.find((s) => s.id === userId)!.mentorStatus = decision;
          audit(d, `Mentor status for ${nameOf(d, userId)} → ${decision}`);
          if (decision !== "none") pushN(d, userId, { kind: "mentor", text: decision === "approved" ? "You've been approved as a Senior Mentor." : "Your Senior Mentor request wasn't approved this time.", href: "/profile" });
        });
      },
      verifyCertificate(userId, certId, verified) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          const c = d.students.find((s) => s.id === userId)!.certificates.find((x) => x.id === certId)!;
          c.status = verified ? "verified" : c.url ? "evidence" : "self";
          audit(d, `${verified ? "Verified" : "Unverified"} certificate "${c.title}" for ${nameOf(d, userId)}`);
        });
      },
      addCategory(name) {
        if (!isAdmin()) return fail("Admins only.");
        const n = name.trim();
        if (n.length < 2) return fail("Category name is too short.");
        if (dbRef.current.settings.skillCategories.some((c) => c.toLowerCase() === n.toLowerCase())) return fail("That category already exists.");
        return commit((d) => {
          d.settings.skillCategories.push(n);
          audit(d, `Added skill category ${n}`);
        });
      },
      removeCategory(name) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.settings.skillCategories = d.settings.skillCategories.filter((c) => c !== name);
          audit(d, `Removed skill category ${name}`);
        });
      },
      closeSupport(id) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.support.find((s) => s.id === id)!.status = "closed";
          audit(d, `Closed support request ${id}`);
        });
      },
      deleteReview(id) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.reviews = d.reviews.filter((r) => r.id !== id);
          d.reports.forEach((r) => r.targetId === id && (r.status = "resolved"));
          audit(d, `Removed review ${id}`);
        });
      },
      deleteMessage(id) {
        if (!isAdmin()) return fail("Admins only.");
        return commit((d) => {
          d.messages = d.messages.filter((m) => m.id !== id);
          d.reports.forEach((r) => r.targetId === id && (r.status = "resolved"));
          audit(d, `Removed message ${id}`);
        });
      },
    },

    updateSettings(patch) {
      commit((d) => {
        if (patch.notify) d.settings.notify = { ...d.settings.notify, ...patch.notify };
        const { notify: _n, ...rest } = patch;
        if (Object.keys(rest).length && !isAdmin()) return d; // platform settings are admin-only
        Object.assign(d.settings, rest);
        if (Object.keys(rest).length) audit(d, `Updated platform settings: ${Object.keys(rest).join(", ")}`);
      });
    },

    resetDemo() {
      const seed = repo.reset();
      dbRef.current = seed;
      setDb(seed);
      localStorage.removeItem(AUTH_KEY);
      setMeId(null);
    },
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

function pushN(d: DB, userId: string, n: Omit<Notification, "id" | "userId" | "read" | "createdAt">) {
  const map: Record<Notification["kind"], keyof DB["settings"]["notify"] | null> = { session: "sessions", mentor: "sessions", connection: "connections", review: "reviews", message: "messages", match: "matches", system: null };
  const key = map[n.kind];
  if (key && !d.settings.notify[key]) return;
  d.notifications.unshift({ id: uid("n"), userId, read: false, createdAt: nowIso(), ...n });
  if (d.notifications.length > 600) d.notifications.length = 600;
}

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useStore outside StoreProvider");
  return c;
}
export const otherParty = (s: Session, meId: string) => (s.teacherId === meId ? s.learnerId : s.teacherId);
