"use client";
import { motion } from "framer-motion";
import {
  ArrowLeftRight, ArrowRight, CalendarClock, CalendarPlus, Check, Clock, DoorOpen, Flag, MapPin, MessageCircle, MonitorSmartphone,
  RefreshCw, Send, ShieldAlert, Star, UserCheck, UserPlus, Users, X, Zap,
} from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { type Match, QUALITIES, isMentor, mentorCheck, ratingSummary, sessionStart, timeState, trustScore, yearLabel } from "@/lib/engines";
import { otherParty, useStore } from "@/lib/store";
import { FORMATS, MODES, type RatingSet, type Report, type Session, type SessionFormat, type SessionMode, type Student, type TeachSkill } from "@/lib/types";
import { useToast } from "./toast";
import { Avatar, Badge, Button, Card, Field, Input, MentorBadge, Modal, Ring, Select, SkillChip, StarInput, Stars, Textarea, cn } from "./ui";

/* ---------- derived stats ---------- */
export function useStats(id: string) {
  const { db } = useStore();
  return useMemo(() => {
    const s = db.students.find((x) => x.id === id);
    return {
      rating: ratingSummary(id, db.reviews),
      mentorRating: ratingSummary(id, db.reviews, { mentorship: true }),
      trust: trustScore(id, db),
      mentor: s ? isMentor(s, db) : false,
      check: s ? mentorCheck(s, db) : { eligible: false, criteria: [] },
    };
  }, [db, id]);
}

export function SampleTag() {
  return <span title="Fictional sample profile for demonstration" className="rounded-full border border-dashed border-[#c8cbe0] px-2 py-0.5 text-[0.65rem] font-bold tracking-wide text-subtle uppercase">Sample</span>;
}
export function TrustPill({ id }: { id: string }) {
  const { trust } = useStats(id);
  return trust.established ? <Badge tone="navy" className="whitespace-nowrap">Trust {trust.total}</Badge> : <Badge tone="neutral" className="whitespace-nowrap">New · building trust</Badge>;
}
export const modeLabel = (m: Student["mode"]) => (m === "both" ? "Online & offline" : m === "online" ? "Online" : "Offline");

/* ---------- connect ---------- */
export function ConnectButton({ student, size = "sm", className }: { student: Student; size?: "sm" | "md"; className?: string }) {
  const { connect, connectionWith, respondConnection, cancelConnection, me } = useStore();
  const toast = useToast();
  const c = connectionWith(student.id);
  if (!me || me.id === student.id || me.role === "admin") return null;
  const run = (r: { ok: boolean; error?: string }, msg: string) => toast(r.ok ? msg : r.error!, r.ok ? "success" : "error");
  if (c?.status === "Accepted") return <Button size={size} variant="secondary" href={`/messages?with=${student.id}`} className={className}><UserCheck className="h-4 w-4 text-teal-strong" /> Connected</Button>;
  if (c?.status === "Pending" && c.toId === me.id) return <Button size={size} variant="accent" className={className} onClick={() => run(respondConnection(c.id, true), `You're now connected with ${student.name}.`)}><Check className="h-4 w-4" /> Accept</Button>;
  if (c?.status === "Pending") return <Button size={size} variant="secondary" className={className} onClick={() => run(cancelConnection(c.id), "Request cancelled.")} title="Cancel request"><Clock className="h-4 w-4" /> Requested · Cancel</Button>;
  return <Button size={size} variant="secondary" className={className} onClick={() => run(connect(student.id), `Connection request sent to ${student.name}.`)}><UserPlus className="h-4 w-4" /> Connect</Button>;
}

/* ---------- student card ---------- */
export function StudentCard({ student, onView, onRequest, highlight }: { student: Student; onView: () => void; onRequest: () => void; highlight?: string }) {
  const { rating, mentor } = useStats(student.id);
  const hl = (name: string) => !!highlight && name.toLowerCase().includes(highlight.toLowerCase());
  return (
    <Card hover className="flex h-full flex-col">
      <button onClick={onView} className="flex items-start gap-3.5 text-left" aria-label={`View ${student.name}'s profile`}>
        <Avatar name={student.name} src={student.avatar} size={52} />
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2"><span className="truncate text-[1.02rem] font-bold text-navy">{student.name}</span>{student.sample && <SampleTag />}</span>
          <span className="block truncate text-sm text-subtle">{student.department} · {yearLabel(student.year)}</span>
          <span className="block truncate text-xs text-subtle">{student.privacy.showCollege ? student.college : "College hidden"} · {student.field}</span>
          <span className="mt-1 block"><Stars value={rating.average} showValue count={rating.count} size={14} /></span>
        </span>
      </button>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {mentor && <MentorBadge small />}
        <Badge tone="neutral">{modeLabel(student.mode)}</Badge>
        <TrustPill id={student.id} />
      </div>
      <div className="mt-4 space-y-3 text-sm">
        <div>
          <p className="mb-1.5 text-xs font-bold tracking-wide text-muted uppercase">Can teach</p>
          <div className="flex flex-wrap gap-1.5">{student.teach.map((t) => <SkillChip key={t.name} tone={hl(t.name) ? "match" : "navy"}>{t.name}<span className="opacity-60">· {t.level[0]}</span></SkillChip>)}</div>
        </div>
        <div>
          <p className="mb-1.5 text-xs font-bold tracking-wide text-muted uppercase">Wants to learn</p>
          <div className="flex flex-wrap gap-1.5">{student.learn.map((t) => <SkillChip key={t.name} tone="teal">{t.name}</SkillChip>)}</div>
        </div>
      </div>
      <div className="mt-auto flex flex-wrap gap-2 pt-5">
        <Button size="sm" variant="primary" className="flex-1" onClick={onRequest}><CalendarPlus className="h-4 w-4" /> Request</Button>
        <ConnectButton student={student} className="flex-1" />
      </div>
    </Card>
  );
}

/* ---------- skill card (one skill of one student) ---------- */
export function SkillCard({ student, skill, onView, onRequest }: { student: Student; skill: TeachSkill; onView: () => void; onRequest: () => void }) {
  const { rating, mentor } = useStats(student.id);
  const sk = rating.bySkill.find((b) => b.skill === skill.name);
  return (
    <Card hover className="flex h-full flex-col">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-bold tracking-wide text-teal-strong uppercase">{skill.category}</p>
          <h3 className="mt-0.5 text-lg font-extrabold text-navy">{skill.name}</h3>
        </div>
        <Badge tone={skill.level === "Advanced" ? "teal" : skill.level === "Intermediate" ? "navy" : "neutral"}>{skill.level}</Badge>
      </div>
      {skill.description && <p className="mt-2 line-clamp-2 text-sm text-ink">{skill.description}</p>}
      <div className="mt-3 flex items-center gap-2 text-sm">
        {sk ? (sk.enough ? <><Stars value={sk.average} size={13} showValue /><span className="text-xs text-subtle">{sk.count} reviews</span></> : <span className="text-xs text-subtle">{sk.count} review · not enough to rate yet</span>) : <span className="text-xs text-subtle">No reviews for this skill yet</span>}
      </div>
      <button onClick={onView} className="mt-4 flex items-center gap-3 neu-inset rounded-2xl p-3 text-left hover:bg-[#e3e7f0]">
        <Avatar name={student.name} src={student.avatar} size={38} className="ring-2" />
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2"><span className="truncate text-sm font-bold text-navy">{student.name}</span>{student.sample && <SampleTag />}</span>
          <span className="block truncate text-xs text-subtle">{student.privacy.showCollege ? `${student.college} · ` : ""}{student.department} · {yearLabel(student.year)}</span>
        </span>
        {mentor && <MentorBadge small />}
      </button>
      <p className="mt-3 text-xs text-subtle">{modeLabel(skill.mode ?? student.mode)} · {student.slots.length ? student.slots.map((s) => `${s.day} ${s.from}`).join(", ") : "Availability on request"}</p>
      <div className="mt-auto flex flex-wrap gap-2 pt-4">
        <Button size="sm" variant="accent" className="flex-1" onClick={onRequest}><CalendarPlus className="h-4 w-4" /> Request session</Button>
        <ConnectButton student={student} className="flex-1" />
      </div>
    </Card>
  );
}

/* ---------- profile quick view ---------- */
export function ProfileModal({ student, onClose }: { student: Student | null; onClose: () => void }) {
  const [book, setBook] = useState(false);
  const stats = useStats(student?.id ?? "");
  if (!student) return null;
  return (
    <>
      <Modal open={!!student && !book} onClose={onClose} title="Student profile" wide>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <Avatar name={student.name} src={student.avatar} size={68} />
          <div className="flex-1">
            <p className="flex items-center gap-2 text-xl font-extrabold text-navy">{student.name} {student.sample && <SampleTag />}</p>
            <p className="text-sm text-subtle">{student.department} · {yearLabel(student.year)}{student.privacy.showCollege ? ` · ${student.college}` : ""}</p>
            <div className="mt-2 flex flex-wrap items-center gap-2"><Stars value={stats.rating.average} showValue count={stats.rating.count} />{stats.mentor && <MentorBadge small />}</div>
          </div>
          <div className="text-center">
            {stats.trust.established ? <Ring value={stats.trust.total} size={64} label={`Trust score ${stats.trust.total} of 100`} /> : <TrustPill id={student.id} />}
            {stats.trust.established && <p className="mt-1 text-xs font-semibold text-subtle">Trust</p>}
          </div>
        </div>
        {student.bio && <p className="mt-5 text-[0.95rem] text-ink">{student.bio}</p>}
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div className="neu-inset rounded-2xl p-4">
            <p className="mb-2 text-xs font-bold tracking-wide text-muted uppercase">Can teach</p>
            <ul className="space-y-1.5">{student.teach.map((t) => <li key={t.name} className="flex items-center justify-between text-sm"><span className="font-semibold text-navy">{t.name}</span><span className="text-xs text-subtle">{t.level}</span></li>)}</ul>
          </div>
          <div className="neu-inset rounded-2xl p-4">
            <p className="mb-2 text-xs font-bold tracking-wide text-muted uppercase">Wants to learn</p>
            <div className="flex flex-wrap gap-1.5">{student.learn.map((t) => <SkillChip key={t.name} tone="teal">{t.name}</SkillChip>)}</div>
          </div>
        </div>
        <div className="mt-6 flex flex-col gap-2 sm:flex-row">
          <Button variant="accent" className="flex-1" onClick={() => setBook(true)}><CalendarPlus className="h-4 w-4" /> Request session</Button>
          <ConnectButton student={student} size="md" className="flex-1" />
          <Button variant="secondary" href={`/profile/${student.id}`} className="flex-1">Full profile <ArrowRight className="h-4 w-4" /></Button>
        </div>
      </Modal>
      <RequestSessionModal open={book} other={student} onClose={() => { setBook(false); onClose(); }} />
    </>
  );
}

/* ---------- request session ---------- */
const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const tomorrow = () => { const d = new Date(); d.setDate(d.getDate() + 1); return ymd(d); };
export const today = () => ymd(new Date());

export function RequestSessionModal({ open, onClose, other, role: initialRole, skill: initialSkill, title, mentorship }: { open: boolean; onClose: () => void; other: Student | null; role?: "learn" | "teach"; skill?: string; title?: string; mentorship?: boolean }) {
  const { me, db, requestSession } = useStore();
  const toast = useToast();
  const [role, setRole] = useState<"learn" | "teach">(initialRole ?? "learn");
  const [skill, setSkill] = useState(initialSkill ?? "");
  const [date, setDate] = useState(tomorrow());
  const [time, setTime] = useState("17:00");
  const [duration, setDuration] = useState(60);
  const [mode, setMode] = useState<SessionMode>("Online");
  const [format, setFormat] = useState<SessionFormat>("One-to-One");
  const [group, setGroup] = useState<string[]>([]);
  const [objective, setObjective] = useState("");
  const [message, setMessage] = useState("");
  const [err, setErr] = useState("");
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) {
      setRole(initialRole ?? (mentorship || other?.teach.length ? "learn" : "teach"));
      setSkill(initialSkill ?? "");
      setErr(""); setMessage(""); setObjective(""); setGroup([]);
      setMode(other?.mode === "offline" ? "Offline" : "Online");
      setFormat(other?.formats[0] ?? "One-to-One");
    }
  }
  if (!other || !me) return null;
  const options = role === "learn" ? other.teach.map((t) => t.name) : me.teach.map((t) => t.name);
  const skillValue = options.includes(skill) ? skill : options[0] ?? "";
  const friends = db.connections.filter((c) => c.status === "Accepted" && (c.fromId === me.id || c.toId === me.id)).map((c) => (c.fromId === me.id ? c.toId : c.fromId)).filter((id) => id !== other.id);
  const slotHint = other.slots.length ? `${other.name.split(" ")[0]} is usually free ${other.slots.map((s) => `${s.day} ${s.from}–${s.to}`).join(", ")}.` : undefined;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = requestSession({ otherId: other.id, role, skill: skillValue, date, time, duration, mode, format, groupIds: group, objective, message, mentorship });
    if (!r.ok) return setErr(r.error);
    toast(`${mentorship ? "Mentorship" : "Session"} request sent to ${other.name}.`);
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title={title ?? `Request a session with ${other.name.split(" ")[0]}`}>
      <form onSubmit={submit} className="space-y-4">
        {!mentorship && (
          <div className="neu-inset grid grid-cols-2 gap-1 rounded-2xl p-1.5" role="radiogroup" aria-label="Session direction">
            {(["learn", "teach"] as const).map((r) => (
              <button type="button" role="radio" aria-checked={role === r} key={r} onClick={() => setRole(r)} className={cn("rounded-xl px-3 py-2 text-sm font-semibold", role === r ? "bg-ivory text-navy shadow-[var(--shadow-raised-sm)]" : "text-subtle")}>
                {r === "learn" ? "I want to learn" : "I'll teach them"}
              </button>
            ))}
          </div>
        )}
        <Field label="Skill" htmlFor="rs-skill" hint={!options.length ? (role === "learn" ? `${other.name.split(" ")[0]} hasn't listed teaching skills.` : "Add teaching skills to My Skills first.") : undefined}>
          <Select id="rs-skill" value={skillValue} onChange={(e) => setSkill(e.target.value)} disabled={!options.length}>{options.map((o) => <option key={o}>{o}</option>)}</Select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date" htmlFor="rs-date"><Input id="rs-date" type="date" min={today()} value={date} onChange={(e) => setDate(e.target.value)} required /></Field>
          <Field label="Time" htmlFor="rs-time"><Input id="rs-time" type="time" value={time} onChange={(e) => setTime(e.target.value)} required /></Field>
        </div>
        {slotHint && <p className="-mt-2 text-xs text-subtle">{slotHint}</p>}
        <div className="grid grid-cols-3 gap-3">
          <Field label="Duration" htmlFor="rs-dur"><Select id="rs-dur" value={duration} onChange={(e) => setDuration(Number(e.target.value))}>{[30, 45, 60, 90, 120].map((d) => <option key={d} value={d}>{d} min</option>)}</Select></Field>
          <Field label="Mode" htmlFor="rs-mode"><Select id="rs-mode" value={mode} onChange={(e) => setMode(e.target.value as SessionMode)}>{MODES.map((t) => <option key={t}>{t}</option>)}</Select></Field>
          <Field label="Format" htmlFor="rs-fmt"><Select id="rs-fmt" value={format} onChange={(e) => setFormat(e.target.value as SessionFormat)}>{FORMATS.map((t) => <option key={t}>{t}</option>)}</Select></Field>
        </div>
        {format === "Group" && (
          <div>
            <p className="mb-1.5 text-sm font-semibold text-ink">Invite connections (optional)</p>
            {friends.length ? (
              <div className="flex flex-wrap gap-2">
                {friends.map((id) => {
                  const f = db.students.find((s) => s.id === id);
                  if (!f) return null;
                  const on = group.includes(id);
                  return <button type="button" key={id} onClick={() => setGroup(on ? group.filter((g) => g !== id) : [...group, id])} className={cn("rounded-full px-3 py-1 text-xs font-semibold", on ? "bg-teal-strong text-white" : "neu-sm text-ink")} aria-pressed={on}>{f.name}</button>;
                })}
              </div>
            ) : <p className="text-xs text-subtle">Connect with classmates to invite them to group sessions.</p>}
          </div>
        )}
        <Field label="Learning objective" htmlFor="rs-obj"><Input id="rs-obj" placeholder="e.g. Understand interfaces and write two small classes" value={objective} onChange={(e) => setObjective(e.target.value)} maxLength={160} /></Field>
        <Field label="Message (optional)" htmlFor="rs-note"><Textarea id="rs-note" rows={2} placeholder="Anything they should know?" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={300} /></Field>
        {err && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err}</p>}
        <Button type="submit" variant="accent" className="w-full" disabled={!options.length}><Send className="h-4 w-4" /> Send request</Button>
      </form>
    </Modal>
  );
}

/* ---------- match card ---------- */
export function MatchCard({ match, onRequest, onView }: { match: Match; onRequest: () => void; onView: () => void }) {
  const { rating } = useStats(match.student.id);
  const s = match.student;
  return (
    <Card hover className="flex h-full flex-col">
      <div className="flex items-start gap-3.5">
        <button onClick={onView} aria-label={`View ${s.name}'s profile`}><Avatar name={s.name} src={s.avatar} size={52} /></button>
        <div className="min-w-0 flex-1">
          <button onClick={onView} className="block truncate text-left text-[1.02rem] font-bold text-navy hover:underline">{s.name}</button>
          <p className="truncate text-sm text-subtle">{s.department} · {yearLabel(s.year)}</p>
          <p className="truncate text-xs text-subtle">{s.privacy.showCollege ? s.college : s.field}</p>
          <div className="mt-1"><Stars value={rating.average} showValue count={rating.count} size={14} /></div>
        </div>
        <motion.div whileHover={{ scale: 1.06 }}><Ring value={match.percent} size={58} stroke={6} label={`${match.percent}% match`} /></motion.div>
      </div>
      {match.perfect && <Badge tone="teal" className="mt-3 self-start"><Zap className="h-3 w-3" /> Perfect Mutual Match</Badge>}
      <p className="mt-3 rounded-xl bg-blush-soft px-3 py-2 text-sm text-[#6b2f3a]">{match.explanation}</p>
      <div className="mt-3 grid grid-cols-[1fr_auto_1fr] items-stretch gap-2">
        <div className="neu-inset rounded-2xl p-3">
          <p className="mb-2 text-[0.68rem] font-bold tracking-wide text-muted uppercase">You teach them</p>
          <div className="flex flex-wrap gap-1.5">{match.iTeach.length ? match.iTeach.map((x) => <SkillChip key={x}>{x}</SkillChip>) : <span className="text-xs text-subtle">-</span>}</div>
        </div>
        <div className="flex items-center justify-center text-[#d9868c] drop-shadow-[0_0_6px_rgb(246_201_204/1)]" aria-hidden>
          {match.kind === "mutual" ? <ArrowLeftRight className="h-5 w-5" /> : <ArrowRight className={cn("h-5 w-5", match.kind === "learn" && "rotate-180")} />}
        </div>
        <div className="neu-inset rounded-2xl p-3">
          <p className="mb-2 text-[0.68rem] font-bold tracking-wide text-muted uppercase">They teach you</p>
          <div className="flex flex-wrap gap-1.5">{match.theyTeach.length ? match.theyTeach.map((x) => {
            const sk = rating.bySkill.find((b) => b.skill === x);
            return <SkillChip key={x} tone="teal">{x}{sk?.enough && <span className="opacity-70"> ★{sk.average.toFixed(1)}</span>}</SkillChip>;
          }) : <span className="text-xs text-subtle">-</span>}</div>
        </div>
      </div>
      <div className="mt-auto flex flex-wrap gap-2 pt-5">
        <Button size="sm" variant="accent" className="flex-1" onClick={onRequest}>{match.kind === "mutual" ? <><ArrowLeftRight className="h-4 w-4" /> Request exchange</> : <><CalendarPlus className="h-4 w-4" /> Request session</>}</Button>
        <ConnectButton student={s} className="flex-1" />
        <Button size="sm" variant="ghost" onClick={onView}>Profile</Button>
      </div>
    </Card>
  );
}

/* ---------- sessions ---------- */
export const statusTone = { Pending: "amber", Accepted: "teal", Rejected: "rose", Completed: "green", Cancelled: "neutral" } as const;
export const fmtDate = (s: Session) => sessionStart(s).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" });
export const fmtTime = (s: Session) => sessionStart(s).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });

function useRun() {
  const toast = useToast();
  return (r: { ok: boolean; error?: string }, msg: string) => toast(r.ok ? msg : r.error!, r.ok ? "success" : "error");
}

export function SessionActions({ session, onReschedule, onCancel }: { session: Session; onReschedule: () => void; onCancel: () => void }) {
  const { me, byId, respondSession, completeSession, simulatePeer, db, now, supabase } = useStore();
  const run = useRun();
  if (!me) return null;
  const other = byId(otherParty(session, me.id));
  const ts = timeState(session, now);
  const started = ts.kind === "live" || ts.kind === "ended";
  const isLead = me.id === session.teacherId || me.id === session.learnerId;
  const iConfirmed = session.completedBy.includes(me.id);
  const reviewed = db.reviews.some((r) => r.sessionId === session.id && r.reviewerId === me.id);
  const isLearner = session.learnerId === me.id || session.groupIds.includes(me.id);
  const gaveFeedback = db.feedback.some((f) => f.sessionId === session.id && f.teacherId === me.id);
  return (
    <div className="flex flex-wrap gap-2">
      {session.status === "Pending" && session.awaitingId === me.id && (
        <>
          <Button size="sm" variant="accent" onClick={() => run(respondSession(session.id, true), "Accepted. It's on your calendar.")}><Check className="h-4 w-4" /> Accept</Button>
          <Button size="sm" variant="danger" onClick={() => run(respondSession(session.id, false), "Request declined.")}><X className="h-4 w-4" /> Reject</Button>
        </>
      )}
      {!supabase && session.status === "Pending" && session.awaitingId !== me.id && isLead && (
        <Button size="sm" variant="secondary" title="Demo control: simulates the other student" onClick={() => run(simulatePeer(session.id), `${other?.name.split(" ")[0]} accepted (demo simulation).`)}><Zap className="h-4 w-4 text-amber" /> Simulate their accept</Button>
      )}
      {session.status === "Accepted" && started && isLead && !iConfirmed && (
        <Button size="sm" variant="accent" onClick={() => { const r = completeSession(session.id); run(r, r.ok && r.info === "completed" ? "Session marked as completed." : "Confirmed. Waiting for the other participant."); }}><Check className="h-4 w-4" /> Mark completed</Button>
      )}
      {!supabase && session.status === "Accepted" && iConfirmed && (
        <Button size="sm" variant="secondary" title="Demo control: simulates the other participant confirming" onClick={() => run(simulatePeer(session.id), "Other participant confirmed (demo simulation).")}><Zap className="h-4 w-4 text-amber" /> Simulate their confirm</Button>
      )}
      {(session.status === "Pending" || (session.status === "Accepted" && ts.kind !== "ended")) && isLead && (
        <>
          <Button size="sm" variant="secondary" onClick={onReschedule}><RefreshCw className="h-4 w-4" /> Reschedule</Button>
          <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
        </>
      )}
      {session.status === "Completed" && isLearner && !reviewed && <Button size="sm" href={`/reviews?rate=${session.id}`}><Star className="h-4 w-4" /> Rate teacher</Button>}
      {session.status === "Completed" && isLearner && reviewed && <Badge tone="green"><Check className="h-3 w-3" /> Rated</Badge>}
      {session.status === "Completed" && session.teacherId === me.id && !gaveFeedback && <Button size="sm" variant="secondary" href={`/sessions/${session.id}#feedback`}>Give learner feedback</Button>}
    </div>
  );
}

export function RescheduleModal({ session, open, onClose }: { session: Session; open: boolean; onClose: () => void }) {
  const { rescheduleSession, byId, me } = useStore();
  const toast = useToast();
  const [d, setD] = useState(session.date);
  const [t, setT] = useState(session.time);
  const [err, setErr] = useState("");
  const other = me ? byId(otherParty(session, me.id)) : undefined;
  return (
    <Modal open={open} onClose={onClose} title="Reschedule session">
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); const r = rescheduleSession(session.id, d, t); if (!r.ok) return setErr(r.error); toast(`New time sent to ${other?.name ?? "them"} to confirm.`); onClose(); }}>
        <p className="text-sm text-subtle">{other?.name ?? "The other participant"} will need to confirm. The session returns to Pending until they do.</p>
        <div className="grid grid-cols-2 gap-3">
          <Field label="New date" htmlFor="r-d"><Input id="r-d" type="date" min={today()} value={d} onChange={(e) => setD(e.target.value)} required /></Field>
          <Field label="New time" htmlFor="r-t"><Input id="r-t" type="time" value={t} onChange={(e) => setT(e.target.value)} required /></Field>
        </div>
        {err && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err}</p>}
        <Button type="submit" className="w-full">Propose new time</Button>
      </form>
    </Modal>
  );
}

export function CancelModal({ session, open, onClose }: { session: Session; open: boolean; onClose: () => void }) {
  const { cancelSession } = useStore();
  const run = useRun();
  return (
    <Modal open={open} onClose={onClose} title="Cancel this session?">
      <p className="text-sm text-ink">Your {session.skill} session on {fmtDate(session)} will be cancelled and the other participants notified. It stays in everyone's history and is never counted as completed.</p>
      <div className="mt-6 flex gap-2">
        <Button variant="secondary" className="flex-1" onClick={onClose}>Keep session</Button>
        <Button variant="danger" className="flex-1" onClick={() => { run(cancelSession(session.id), "Session cancelled."); onClose(); }}>Cancel session</Button>
      </div>
    </Modal>
  );
}

export function SessionCard({ session }: { session: Session }) {
  const { me, byId, now } = useStore();
  const [resched, setResched] = useState(false);
  const [cancel, setCancel] = useState(false);
  if (!me) return null;
  const other = byId(otherParty(session, me.id));
  const iTeach = session.teacherId === me.id;
  const ts = timeState(session, now);
  const active = session.status === "Pending" || session.status === "Accepted";
  return (
    <>
      <div className={cn("neu flex flex-col gap-4 p-5 xl:flex-row xl:items-center", session.status === "Accepted" && ts.kind === "live" && "glow-live")}>
        <div className="flex min-w-0 flex-1 items-center gap-3.5">
          <div className="neu-inset flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-2xl leading-none">
            <span className="text-[0.65rem] font-bold text-subtle uppercase">{sessionStart(session).toLocaleDateString(undefined, { month: "short" })}</span>
            <span className="text-lg font-extrabold text-navy">{sessionStart(session).getDate()}</span>
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Link href={`/sessions/${session.id}`} className="font-bold text-navy hover:underline">{session.skill}</Link>
              <Badge tone={statusTone[session.status]}>{session.status}</Badge>
              <Badge tone="navy">{iTeach ? "Teaching" : "Learning"}</Badge>
              {session.mentorship && <Badge tone="teal">Mentorship</Badge>}
            </div>
            <p className="mt-0.5 truncate text-sm text-subtle">{iTeach ? "with" : "from"} {other ? <Link href={`/profile/${other.id}`} className="font-semibold text-ink hover:underline">{other.name}</Link> : "a former member"}{session.groupIds.length ? ` +${session.groupIds.length}` : ""}</p>
            <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-subtle">
              <span className="inline-flex items-center gap-1"><CalendarClock className="h-3.5 w-3.5" /> {fmtDate(session)}, {fmtTime(session)} · {session.duration} min</span>
              <span className="inline-flex items-center gap-1">{session.mode === "Online" ? <MonitorSmartphone className="h-3.5 w-3.5" /> : <MapPin className="h-3.5 w-3.5" />}{session.format === "Group" && <Users className="h-3.5 w-3.5" />} {session.mode} · {session.format}</span>
            </p>
            {active && (
              <p className={cn("mt-1.5 inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-bold", ts.kind === "live" || ts.kind === "soon" ? "bg-blush-soft text-blush-ink" : ts.kind === "ended" ? "bg-[#f7ecd6] text-[#8a5b0c]" : "bg-[#eceef5] text-subtle")}>
                {ts.kind === "live" && <span className="live-dot" />}
                {ts.kind === "ended" && session.status === "Accepted" ? `${ts.label}. Confirm it's done` : ts.label}
              </p>
            )}
            {session.status === "Accepted" && session.completedBy.length === 1 && <p className="mt-1 text-xs font-semibold text-teal-strong">{session.completedBy.includes(me.id) ? "You confirmed · waiting for the other participant" : "The other participant confirmed. Confirm to finish"}</p>}
            {session.status === "Pending" && <p className="mt-1 text-xs font-semibold text-[#8a5b0c]">{session.awaitingId === me.id ? "Waiting for your response" : `Waiting for ${byId(session.awaitingId)?.name.split(" ")[0] ?? "them"}`}</p>}
            {session.note && session.status === "Cancelled" && <p className="mt-1 text-xs text-subtle">{session.note}</p>}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <SessionActions session={session} onReschedule={() => setResched(true)} onCancel={() => setCancel(true)} />
          <Button size="sm" variant="ghost" href={`/sessions/${session.id}`}><DoorOpen className="h-4 w-4" /> Room</Button>
        </div>
      </div>
      <RescheduleModal session={session} open={resched} onClose={() => setResched(false)} />
      <CancelModal session={session} open={cancel} onClose={() => setCancel(false)} />
    </>
  );
}

/* ---------- review modal ---------- */
export function ReviewModal({ session, onClose }: { session: Session | null; onClose: () => void }) {
  const { submitReview, byId } = useStore();
  const toast = useToast();
  const [stars, setStars] = useState(0);
  const [ratings, setRatings] = useState<RatingSet>({ teaching: 0, knowledge: 0, communication: 0, experience: 0 });
  const [qualities, setQualities] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);
  const [lastId, setLastId] = useState<string | null>(null);
  if ((session?.id ?? null) !== lastId) {
    setLastId(session?.id ?? null);
    setStars(0); setRatings({ teaching: 0, knowledge: 0, communication: 0, experience: 0 }); setQualities([]); setComment(""); setErr(""); setDone(false);
  }
  const teacher = session ? byId(session.teacherId) : undefined;
  const labels: [keyof RatingSet, string][] = [["teaching", "Teaching Quality"], ["knowledge", "Knowledge of Subject"], ["communication", "Communication"], ["experience", "Session Experience"]];
  return (
    <Modal open={!!session} onClose={onClose} title={done ? "Thanks for your rating!" : `Rate ${teacher?.name ?? "your teacher"}`}>
      {done ? (
        <div className="flex flex-col items-center py-6 text-center">
          <motion.span initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", damping: 12 }} className="flex h-20 w-20 items-center justify-center rounded-full bg-teal-strong text-white shadow-[0_0_40px_6px_rgb(246_201_204/.9)]"><Check className="h-10 w-10" strokeWidth={3} /></motion.span>
          <p className="mt-5 font-bold text-navy">Rating submitted</p>
          <p className="mt-1 text-sm text-subtle">{teacher?.name}'s {session?.skill} rating and trust score were recalculated. You can edit your review for 7 days.</p>
          <Button className="mt-6" onClick={onClose}>Done</Button>
        </div>
      ) : (
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if (!session) return; const r = submitReview(session.id, stars, ratings, qualities, comment); if (!r.ok) return setErr(r.error); setDone(true); toast("Rating submitted. Thank you!"); }}>
          <p className="text-sm text-subtle">{session?.skill} · {session && fmtDate(session)}</p>
          <div className="rounded-2xl bg-blush-soft p-4"><StarInput label="Overall rating" value={stars} onChange={setStars} /></div>
          <div className="neu-inset space-y-3 rounded-2xl p-4">{labels.map(([k, l]) => <StarInput key={k} label={l} value={ratings[k]} onChange={(v) => setRatings((r) => ({ ...r, [k]: v }))} />)}</div>
          <div>
            <p className="mb-2 text-sm font-semibold text-ink">What stood out? (optional)</p>
            <div className="flex flex-wrap gap-2">{QUALITIES.map((q) => { const on = qualities.includes(q); return <button type="button" key={q} aria-pressed={on} onClick={() => setQualities(on ? qualities.filter((x) => x !== q) : [...qualities, q])} className={cn("rounded-full px-3 py-1 text-xs font-semibold", on ? "bg-teal-strong text-white" : "neu-sm text-ink")}>{q}</button>; })}</div>
          </div>
          <Field label="Written feedback" htmlFor="rv-c" hint="Be specific and kind. This helps other students choose."><Textarea id="rv-c" rows={3} value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder="What went well? What could be better?" /></Field>
          {err && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err}</p>}
          <Button type="submit" className="w-full"><Star className="h-4 w-4" /> Submit rating</Button>
        </form>
      )}
    </Modal>
  );
}

/* ---------- report ---------- */
export function ReportModal({ open, onClose, targetType, targetId, label }: { open: boolean; onClose: () => void; targetType: Report["targetType"]; targetId: string; label: string }) {
  const { report } = useStore();
  const toast = useToast();
  const [reason, setReason] = useState("");
  const [err, setErr] = useState("");
  return (
    <Modal open={open} onClose={onClose} title={`Report ${label}`}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); const r = report(targetType, targetId, reason); if (!r.ok) return setErr(r.error); toast("Report sent. Our moderators will review it.", "info"); setReason(""); onClose(); }}>
        <p className="flex gap-2 text-sm text-subtle"><ShieldAlert className="h-4 w-4 shrink-0 text-rose" /> Reports are confidential. Moderators review every report against the Community Guidelines.</p>
        <Field label="What happened?" htmlFor="rp"><Textarea id="rp" rows={4} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={600} /></Field>
        {err && <p className="text-sm font-semibold text-rose" role="alert">{err}</p>}
        <Button type="submit" variant="danger" className="w-full"><Flag className="h-4 w-4" /> Submit report</Button>
      </form>
    </Modal>
  );
}

export function MessageButton({ student, size = "sm" }: { student: Student; size?: "sm" | "md" }) {
  return <Button size={size} variant="secondary" href={`/messages?with=${student.id}`}><MessageCircle className="h-4 w-4" /> Message</Button>;
}
