"use client";
import { Bell, Check } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Badge, Button, Card, EmptyState, PageHeader, Tabs, cn } from "@/components/ui";
import { useStore } from "@/lib/store";

export default function Notifications() {
  const { db, me, markRead } = useStore();
  const [tab, setTab] = useState<"all" | "unread">("all");
  if (!me) return null;
  const all = db.notifications.filter((n) => n.userId === me.id);
  const list = tab === "unread" ? all.filter((n) => !n.read) : all;
  return (
    <div className="max-w-3xl">
      <PageHeader title="Notifications" subtitle="Your notification history." action={<div className="flex gap-2"><Button variant="secondary" href="/settings#notifications">Preferences</Button><Button onClick={() => markRead()} disabled={!all.some((n) => !n.read)}><Check className="h-4 w-4" /> Mark all read</Button></div>} />
      <div className="mb-5"><Tabs value={tab} onChange={setTab} tabs={[{ value: "all", label: "All", count: all.length }, { value: "unread", label: "Unread", count: all.filter((n) => !n.read).length }]} /></div>
      {list.length ? (
        <Card className="p-0"><ul className="divide-y divide-line">{list.map((n) => (
          <li key={n.id} className={cn("flex items-start gap-3 px-5 py-4", !n.read && "bg-blush-soft/40")}>
            <span className={cn("mt-2 h-2 w-2 shrink-0 rounded-full", n.read ? "bg-transparent" : "bg-blush-ink")} />
            <Link href={n.href} onClick={() => markRead(n.id)} className="min-w-0 flex-1"><span className="block text-sm text-ink">{n.text}</span><span className="text-xs text-subtle">{new Date(n.createdAt).toLocaleString(undefined, { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}</span></Link>
            <Badge tone="neutral">{n.kind}</Badge>
            {!n.read && <button onClick={() => markRead(n.id)} className="text-xs font-semibold text-teal-strong hover:underline">Mark read</button>}
          </li>
        ))}</ul></Card>
      ) : <Card><EmptyState icon={Bell} title="You're all caught up" text="New requests, ratings and messages will show up here." /></Card>}
    </div>
  );
}
