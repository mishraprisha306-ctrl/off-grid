"use client";
import { BadgeCheck, FileText, Link2, Paperclip, Save, Trash2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { useStats } from "@/components/domain";
import { LearnEditor, SlotEditor, TeachEditor } from "@/components/profile-forms";
import { useToast } from "@/components/toast";
import { Avatar, Badge, Button, Card, Field, Input, MentorBadge, PageHeader, Select, SkillChip, Stars } from "@/components/ui";
import { yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FORMATS, type SessionFormat, type Student } from "@/lib/types";

const CERT_LABEL = { self: { t: "Self-reported", tone: "neutral" }, evidence: { t: "Evidence attached", tone: "amber" }, verified: { t: "Verified by admin", tone: "green" } } as const;

export default function MySkills() {
  const { me, updateMe, addCertificate, removeCertificate } = useStore();
  const toast = useToast();
  const [d, setD] = useState<Student>(() => structuredClone(me!));
  const [cert, setCert] = useState({ title: "", url: "" });
  const [certErr, setCertErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const stats = useStats(me!.id);
  if (!me) return null;
  const dirty = JSON.stringify({ t: d.teach, l: d.learn, s: d.slots, m: d.mode, f: d.formats, k: d.links }) !== JSON.stringify({ t: me.teach, l: me.learn, s: me.slots, m: me.mode, f: me.formats, k: me.links });

  const save = () => {
    if (!d.teach.length || !d.learn.length) return toast("Keep at least one skill to teach and one to learn.", "error");
    for (const [k, v] of Object.entries(d.links)) if (v && !/^https:\/\/\S+$/.test(v)) return toast(`${k} link must start with https://`, "error");
    const r = updateMe({ teach: d.teach, learn: d.learn, slots: d.slots, mode: d.mode, formats: d.formats, links: d.links });
    toast(r.ok ? "Skills saved. Matches updated." : r.error, r.ok ? "success" : "error");
  };

  return (
    <div>
      <PageHeader title="My Skills" subtitle="What you can teach, what you want to learn, and the evidence behind it." action={<Button onClick={save} disabled={!dirty}><Save className="h-4 w-4" /> {dirty ? "Save changes" : "Saved"}</Button>} />
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <Card><h2 className="mb-4 font-bold text-navy">Skills I can teach</h2><TeachEditor value={d.teach} learn={d.learn} onChange={(teach) => setD({ ...d, teach })} /></Card>
          <Card><h2 className="mb-4 font-bold text-navy">Skills I want to learn</h2><LearnEditor value={d.learn} teach={d.teach} onChange={(learn) => setD({ ...d, learn })} /></Card>
          <Card>
            <h2 className="mb-4 font-bold text-navy">Availability & preferences</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Preferred mode" htmlFor="ms-m"><Select id="ms-m" value={d.mode} onChange={(e) => setD({ ...d, mode: e.target.value as Student["mode"] })}><option value="both">Online & offline</option><option value="online">Online</option><option value="offline">Offline</option></Select></Field>
              <div><p className="mb-2 text-sm font-semibold text-ink">Session types</p><div className="flex gap-4 pt-2">{FORMATS.map((f) => <label key={f} className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={d.formats.includes(f)} onChange={(e) => setD({ ...d, formats: e.target.checked ? [...d.formats, f] : d.formats.filter((x: SessionFormat) => x !== f) })} /> {f}</label>)}</div></div>
            </div>
            <div className="mt-4"><p className="mb-2 text-sm font-semibold text-ink">Available time slots</p><SlotEditor value={d.slots} onChange={(slots) => setD({ ...d, slots })} /></div>
          </Card>
          <Card>
            <h2 className="mb-1 font-bold text-navy">Portfolio & links</h2>
            <p className="mb-4 text-sm text-subtle">Shown on your profile unless you hide links in Settings → Privacy.</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {(["github", "linkedin", "portfolio"] as const).map((k) => <Field key={k} label={k === "github" ? "GitHub" : k === "linkedin" ? "LinkedIn" : "Portfolio"} htmlFor={`l-${k}`}><Input id={`l-${k}`} placeholder="https://…" value={d.links[k] ?? ""} onChange={(e) => setD({ ...d, links: { ...d.links, [k]: e.target.value.trim() || undefined } })} /></Field>)}
            </div>
          </Card>
          <Card>
            <h2 className="mb-1 font-bold text-navy">Certificates & evidence</h2>
            <p className="mb-4 text-sm text-subtle">We never show a claim as verified unless an admin has checked it.</p>
            <ul className="mb-4 space-y-2">
              {me.certificates.map((c) => (
                <li key={c.id} className="flex items-center gap-3 neu-inset rounded-2xl p-3">
                  <FileText className="h-5 w-5 text-teal-strong" />
                  <span className="min-w-0 flex-1"><span className="block truncate font-semibold text-navy">{c.title}</span>{c.url && <a href={c.url} target="_blank" rel="noreferrer" className="text-xs font-semibold text-teal-strong hover:underline">{c.url.startsWith("data:") ? "View uploaded file" : "Open link"}</a>}</span>
                  <Badge tone={CERT_LABEL[c.status].tone}>{c.status === "verified" && <BadgeCheck className="h-3 w-3" />}{CERT_LABEL[c.status].t}</Badge>
                  <button onClick={() => removeCertificate(c.id)} className="rounded-lg p-2 text-muted hover:text-rose" aria-label={`Delete ${c.title}`}><Trash2 className="h-4 w-4" /></button>
                </li>
              ))}
              {!me.certificates.length && <li className="text-sm text-subtle">No certificates yet.</li>}
            </ul>
            <div className="grid gap-2 sm:grid-cols-[1.2fr_1.2fr_auto_auto]">
              <Input placeholder="Certificate title" value={cert.title} onChange={(e) => setCert({ ...cert, title: e.target.value })} aria-label="Certificate title" />
              <Input placeholder="Link (https://…)" value={cert.url.startsWith("data:") ? "File attached" : cert.url} onChange={(e) => setCert({ ...cert, url: e.target.value })} aria-label="Certificate link" disabled={cert.url.startsWith("data:")} />
              <input ref={fileRef} type="file" accept="application/pdf,image/png,image/jpeg" className="hidden" onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                if (!["application/pdf", "image/png", "image/jpeg"].includes(f.type)) return setCertErr("Only PDF, PNG or JPG files.");
                if (f.size > 300_000) return setCertErr("Demo mode stores files in your browser, so keep them under 300 KB. Supabase Storage allows larger files.");
                const rd = new FileReader();
                rd.onload = () => { setCert((c) => ({ ...c, url: String(rd.result) })); setCertErr(""); };
                rd.readAsDataURL(f);
              }} />
              <Button type="button" variant="secondary" onClick={() => fileRef.current?.click()}><Upload className="h-4 w-4" /> File</Button>
              <Button type="button" onClick={() => { const r = addCertificate(cert); if (!r.ok) return setCertErr(r.error); setCert({ title: "", url: "" }); setCertErr(""); toast("Certificate added. An admin can verify it."); }}><Paperclip className="h-4 w-4" /> Add</Button>
            </div>
            {certErr && <p className="mt-2 text-xs font-semibold text-rose" role="alert">{certErr}</p>}
          </Card>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="mb-3 text-xs font-bold tracking-wide text-muted uppercase">Your skill card preview</p>
          <Card className="relative overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-24 bg-navy" />
            <span aria-hidden className="absolute top-6 right-8 h-16 w-16 rounded-full bg-[#f6c9cc]/30 shadow-[0_0_40px_14px_rgb(246_201_204/.35)]" />
            <div className="relative flex flex-col items-center pt-8 text-center">
              <Avatar name={me.name} src={me.avatar} size={84} />
              <p className="mt-3 text-xl font-extrabold text-navy">{me.name}</p>
              <p className="text-sm text-subtle">{me.department} · {yearLabel(me.year)}</p>
              <div className="mt-2 flex flex-wrap justify-center gap-2">{stats.mentor && <MentorBadge small />}<Stars value={stats.rating.average} size={13} showValue count={stats.rating.count} /></div>
            </div>
            <div className="relative mt-6 space-y-4">
              <div><p className="mb-2 text-xs font-bold tracking-wide text-muted uppercase">Can teach</p><div className="flex flex-wrap gap-1.5">{d.teach.map((t) => <SkillChip key={t.name}>{t.name} · {t.level}</SkillChip>)}</div></div>
              <div><p className="mb-2 text-xs font-bold tracking-wide text-muted uppercase">Wants to learn</p><div className="flex flex-wrap gap-1.5">{d.learn.map((t) => <SkillChip key={t.name} tone="teal">{t.name}</SkillChip>)}</div></div>
              {Object.values(d.links).some(Boolean) && <p className="flex items-center gap-1.5 text-xs text-subtle"><Link2 className="h-3.5 w-3.5" /> {Object.entries(d.links).filter(([, v]) => v).map(([k]) => k).join(" · ")}</p>}
            </div>
          </Card>
        </aside>
      </div>
    </div>
  );
}
