"use client";
import { Award, Lock } from "lucide-react";
import { Card, PageHeader, cn } from "@/components/ui";
import { achievements } from "@/lib/engines";
import { useStore } from "@/lib/store";

export default function Achievements() {
  const { db, me } = useStore();
  if (!me) return null;
  const list = achievements(me, db);
  const got = list.filter((a) => a.got).length;
  return (
    <div>
      <PageHeader title="Achievements" subtitle={`${got} of ${list.length} badges earned. Every badge comes from real activity.`} />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {list.map((a) => (
          <Card key={a.id} className={cn("text-center", !a.got && "opacity-60")}>
            <span className={cn("mx-auto flex h-16 w-16 items-center justify-center rounded-2xl", a.got ? "bg-teal-strong text-white shadow-[0_0_28px_4px_rgb(246_201_204/.9)]" : "neu-inset text-muted")}>{a.got ? <Award className="h-8 w-8" /> : <Lock className="h-6 w-6" />}</span>
            <p className="mt-4 font-bold text-navy">{a.label}</p>
            <p className="mt-1 text-sm text-subtle">{a.desc}</p>
            <p className={cn("mt-3 text-xs font-bold uppercase", a.got ? "text-teal-strong" : "text-muted")}>{a.got ? "Earned" : "Locked"}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
