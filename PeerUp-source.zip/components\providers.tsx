"use client";
import { MotionConfig } from "framer-motion";
import { StoreProvider } from "@/lib/store";
import WavyBackground from "./ui/blue-meshy-background";
import { Intro } from "./intro";
import { ToastProvider } from "./toast";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <MotionConfig reducedMotion="user">
      {/* site-wide backdrop: fixed, behind everything, barely visible */}
      <WavyBackground className="pointer-events-none !fixed inset-0 -z-10 h-dvh opacity-90" />
      <StoreProvider>
        <ToastProvider>
          <Intro />
          {children}
        </ToastProvider>
      </StoreProvider>
    </MotionConfig>
  );
}
