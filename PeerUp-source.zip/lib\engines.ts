import type { DB, RatingSet, Review, Session, Student } from "./types";

/* ================= skill normalisation ================= */
const ALIASES: Record<string, string> = {
  "ui/ux design": "ui/ux", "ui ux": "ui/ux", "ux/ui": "ui/ux", "ui and ux design": "ui/ux", "ui/ux": "ui/ux",
  js: "javascript", "c programming": "c", c: "c", "c and c++": "c++", cpp: "c++",
  "web dev": "web development", ml: "machine learning", "graphic designing": "graphic design",
  "communication skills": "communication", "maths": "mathematics", math: "mathematics",
  "business and management": "business management", "html/css": "html & css",
};
export function normSkill(s: string) {
  const k = s.trim().toLowerCase().replace(/\s+/g, " ");
  return ALIASES[k] ?? k;
}
function intersect(teach: string[], learn: string[]) {
  const wanted = new Set(learn.map(normSkill));
  return teach.filter((t) => wanted.has(normSkill(t)));
}

/* ================= matching ================= */
export interface Match {
  student: Student;
  iTeach: string[];
  theyTeach: string[];
  kind: "mutual" | "learn" | "teach";
  percent: number;
  perfect: boolean;
  explanation: string;
}

/**
 * Mutual = A teaches ≥1 skill B wants AND B teaches ≥1 skill A wants (one-way never counts as mutual).
 * Percent = 50 × (share of my wish list they cover) + 50 × (share of theirs I cover).
 * One-way matches score only the covered side and are listed separately.
 */
export function computeMatch(me: Student, other: Student): Match | null {
  if (me.id === other.id || other.suspended || other.role === "admin") return null;
  if (me.blocked.includes(other.id) || other.blocked.includes(me.id)) return null;
  const iTeach = intersect(me.teach.map((t) => t.name), other.learn.map((l) => l.name));
  const theyTeach = intersect(other.teach.map((t) => t.name), me.learn.map((l) => l.name));
  if (!iTeach.length && !theyTeach.length) return null;
  const covMine = me.learn.length ? theyTeach.length / me.learn.length : 0;
  const covTheirs = other.learn.length ? iTeach.length / other.learn.length : 0;
  const first = other.name.split(" ")[0];
  const list = (a: string[]) => a.join(", ");
  if (iTeach.length && theyTeach.length) {
    const percent = Math.round(50 * covMine + 50 * covTheirs);
    return { student: other, iTeach, theyTeach, kind: "mutual", percent, perfect: percent === 100,
      explanation: `You can teach ${first} ${list(iTeach)} while ${first} can teach you ${list(theyTeach)}.` };
  }
  if (theyTeach.length)
    return { student: other, iTeach, theyTeach, kind: "learn", percent: Math.round(100 * covMine), perfect: false,
      explanation: `${first} can teach you ${list(theyTeach)}. You don't yet teach anything ${first} wants.` };
  return { student: other, iTeach, theyTeach, kind: "teach", percent: Math.round(100 * covTheirs), perfect: false,
    explanation: `${first} wants to learn ${list(iTeach)}, which you can teach.` };
}

export function allMatches(me: Student, students: Student[]) {
  const list = students.map((s) => computeMatch(me, s)).filter((m): m is Match => !!m);
  const sort = (a: Match, b: Match) => b.percent - a.percent || b.iTeach.length + b.theyTeach.length - (a.iTeach.length + a.theyTeach.length) || a.student.name.localeCompare(b.student.name);
  return {
    mutual: list.filter((m) => m.kind === "mutual").sort(sort),
    learn: list.filter((m) => m.kind === "learn").sort(sort),
    teach: list.filter((m) => m.kind === "teach").sort(sort),
  };
}

/* ================= ratings ================= */
export const RATING_LABELS: Record<keyof RatingSet, string> = {
  teaching: "Teaching Quality",
  knowledge: "Knowledge of Subject",
  communication: "Communication",
  experience: "Session Experience",
};
export const QUALITIES = ["Clear explanations", "Patient", "Well prepared", "Practical examples", "Punctual", "Encouraging", "Shared resources"];
export const reviewScore = (r: Review) => r.stars;
export const MIN_SKILL_REVIEWS = 2;

export interface RatingSummary {
  count: number;
  average: number | null;
  categories: Record<keyof RatingSet, number | null>;
  bySkill: { skill: string; average: number; count: number; enough: boolean }[];
  distribution: { stars: number; count: number }[];
  qualities: { quality: string; count: number }[];
}

/** Average = sum of eligible star ratings ÷ number of eligible ratings (e.g. 5,4,5,4 → 4.5). */
export function ratingSummary(studentId: string, reviews: Review[], opts: { mentorship?: boolean; since?: number } = {}): RatingSummary {
  const mine = reviews.filter((r) =>
    r.revieweeId === studentId && r.reviewerId !== studentId &&
    (opts.mentorship === undefined || r.mentorship === opts.mentorship) &&
    (!opts.since || new Date(r.createdAt).getTime() >= opts.since));
  const avg = (ns: number[]) => (ns.length ? ns.reduce((a, b) => a + b, 0) / ns.length : null);
  const bySkill = new Map<string, number[]>();
  const q = new Map<string, number>();
  for (const r of mine) {
    bySkill.set(r.skill, [...(bySkill.get(r.skill) ?? []), r.stars]);
    r.qualities.forEach((x) => q.set(x, (q.get(x) ?? 0) + 1));
  }
  return {
    count: mine.length,
    average: avg(mine.map((r) => r.stars)),
    categories: {
      teaching: avg(mine.map((r) => r.ratings.teaching)),
      knowledge: avg(mine.map((r) => r.ratings.knowledge)),
      communication: avg(mine.map((r) => r.ratings.communication)),
      experience: avg(mine.map((r) => r.ratings.experience)),
    },
    bySkill: [...bySkill.entries()].map(([skill, ns]) => ({ skill, average: avg(ns)!, count: ns.length, enough: ns.length >= MIN_SKILL_REVIEWS })).sort((a, b) => b.average - a.average),
    distribution: [5, 4, 3, 2, 1].map((stars) => ({ stars, count: mine.filter((r) => r.stars === stars).length })),
    qualities: [...q.entries()].map(([quality, count]) => ({ quality, count })).sort((a, b) => b.count - a.count),
  };
}

/* ================= trust score ================= */
export const TRUST_RULES = { minReviews: 3, minCommitted: 3, sessionCap: 20, consistencyMin: 4 };

export interface TrustBreakdown {
  total: number;
  ratingPts: number;
  sessionPts: number;
  consistencyPts: number;
  reliabilityPts: number;
  completedTeaching: number;
  committed: number;
  reviewCount: number;
  average: number | null;
  /** false = not enough evidence yet: show "New · building trust" instead of a low number */
  established: boolean;
  verified: boolean;
}

/**
 * Trust (0–100), independent of academic year or mentor badge:
 *  • Rating       up to 50 = avg/5 × 50, weighted by evidence until 3 reviews (no rating ≠ 5★)
 *  • Sessions     up to 20 = 20 × ln(1+n)/ln(21), n = completed teaching sessions only
 *  • Consistency  up to 15 = share of reviews ≥ 4★ × 15 (needs 3 reviews)
 *  • Reliability  up to 15 = completed ÷ (completed + cancelled-after-accepting) × 15 (needs 3)
 * New members with too little evidence are shown as "New", not penalised with a low number.
 */
export function trustScore(studentId: string, db: Pick<DB, "sessions" | "reviews">, since?: number): TrustBreakdown {
  const inWin = (s: Session) => !since || new Date(`${s.date}T${s.time}:00`).getTime() >= since;
  const teaching = db.sessions.filter((s) => s.teacherId === studentId && inWin(s));
  const completedTeaching = teaching.filter((s) => s.status === "Completed").length;
  const committed = teaching.filter((s) => s.wasAccepted && (s.status === "Completed" || s.status === "Cancelled")).length;
  const rs = ratingSummary(studentId, db.reviews, { since });
  const evidence = Math.min(1, rs.count / TRUST_RULES.minReviews);
  const ratingPts = rs.average === null ? 0 : (rs.average / 5) * 50 * evidence;
  const sessionPts = Math.min(20, (20 * Math.log(1 + completedTeaching)) / Math.log(1 + TRUST_RULES.sessionCap));
  const positive = db.reviews.filter((r) => r.revieweeId === studentId && r.stars >= TRUST_RULES.consistencyMin && (!since || new Date(r.createdAt).getTime() >= since)).length;
  const consistencyPts = rs.count >= TRUST_RULES.minReviews ? (positive / rs.count) * 15 : 0;
  const relEvidence = Math.min(1, committed / TRUST_RULES.minCommitted);
  const reliabilityPts = committed ? Math.min(15, 15 * (completedTeaching / committed) * relEvidence) : 0;
  const total = Math.min(100, Math.round(ratingPts + sessionPts + consistencyPts + reliabilityPts));
  return {
    total, ratingPts, sessionPts, consistencyPts, reliabilityPts, completedTeaching, committed,
    reviewCount: rs.count, average: rs.average,
    established: rs.count >= TRUST_RULES.minReviews && completedTeaching >= TRUST_RULES.minReviews,
    verified: completedTeaching > 0 && rs.count > 0,
  };
}

/* ================= senior mentor eligibility (separate from trust) ================= */
export interface MentorCheck { eligible: boolean; criteria: { label: string; met: boolean }[] }
export function mentorCheck(s: Student, db: DB): MentorCheck {
  const st = db.settings;
  const t = trustScore(s.id, db);
  const openReports = db.reports.some((r) => r.targetType === "user" && r.targetId === s.id && r.status === "open");
  const criteria = [
    { label: `Year ${st.mentorMinYear}+ or proven experience (Advanced in a skill)`, met: s.year >= st.mentorMinYear || (s.year === 0 && s.teach.some((x) => x.level === "Advanced")) },
    { label: `${st.mentorMinSessions}+ completed teaching sessions`, met: t.completedTeaching >= st.mentorMinSessions },
    { label: `Average ${st.mentorMinRating.toFixed(1)}★+ from ${TRUST_RULES.minReviews}+ reviews`, met: t.reviewCount >= TRUST_RULES.minReviews && (t.average ?? 0) >= st.mentorMinRating },
    { label: "No unresolved conduct reports", met: !openReports },
  ];
  return { eligible: criteria.every((c) => c.met), criteria };
}
/** Badge shown only when criteria are met AND an admin has not rejected; admin approval overrides. */
export const isMentor = (s: Student, db: DB) =>
  !s.suspended && s.role !== "admin" && s.mentorStatus !== "rejected" && (s.mentorStatus === "approved" || mentorCheck(s, db).eligible);

/* ================= sessions & timing ================= */
export const sessionStart = (s: Session) => new Date(`${s.date}T${s.time}:00`);
export const sessionEnd = (s: Session) => new Date(sessionStart(s).getTime() + s.duration * 60_000);
export const participants = (s: Session) => [s.teacherId, s.learnerId, ...s.groupIds];
export const sessionTypeLabel = (s: Session) => `${s.mode} ${s.format}`;

export type TimeState = { kind: "future" | "soon" | "live" | "ended"; label: string };
export function timeState(s: Session, now: number): TimeState {
  const start = sessionStart(s).getTime();
  const end = start + s.duration * 60_000;
  const mins = Math.round((start - now) / 60_000);
  if (now >= end) return { kind: "ended", label: `Ended ${relative(now - end)} ago` };
  if (now >= start) return { kind: "live", label: `Live now · ${Math.ceil((end - now) / 60_000)} min left` };
  if (mins <= 60) return { kind: "soon", label: `Starts in ${Math.max(1, mins)} min` };
  return { kind: "future", label: `Starts in ${relative(start - now)}` };
}
export function relative(ms: number) {
  const m = Math.round(ms / 60_000);
  if (m < 60) return `${Math.max(1, m)} min`;
  const h = Math.round(m / 60);
  if (h < 48) return `${h} hr${h > 1 ? "s" : ""}`;
  return `${Math.round(h / 24)} days`;
}
export function overlaps(a: Session, b: Session) {
  return sessionStart(a) < sessionEnd(b) && sessionStart(b) < sessionEnd(a);
}

/* ================= profile helpers ================= */
export function profileCompletion(s: Student) {
  const checks = [!!s.name, !!s.avatar, !!s.college, !!s.department, s.year !== undefined, s.bio.trim().length >= 20,
    s.interests.length > 0, s.teach.length > 0, s.learn.length > 0, s.slots.length > 0, !!(s.links.github || s.links.linkedin || s.links.portfolio)];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}
export const yearLabel = (y: number) => (y === 0 ? "Other" : `${y}${["st", "nd", "rd", "th", "th"][Math.min(y, 5) - 1]} Year`);
export const initials = (name: string) => name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

/* ================= achievements ================= */
export interface Achievement { id: string; label: string; desc: string; got: boolean }
export function achievements(s: Student, db: DB): Achievement[] {
  const mine = db.sessions.filter((x) => x.status === "Completed" && participants(x).includes(s.id));
  const taught = mine.filter((x) => x.teacherId === s.id).length;
  const learned = mine.filter((x) => x.learnerId === s.id || x.groupIds.includes(s.id)).length;
  const rs = ratingSummary(s.id, db.reviews);
  const helpful = db.reviews.filter((r) => r.reviewerId === s.id && r.helpful.length > 0).length;
  return [
    { id: "first-session", label: "First Session Completed", desc: "Complete any session", got: mine.length >= 1 },
    { id: "first-skill", label: "First Skill Shared", desc: "Teach your first session", got: taught >= 1 },
    { id: "ten", label: "10 Sessions Completed", desc: "Complete 10 sessions", got: mine.length >= 10 },
    { id: "top-mentor", label: "Top Rated Mentor", desc: "4.8★+ from 5+ reviews", got: rs.count >= 5 && (rs.average ?? 0) >= 4.8 },
    { id: "learner", label: "Consistent Learner", desc: "Attend 3+ sessions", got: learned >= 3 },
    { id: "helpful", label: "Helpful Peer", desc: "Write a review others found helpful", got: helpful >= 1 },
    { id: "portfolio", label: "Verified Portfolio", desc: "Have a certificate verified by an admin", got: s.certificates.some((c) => c.status === "verified") },
  ];
}

/* ================= recommendations ================= */
const NEXT: Record<string, string[]> = {
  html: ["CSS", "JavaScript"], css: ["JavaScript", "UI/UX Design"], "html & css": ["JavaScript"], javascript: ["React", "Node.js"],
  python: ["Data Science", "Machine Learning"], c: ["C++", "Data Structures"], java: ["Data Structures", "Spring Boot"],
  figma: ["UI/UX Design"], "graphic design": ["Figma", "Video Editing"], "ui/ux": ["Figma", "HTML & CSS"],
  "data science": ["Machine Learning", "SQL"], sql: ["Data Science"], calculus: ["Linear Algebra"], biology: ["Biochemistry"],
  chemistry: ["Biochemistry"], "public speaking": ["Business English"], "digital marketing": ["Graphic Design"],
};
export function recommendSkills(s: Student) {
  const have = new Set([...s.teach.map((t) => normSkill(t.name)), ...s.learn.map((l) => normSkill(l.name))]);
  const out = new Map<string, string>();
  for (const k of [...s.teach.map((t) => t.name), ...s.learn.map((l) => l.name), ...s.interests]) {
    for (const n of NEXT[normSkill(k)] ?? []) if (!have.has(normSkill(n)) && !out.has(n)) out.set(n, k);
  }
  return [...out.entries()].slice(0, 6).map(([skill, because]) => ({ skill, because }));
}

export const CHALLENGES = [
  { id: "code7", title: "7-Day Coding Streak", kind: "Coding", days: 7, desc: "Solve one problem a day for a week." },
  { id: "design7", title: "Daily UI, 7 days", kind: "Creative", days: 7, desc: "Design one small interface every day." },
  { id: "mini5", title: "Mini Project Sprint", kind: "Mini Project", days: 5, desc: "Ship a tiny project in five steps." },
  { id: "teach3", title: "Teach-back Challenge", kind: "Learning", days: 3, desc: "Explain one concept you learned each day." },
];
