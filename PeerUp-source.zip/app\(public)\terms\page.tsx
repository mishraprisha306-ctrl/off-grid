import { Legal } from "@/components/legal";
export const metadata = { title: "Terms and Conditions" };
export default function Page() {
  return <Legal title="Terms and Conditions" subtitle="The rules for using PeerUp." sections={[
    ["Eligibility", ["PeerUp is for students. Provide accurate academic details.", "One account per person. Don't impersonate anyone."]],
    ["Sessions", ["Sessions are arranged between students; PeerUp doesn't employ or vet teachers beyond the published mentor criteria.", "Only mark a session completed if it actually happened. Both participants confirm completion.", "Meet offline only in safe, public, mutually agreed locations."]],
    ["Ratings and reviews", ["Only learners in completed sessions may rate, once per session.", "Reviews must be honest and respectful. Moderators may remove reviews that break the Community Guidelines."]],
    ["Content and copyright", ["Share only resources you have the right to share.", "Never record a live session without every participant's knowledge and consent."]],
    ["Enforcement", ["Accounts that break these terms or the Community Guidelines may be suspended."]],
  ]} />;
}
