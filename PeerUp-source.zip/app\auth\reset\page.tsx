"use client";
import { useState } from "react";
import { Button, Field, Input } from "@/components/ui";
import { auth, isSupabaseConfigured } from "@/lib/auth";

export default function Reset() {
  const [pw, setPw] = useState("");
  const [state, setState] = useState<{ ok?: boolean; error?: string }>({});
  return (
    <div className="mx-auto grid min-h-dvh max-w-md place-items-center p-6">
      <form
        className="w-full space-y-4 rounded-[20px] bg-ivory p-8 shadow-[var(--shadow-raised)]"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!isSupabaseConfigured) return setState({ error: "Password reset needs Supabase to be configured." });
          if (pw.length < 8 || !/[A-Z]/.test(pw) || !/\d/.test(pw) || !/[^A-Za-z0-9]/.test(pw)) return setState({ error: "Use 8+ characters with an uppercase letter, a number and a symbol." });
          const r = await auth.updatePassword(pw);
          setState(r.ok ? { ok: true } : { error: r.error });
        }}
      >
        <h1 className="text-2xl font-extrabold text-navy">Choose a new password</h1>
        {state.ok ? <><p className="text-subtle">Password updated.</p><Button href="/login" className="w-full">Sign in</Button></> : <>
          <Field label="New password" htmlFor="np"><Input id="np" type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
          {state.error && <p className="text-sm font-semibold text-rose" role="alert">{state.error}</p>}
          <Button type="submit" className="w-full">Update password</Button>
        </>}
      </form>
    </div>
  );
}
