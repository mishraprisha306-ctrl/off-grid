import { PublicPage } from "./public-chrome";

export function Legal({ title, subtitle, sections }: { title: string; subtitle: string; sections: [string, string[]][] }) {
  return (
    <PublicPage title={title} subtitle={subtitle}>
      <p className="rounded-xl bg-[#f7ecd6] px-4 py-3 text-sm text-[#7a520b]">Template for the PeerUp project. Have it reviewed by your institution or a lawyer before a public launch.</p>
      {sections.map(([h, ps]) => (
        <section key={h}>
          <h2 className="text-xl font-extrabold text-navy">{h}</h2>
          <ul className="mt-2 list-disc space-y-1.5 pl-5 text-subtle">{ps.map((p) => <li key={p}>{p}</li>)}</ul>
        </section>
      ))}
    </PublicPage>
  );
}
