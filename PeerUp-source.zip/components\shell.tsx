"use client";
import { AnimatePresence, motion } from "framer-motion";
import {
  Award, Bell, BookOpen, CalendarDays, CalendarRange, ChevronsLeft, ChevronsRight, Compass, Flag, Flame, GraduationCap, HelpCircle, IdCard,
  LayoutDashboard, LogOut, Menu, MessageCircle, Search, Settings, ShieldCheck, Star, TrendingUp, Trophy, User, UserPlus, Users, X,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { normSkill, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { Logo } from "./logo";
import { useToast } from "./toast";
import { Avatar, Button, cn } from "./ui";

type Item = { label: string; icon: React.ElementType; href: string };
export const NAV_GROUPS: { title: string; items: Item[] }[] = [
  { title: "Home", items: [
    { label: "Dashboard", icon: LayoutDashboard, href: "/dashboard" },
    { label: "My Profile", icon: User, href: "/profile" },
    { label: "My Skills", icon: IdCard, href: "/my-skills" },
  ] },
  { title: "Discover", items: [
    { label: "Explore Skills", icon: Compass, href: "/explore" },
    { label: "Mutual Matches", icon: Users, href: "/matches" },
    { label: "Connections", icon: UserPlus, href: "/connections" },
    { label: "Senior Mentors", icon: GraduationCap, href: "/mentors" },
  ] },
  { title: "Learn", items: [
    { label: "Sessions", icon: CalendarDays, href: "/sessions" },
    { label: "Calendar", icon: CalendarRange, href: "/calendar" },
    { label: "Messages", icon: MessageCircle, href: "/messages" },
    { label: "Learning Progress", icon: TrendingUp, href: "/progress" },
    { label: "Resources", icon: BookOpen, href: "/resources" },
    { label: "Challenges", icon: Flame, href: "/challenges" },
  ] },
  { title: "Reputation", items: [
    { label: "Ratings & Reviews", icon: Star, href: "/reviews" },
    { label: "Trust Score", icon: ShieldCheck, href: "/trust" },
    { label: "Leaderboard", icon: Trophy, href: "/leaderboard" },
    { label: "Achievements", icon: Award, href: "/achievements" },
  ] },
];
const ADMIN_GROUPS: { title: string; items: Item[] }[] = [
  { title: "Admin", items: [
    { label: "Admin Dashboard", icon: LayoutDashboard, href: "/admin" },
    { label: "Users", icon: Users, href: "/admin?tab=users" },
    { label: "Reports", icon: Flag, href: "/admin?tab=reports" },
    { label: "Moderation", icon: ShieldCheck, href: "/admin?tab=moderation" },
    { label: "Mentor Verification", icon: GraduationCap, href: "/admin?tab=mentors" },
    { label: "Skill Management", icon: IdCard, href: "/admin?tab=skills" },
    { label: "Sessions", icon: CalendarDays, href: "/admin?tab=sessions" },
    { label: "Analytics", icon: TrendingUp, href: "/admin?tab=analytics" },
    { label: "Support", icon: HelpCircle, href: "/admin?tab=support" },
  ] },
];
const BOTTOM: Item[] = [
  { label: "Notifications", icon: Bell, href: "/notifications" },
  { label: "Settings", icon: Settings, href: "/settings" },
  { label: "Help & Support", icon: HelpCircle, href: "/help" },
];
const MOBILE: Item[] = [
  { label: "Home", icon: LayoutDashboard, href: "/dashboard" },
  { label: "Explore", icon: Compass, href: "/explore" },
  { label: "Matches", icon: Users, href: "/matches" },
  { label: "Sessions", icon: CalendarDays, href: "/sessions" },
];

const isActive = (path: string, href: string) => {
  if (href.includes("?")) return false;
  return path === href || (href !== "/admin" && path.startsWith(href + "/"));
};

function useLogout() {
  const { logout } = useStore();
  const router = useRouter();
  const toast = useToast();
  return async () => {
    await logout();
    toast("You've been signed out.", "info");
    router.replace("/");
  };
}

function NavList({ collapsed, onNavigate, id }: { collapsed?: boolean; onNavigate?: () => void; id: string }) {
  const path = usePathname();
  const { db, me } = useStore();
  const pending = me ? db.sessions.filter((s) => s.status === "Pending" && s.awaitingId === me.id).length : 0;
  const unreadMsgs = me ? db.messages.filter((m) => m.toId === me.id && !m.read).length : 0;
  const unreadN = me ? db.notifications.filter((x) => x.userId === me.id && !x.read).length : 0;
  const groups = me?.role === "admin" ? ADMIN_GROUPS : NAV_GROUPS;
  const doLogout = useLogout();
  const item = (n: Item, badge?: number) => {
    const active = isActive(path, n.href);
    return (
      <li key={n.href}>
        <Link
          href={n.href}
          onClick={onNavigate}
          title={collapsed ? n.label : undefined}
          aria-current={active ? "page" : undefined}
          className={cn("relative flex h-10 items-center gap-3 rounded-xl px-3 text-[0.88rem] font-semibold transition-colors", active ? "text-navy" : "text-subtle hover:text-navy", collapsed && "justify-center px-0")}
        >
          {active && <motion.span layoutId={`nav-active-${id}`} className="absolute inset-0 rounded-xl neu-inset" transition={{ type: "spring", damping: 30, stiffness: 360 }} />}
          {active && <motion.span layoutId={`nav-bar-${id}`} className="absolute top-2.5 bottom-2.5 left-0 w-[3px] rounded-full bg-blush shadow-[0_0_10px_3px_rgb(246_201_204/.9)]" />}
          <n.icon className={cn("relative h-[18px] w-[18px] shrink-0", active && "text-teal-strong")} />
          {!collapsed && <span className="relative truncate">{n.label}</span>}
          {!!badge && <span className={cn("relative ml-auto rounded-full bg-teal-strong px-1.5 text-[0.68rem] font-bold text-white", collapsed && "absolute top-0.5 right-0.5 ml-0")}>{badge}</span>}
        </Link>
      </li>
    );
  };
  return (
    <div className="flex h-full flex-col">
      <div className="no-scrollbar -mx-1 min-h-0 flex-1 space-y-4 overflow-y-auto px-1">
        {groups.map((g) => (
          <div key={g.title}>
            {!collapsed && <p className="mb-1 px-3 text-[0.65rem] font-bold tracking-[0.12em] text-muted uppercase">{g.title}</p>}
            <ul className="space-y-0.5">{g.items.map((n) => item(n, n.href === "/sessions" ? pending : n.href === "/messages" ? unreadMsgs : undefined))}</ul>
          </div>
        ))}
      </div>
      <ul className="mt-3 space-y-0.5 border-t border-line pt-3">
        {BOTTOM.map((n) => item(n, n.href === "/notifications" ? unreadN : undefined))}
        <li>
          <button onClick={doLogout} title={collapsed ? "Logout" : undefined} className={cn("flex h-11 w-full items-center gap-3 rounded-xl px-3 text-[0.92rem] font-semibold text-subtle hover:text-rose", collapsed && "justify-center px-0")}>
            <LogOut className="h-[19px] w-[19px]" /> {!collapsed && "Logout"}
          </button>
        </li>
      </ul>
    </div>
  );
}

function GlobalSearch() {
  const { db, me } = useStore();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const results = useMemo(() => {
    const k = q.trim().toLowerCase();
    if (!k) return { people: [], skills: [] as string[] };
    const people = db.students.filter((s) => s.id !== me?.id && s.role !== "admin" && !s.suspended && (s.name.toLowerCase().includes(k) || s.college.toLowerCase().includes(k) || s.department.toLowerCase().includes(k))).slice(0, 5);
    const skillSet = new Map<string, string>();
    db.students.forEach((s) => s.teach.forEach((t) => t.name.toLowerCase().includes(k) && skillSet.set(normSkill(t.name), t.name)));
    return { people, skills: [...skillSet.values()].slice(0, 5) };
  }, [q, db.students, me]);
  const go = (href: string) => {
    setOpen(false);
    setQ("");
    router.push(href);
  };
  return (
    <div ref={ref} className="relative w-full max-w-md">
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          if (q.trim()) go(`/explore?q=${encodeURIComponent(q.trim())}`);
        }}
      >
        <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-muted" />
        <input
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search skills, students, colleges…"
          aria-label="Search students or skills"
          className="field h-11 pl-10"
        />
      </form>
      <AnimatePresence>
        {open && q.trim() && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute top-13 right-0 left-0 z-50 overflow-hidden rounded-2xl bg-ivory p-2 shadow-[var(--shadow-raised-lg)]">
            {!results.people.length && !results.skills.length && <p className="px-3 py-4 text-sm text-subtle">No students or skills match “{q}”.</p>}
            {!!results.skills.length && <p className="px-3 pt-2 pb-1 text-xs font-bold tracking-wide text-muted uppercase">Skills</p>}
            {results.skills.map((s) => (
              <button key={s} onClick={() => go(`/explore?q=${encodeURIComponent(s)}`)} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm font-semibold text-ink hover:bg-[#e5e9f2]">
                <Compass className="h-4 w-4 text-teal-strong" /> {s} <span className="ml-auto text-xs text-subtle">Find teachers</span>
              </button>
            ))}
            {!!results.people.length && <p className="px-3 pt-2 pb-1 text-xs font-bold tracking-wide text-muted uppercase">Students</p>}
            {results.people.map((s) => (
              <button key={s.id} onClick={() => go(`/profile/${s.id}`)} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left hover:bg-[#e5e9f2]">
                <Avatar name={s.name} size={30} className="ring-2" />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold text-ink">{s.name}</span>
                  <span className="block text-xs text-subtle">{s.department} · {yearLabel(s.year)}</span>
                </span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Notifications() {
  const { db, me, markRead, respondConnection } = useStore();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const mine = db.notifications.filter((n) => n.userId === me?.id).slice(0, 12);
  const unread = mine.filter((n) => !n.read).length;
  const ago = (iso: string) => {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    if (m < 1440) return `${Math.round(m / 60)}h ago`;
    return `${Math.round(m / 1440)}d ago`;
  };
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((o) => !o)} className="neu-sm relative flex h-11 w-11 items-center justify-center rounded-xl text-subtle hover:text-navy" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} aria-expanded={open}>
        <Bell className="h-5 w-5" />
        <AnimatePresence>
          {unread > 0 && (
            <motion.span key={unread} initial={{ scale: 0 }} animate={{ scale: [0, 1.25, 1] }} exit={{ scale: 0 }} className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-blush-ink px-1 text-[0.68rem] font-bold text-white ring-2 ring-ivory shadow-[0_0_12px_rgb(240_170_170/.9)]">
              {unread}
            </motion.span>
          )}
        </AnimatePresence>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -6, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6 }} className="fixed inset-x-3 top-[4.5rem] z-50 rounded-2xl bg-ivory p-2 shadow-[var(--shadow-raised-lg)] sm:absolute sm:inset-x-auto sm:top-14 sm:right-0 sm:w-96">
            <div className="flex items-center justify-between px-3 py-2">
              <p className="font-bold text-navy">Notifications</p>
              {unread > 0 && <button onClick={() => markRead()} className="text-xs font-semibold text-teal-strong hover:underline">Mark all read</button>}
            </div>
            <ul className="max-h-[60vh] overflow-y-auto">
              {!mine.length && <li className="px-3 py-8 text-center text-sm text-subtle">You're all caught up.</li>}
              {mine.map((n) => (
                <li key={n.id} className={cn("rounded-xl px-3 py-2.5", !n.read && "bg-[#e5e9f2]")}>
                  <button className="flex w-full gap-3 text-left" onClick={() => { markRead(n.id); setOpen(false); router.push(n.href); }}>
                    <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", n.read ? "bg-transparent" : "bg-teal")} />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm text-ink">{n.text}</span>
                      <span className="text-xs text-subtle">{ago(n.createdAt)}</span>
                    </span>
                  </button>
                  {n.connectionId && db.connections.some((c) => c.id === n.connectionId && c.status === "Pending") && (
                    <div className="mt-2 ml-5 flex gap-2">
                      <Button size="sm" variant="accent" onClick={() => { const r = respondConnection(n.connectionId!, true); toast(r.ok ? "Connection accepted." : r.error, r.ok ? "success" : "error"); }}>Accept</Button>
                      <Button size="sm" variant="secondary" onClick={() => { const r = respondConnection(n.connectionId!, false); toast(r.ok ? "Request declined." : r.error, r.ok ? "info" : "error"); }}>Decline</Button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ProfileMenu() {
  const { me } = useStore();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const doLogout = useLogout();
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  if (!me) return null;
  const links = [
    { href: "/profile", label: "My profile", icon: User },
    { href: "/my-skills", label: "My Skills", icon: IdCard },
    { href: "/notifications", label: "Notifications", icon: Bell },
    { href: "/settings", label: "Settings", icon: Settings },
  ];
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-3 rounded-xl p-1 pr-2 hover:bg-[#e3e7f0]" aria-label="Open profile menu" aria-expanded={open}>
        <Avatar name={me.name} size={40} className="ring-2" />
        <span className="hidden text-left leading-tight xl:block">
          <span className="block text-sm font-bold text-ink">{me.name}</span>
          <span className="block text-xs text-subtle">{me.department} · {yearLabel(me.year)}</span>
        </span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute top-14 right-0 z-50 w-56 rounded-2xl bg-ivory p-2 shadow-[var(--shadow-raised-lg)]">
            {links.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-ink hover:bg-[#e5e9f2]">
                <l.icon className="h-4 w-4 text-muted" /> {l.label}
              </Link>
            ))}
            <button onClick={doLogout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-rose hover:bg-[#e5e9f2]">
              <LogOut className="h-4 w-4" /> Logout
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const path = usePathname();
  useEffect(() => setMoreOpen(false), [path]);

  return (
    <div className="min-h-dvh">
      {/* sidebar: full on lg, collapsible rail on md */}
      <aside className={cn("fixed inset-y-0 left-0 z-40 hidden flex-col bg-white/70 py-6 shadow-[1px_0_0_rgb(255_255_255/.7),6px_0_18px_#d3d8e4] transition-[width] duration-300 md:flex", collapsed ? "w-[84px] px-3" : "w-[84px] px-3 lg:w-[250px] lg:px-5")}>
        <div className={cn("mb-8 flex items-center", collapsed ? "justify-center" : "justify-center lg:justify-between")}>
          <span className={cn(collapsed ? "" : "lg:hidden")}><Logo compact /></span>
          {!collapsed && <span className="hidden lg:block"><Logo /></span>}
        </div>
        <nav className={cn("min-h-0 flex-1", collapsed ? "" : "lg:hidden")} aria-label="Main"><NavList collapsed id="rail" /></nav>
        {!collapsed && <nav className="hidden min-h-0 flex-1 lg:block" aria-label="Main"><NavList id="full" /></nav>}
        <button onClick={() => setCollapsed((c) => !c)} className="neu-sm mx-auto mt-4 hidden h-9 w-9 items-center justify-center rounded-xl text-subtle hover:text-navy lg:flex" aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
          {collapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
        </button>
      </aside>

      <div className={cn("transition-[padding] duration-300 md:pl-[84px]", !collapsed && "lg:pl-[250px]")}>
        <header className="sticky top-0 z-30 bg-white/75 shadow-[0_1px_0_#e4e6ef]">
          <div className="mx-auto flex h-[4.5rem] max-w-[1400px] items-center gap-3 px-4 sm:px-6 lg:px-8">
            <span className="md:hidden"><Logo compact /></span>
            <div className="hidden flex-1 sm:block"><GlobalSearch /></div>
            <div className="ml-auto flex items-center gap-2 sm:gap-3">
              <Link href="/explore" className="neu-sm flex h-11 w-11 items-center justify-center rounded-xl text-subtle sm:hidden" aria-label="Search">
                <Search className="h-5 w-5" />
              </Link>
              <Notifications />
              <ProfileMenu />
            </div>
          </div>
        </header>
        <main className="mx-auto max-w-[1400px] px-4 pt-4 pb-32 sm:px-6 md:pb-12 lg:px-8">{children}</main>
      </div>

      {/* mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/90 px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] md:hidden" aria-label="Mobile">
        <ul className="grid grid-cols-5">
          {MOBILE.map((n) => {
            const active = isActive(path, n.href);
            return (
              <li key={n.href}>
                <Link href={n.href} className={cn("flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[0.68rem] font-semibold", active ? "text-teal-strong" : "text-subtle")} aria-current={active ? "page" : undefined}>
                  <span className={cn("flex h-9 w-12 items-center justify-center rounded-xl", active && "neu-sm")}><n.icon className="h-5 w-5" /></span>
                  {n.label.split(" ").pop()}
                </Link>
              </li>
            );
          })}
          <li>
            <button onClick={() => setMoreOpen(true)} className="flex w-full flex-col items-center gap-0.5 py-1.5 text-[0.68rem] font-semibold text-subtle" aria-label="More navigation">
              <span className="flex h-9 w-12 items-center justify-center"><Menu className="h-5 w-5" /></span> More
            </button>
          </li>
        </ul>
      </nav>
      <AnimatePresence>
        {moreOpen && (
          <motion.div className="fixed inset-0 z-[60] md:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-[#1c2a3f]/35" onClick={() => setMoreOpen(false)} />
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="absolute inset-x-0 bottom-0 max-h-[85dvh] overflow-y-auto rounded-t-[24px] bg-ivory p-5 pb-8">
              <div className="mb-4 flex items-center justify-between">
                <Logo />
                <button onClick={() => setMoreOpen(false)} className="neu-sm rounded-xl p-2" aria-label="Close menu"><X className="h-5 w-5" /></button>
              </div>
              <NavList id="sheet" onNavigate={() => setMoreOpen(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
