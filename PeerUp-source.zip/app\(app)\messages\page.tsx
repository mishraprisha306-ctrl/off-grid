"use client";
import { ArrowLeft, Ban, Flag, MessageCircle, MoreVertical, Send } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { ReportModal, SampleTag } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Button, Card, EmptyState, Modal, PageHeader, cn } from "@/components/ui";
import { useStore } from "@/lib/store";

const linkify = (t: string) => t.split(/(https?:\/\/\S+)/g).map((p, i) => (/^https?:\/\//.test(p) ? <a key={i} href={p} target="_blank" rel="noreferrer noopener" className="underline">{p}</a> : p));

function Messages() {
  const { db, me, byId, sendMessage, canMessage, readConversation, block } = useStore();
  const toast = useToast();
  const params = useSearchParams();
  const router = useRouter();
  const withId = params.get("with");
  const [text, setText] = useState("");
  const [menu, setMenu] = useState(false);
  const [reportMsg, setReportMsg] = useState<string | null>(null);
  const [reportUser, setReportUser] = useState(false);
  const [confirmBlock, setConfirmBlock] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  const convos = useMemo(() => {
    if (!me) return [];
    const map = new Map<string, { last: (typeof db.messages)[number]; unread: number }>();
    for (const m of db.messages) {
      if (m.fromId !== me.id && m.toId !== me.id) continue;
      const other = m.fromId === me.id ? m.toId : m.fromId;
      const cur = map.get(other);
      const unread = (cur?.unread ?? 0) + (m.toId === me.id && !m.read ? 1 : 0);
      map.set(other, { last: !cur || m.createdAt > cur.last.createdAt ? m : cur.last, unread });
    }
    return [...map.entries()].sort((a, b) => b[1].last.createdAt.localeCompare(a[1].last.createdAt));
  }, [db.messages, me]);

  const thread = useMemo(() => (me && withId ? db.messages.filter((m) => (m.fromId === me.id && m.toId === withId) || (m.fromId === withId && m.toId === me.id)).sort((a, b) => a.createdAt.localeCompare(b.createdAt)) : []), [db.messages, me, withId]);
  useEffect(() => { if (withId) readConversation(withId); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [withId, thread.length]);
  useEffect(() => end.current?.scrollIntoView({ block: "end" }), [thread.length, withId]);
  if (!me) return null;
  const other = withId ? byId(withId) : undefined;
  const perm = withId ? canMessage(withId) : { ok: false };

  const list = (
    <Card className={cn("p-2", withId && "hidden lg:block")}>
      <ul className="max-h-[70vh] overflow-y-auto">
        {convos.map(([id, c]) => { const s = byId(id); return (
          <li key={id}>
            <Link href={`/messages?with=${id}`} className={cn("flex items-center gap-3 rounded-xl p-3", id === withId ? "neu-inset" : "hover:bg-[#e5e9f2]")}>
              <Avatar name={s?.name ?? "?"} src={s?.avatar} size={42} className="ring-2" />
              <span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2"><span className="truncate font-bold text-navy">{s?.name ?? "Deleted account"}</span>{c.unread > 0 && <span className="rounded-full bg-teal-strong px-1.5 text-[0.68rem] font-bold text-white">{c.unread}</span>}</span><span className="block truncate text-sm text-subtle">{c.last.fromId === me.id ? "You: " : ""}{c.last.text}</span></span>
            </Link>
          </li>
        ); })}
        {!convos.length && <li className="p-6 text-center text-sm text-subtle">No conversations yet. Message a connection from their profile.</li>}
      </ul>
    </Card>
  );

  return (
    <div>
      <PageHeader title="Messages" subtitle="Plan sessions and share learning links with your connections." />
      <div className="grid gap-6 lg:grid-cols-[340px_1fr]">
        {list}
        {withId && other ? (
          <Card className="flex h-[70vh] flex-col p-0">
            <div className="flex items-center gap-3 border-b border-line p-4">
              <button onClick={() => router.push("/messages")} className="rounded-lg p-1 lg:hidden" aria-label="Back to conversations"><ArrowLeft className="h-5 w-5" /></button>
              <Avatar name={other.name} src={other.avatar} size={40} className="ring-2" />
              <Link href={`/profile/${other.id}`} className="min-w-0 flex-1"><span className="flex items-center gap-2 font-bold text-navy">{other.name}{other.sample && <SampleTag />}</span><span className="text-xs text-subtle">{other.department}</span></Link>
              <div className="relative">
                <button onClick={() => setMenu(!menu)} className="rounded-lg p-2 text-subtle hover:text-navy" aria-label="Conversation options" aria-expanded={menu}><MoreVertical className="h-5 w-5" /></button>
                {menu && (
                  <div className="absolute right-0 z-10 mt-1 w-44 rounded-xl bg-ivory p-1 shadow-[var(--shadow-raised-lg)]">
                    <button onClick={() => { setMenu(false); setReportUser(true); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-[#e5e9f2]"><Flag className="h-4 w-4" /> Report user</button>
                    <button onClick={() => { setMenu(false); setConfirmBlock(true); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose hover:bg-[#e5e9f2]"><Ban className="h-4 w-4" /> Block user</button>
                  </div>
                )}
              </div>
            </div>
            <div className="flex-1 space-y-2 overflow-y-auto p-4">
              {thread.map((m) => (
                <div key={m.id} className={cn("group flex", m.fromId === me.id ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[78%] rounded-2xl px-4 py-2.5 text-sm", m.fromId === me.id ? "rounded-br-md bg-navy text-white" : "rounded-bl-md neu-inset text-ink")}>
                    <p className="break-words whitespace-pre-wrap">{linkify(m.text)}</p>
                    <p className={cn("mt-1 text-[0.65rem]", m.fromId === me.id ? "text-white/60" : "text-subtle")}>{new Date(m.createdAt).toLocaleString(undefined, { hour: "numeric", minute: "2-digit", day: "numeric", month: "short" })}{m.fromId === me.id && (m.read ? " · Seen" : " · Sent")}</p>
                  </div>
                  {m.fromId !== me.id && <button onClick={() => setReportMsg(m.id)} className="ml-1 self-center rounded p-1 text-muted opacity-0 group-hover:opacity-100 focus:opacity-100" aria-label="Report message"><Flag className="h-3.5 w-3.5" /></button>}
                </div>
              ))}
              {!thread.length && <p className="pt-10 text-center text-sm text-subtle">Say hi and suggest a time to meet.</p>}
              <div ref={end} />
            </div>
            {perm.ok ? (
              <form className="flex gap-2 border-t border-line p-3" onSubmit={(e) => { e.preventDefault(); const r = sendMessage(other.id, text); if (!r.ok) return toast(r.error, "error"); setText(""); }}>
                <textarea value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); (e.currentTarget.form as HTMLFormElement).requestSubmit(); } }} rows={1} maxLength={1000} placeholder="Write a message… (Enter to send)" className="field max-h-32 min-h-11 resize-none" aria-label="Message" />
                <Button type="submit" disabled={!text.trim()} aria-label="Send"><Send className="h-4 w-4" /></Button>
              </form>
            ) : <p className="border-t border-line p-4 text-center text-sm text-subtle">{perm.reason}</p>}
          </Card>
        ) : (
          <Card className="hidden lg:block"><EmptyState icon={MessageCircle} title="Select a conversation" text="Messages are private between the two of you. Report anything that breaks the guidelines." /></Card>
        )}
      </div>
      {other && <ReportModal open={reportUser} onClose={() => setReportUser(false)} targetType="user" targetId={other.id} label={other.name} />}
      <ReportModal open={!!reportMsg} onClose={() => setReportMsg(null)} targetType="message" targetId={reportMsg ?? ""} label="this message" />
      <Modal open={confirmBlock} onClose={() => setConfirmBlock(false)} title={`Block ${other?.name ?? ""}?`}>
        <p className="text-sm text-ink">They won't be able to message, connect with or book you, and your connection will be removed. You can unblock them later in Connections.</p>
        <div className="mt-6 flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setConfirmBlock(false)}>Cancel</Button><Button variant="danger" className="flex-1" onClick={() => { const r = block(other!.id); toast(r.ok ? "User blocked." : r.error!, r.ok ? "info" : "error"); setConfirmBlock(false); router.push("/messages"); }}>Block</Button></div>
      </Modal>
    </div>
  );
}

export default function Page() {
  return <Suspense><Messages /></Suspense>;
}
