"use client";
import { Info, Users } from "lucide-react";
import { useState } from "react";
import { MatchCard, ProfileModal, RequestSessionModal } from "@/components/domain";
import { Button, Card, EmptyState, PageHeader, Tabs } from "@/components/ui";
import { type Match, allMatches } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { Student } from "@/lib/types";

export default function Matches() {
  const { db, me } = useStore();
  const [tab, setTab] = useState<"mutual" | "learn" | "teach">("mutual");
  const [view, setView] = useState<Student | null>(null);
  const [req, setReq] = useState<Match | null>(null);
  if (!me) return null;
  const m = allMatches(me, db.students);
  const list = m[tab];
  const copy = {
    mutual: "They teach something you want, and want something you teach.",
    learn: "They can teach you. You don't teach anything they want yet.",
    teach: "They want something you teach. A good way to earn your first ratings.",
  };
  return (
    <div>
      <PageHeader title="Mutual Matches" subtitle="Find students who can teach what you want to learn and want to learn what you can teach." />
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <Tabs value={tab} onChange={setTab} tabs={[{ value: "mutual", label: "Mutual matches", count: m.mutual.length }, { value: "learn", label: "Learn from", count: m.learn.length }, { value: "teach", label: "Teach to", count: m.teach.length }]} />
        <p className="text-sm text-subtle">{copy[tab]}</p>
      </div>
      {!me.teach.length || !me.learn.length ? (
        <Card><EmptyState icon={Users} title="Add your skills first" text="Matches need both skills you teach and skills you want to learn." action={<Button href="/my-skills">Edit My Skills</Button>} /></Card>
      ) : list.length ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {list.map((x) => <MatchCard key={x.student.id} match={x} onView={() => setView(x.student)} onRequest={() => setReq(x)} />)}
        </div>
      ) : (
        <Card><EmptyState icon={Users} title="No matches in this group yet" text="Add more learning interests or teaching skills to widen your matches." action={<Button href="/my-skills" variant="secondary">Edit My Skills</Button>} /></Card>
      )}
      <Card className="mt-10 flex gap-3 text-sm">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-teal-strong" />
        <p className="text-subtle"><b className="text-ink">How match % works:</b> for mutual matches it's the average of how much of <i>your</i> wish list they cover and how much of <i>theirs</i> you cover. 100% means every skill on both lists is covered (a Perfect Mutual Match). One-way matches score only the covered side. Skill names are matched case-insensitively with common aliases (e.g. “UI/UX” = “UI/UX Design”).</p>
      </Card>
      <ProfileModal student={view} onClose={() => setView(null)} />
      <RequestSessionModal open={!!req} other={req?.student ?? null} onClose={() => setReq(null)} role={req?.theyTeach.length ? "learn" : "teach"} skill={req?.theyTeach[0] ?? req?.iTeach[0]} title={req?.kind === "mutual" ? `Start an exchange with ${req.student.name.split(" ")[0]}` : undefined} />
    </div>
  );
}
