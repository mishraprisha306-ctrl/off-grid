"use client";
import { motion } from "framer-motion";
import { Flag, MessageSquareText, Pencil, Star, ThumbsUp } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { ReportModal, ReviewModal, useStats } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Badge, Button, Card, EmptyState, Field, Modal, PageHeader, StarInput, Stars, Tabs, Textarea, cn } from "@/components/ui";
import { MIN_SKILL_REVIEWS, RATING_LABELS, sessionStart } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { RatingSet, Review, Session } from "@/lib/types";

function ReviewItem({ r, mode }: { r: Review; mode: "received" | "given" }) {
  const { byId, me, toggleHelpful, editReview } = useStore();
  const toast = useToast();
  const [report, setReport] = useState(false);
  const [edit, setEdit] = useState(false);
  const [stars, setStars] = useState(r.stars);
  const [comment, setComment] = useState(r.comment);
  const [err, setErr] = useState("");
  const who = byId(mode === "given" ? r.revieweeId : r.reviewerId);
  const editable = mode === "given" && Date.now() - new Date(r.createdAt).getTime() < 7 * 864e5;
  return (
    <li className="neu-sm p-5">
      <div className="flex items-start gap-3">
        <Avatar name={who?.name ?? "?"} src={who?.avatar} size={40} className="ring-2" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-bold text-navy">{mode === "given" ? "For " : ""}{who ? <Link href={`/profile/${who.id}`} className="hover:underline">{who.name}</Link> : "Former member"}</p>
            <span className="text-xs text-subtle">{new Date(r.createdAt).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}{r.editedAt && " · edited"}</span>
          </div>
          <div className="mt-0.5 flex flex-wrap items-center gap-2"><Stars value={r.stars} size={14} /><span className="text-xs font-semibold text-teal-strong">{r.skill}</span>{r.mentorship && <Badge tone="teal">Mentorship</Badge>}</div>
          <p className="mt-2 text-sm text-ink">“{r.comment}”</p>
          {r.qualities.length > 0 && <div className="mt-2 flex flex-wrap gap-1.5">{r.qualities.map((q) => <Badge key={q}>{q}</Badge>)}</div>}
          <div className="mt-3 flex flex-wrap items-center gap-3 text-xs">
            {me && r.reviewerId !== me.id && <button onClick={() => { const x = toggleHelpful(r.id); if (!x.ok) toast(x.error, "error"); }} className={cn("inline-flex items-center gap-1 font-semibold", r.helpful.includes(me.id) ? "text-teal-strong" : "text-subtle hover:text-navy")} aria-pressed={r.helpful.includes(me.id)}><ThumbsUp className="h-3.5 w-3.5" /> Helpful ({r.helpful.length})</button>}
            {mode === "given" && <span className="text-subtle">{r.helpful.length} found this helpful</span>}
            {editable && <button onClick={() => setEdit(true)} className="inline-flex items-center gap-1 font-semibold text-teal-strong"><Pencil className="h-3.5 w-3.5" /> Edit</button>}
            {mode === "received" && <button onClick={() => setReport(true)} className="inline-flex items-center gap-1 font-semibold text-subtle hover:text-rose"><Flag className="h-3.5 w-3.5" /> Report</button>}
          </div>
        </div>
      </div>
      <ReportModal open={report} onClose={() => setReport(false)} targetType="review" targetId={r.id} label="review" />
      <Modal open={edit} onClose={() => setEdit(false)} title="Edit your review">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); const x = editReview(r.id, stars, comment); if (!x.ok) return setErr(x.error); toast("Review updated."); setEdit(false); }}>
          <StarInput label="Overall rating" value={stars} onChange={setStars} />
          <Field label="Feedback" htmlFor={`e-${r.id}`}><Textarea id={`e-${r.id}`} rows={3} value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
          {err && <p className="text-sm font-semibold text-rose">{err}</p>}
          <p className="text-xs text-subtle">Editable for 7 days after submitting.</p>
          <Button type="submit" className="w-full">Save</Button>
        </form>
      </Modal>
    </li>
  );
}

function Reviews() {
  const { db, me, byId } = useStore();
  const params = useSearchParams();
  const router = useRouter();
  const stats = useStats(me!.id);
  const [tab, setTab] = useState<"received" | "given" | "feedback">((params.get("tab") as "feedback") ?? "received");
  const [rating, setRating] = useState<Session | null>(null);
  const rateId = params.get("rate");
  useEffect(() => { if (rateId) setRating(db.sessions.find((s) => s.id === rateId && s.status === "Completed") ?? null); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [rateId]);
  if (!me) return null;
  const awaiting = db.sessions
    .filter((s) => s.status === "Completed" && (s.learnerId === me.id || s.groupIds.includes(me.id)) && s.teacherId !== me.id && !db.reviews.some((r) => r.sessionId === s.id && r.reviewerId === me.id))
    .sort((a, b) => +sessionStart(b) - +sessionStart(a));
  const received = db.reviews.filter((r) => r.revieweeId === me.id);
  const given = db.reviews.filter((r) => r.reviewerId === me.id);
  const feedback = db.feedback.filter((f) => f.learnerId === me.id);
  const rs = stats.rating;
  const maxDist = Math.max(1, ...rs.distribution.map((d) => d.count));

  return (
    <div>
      <PageHeader title="Ratings & Reviews" subtitle="Built only from completed sessions. No self-ratings, no duplicates." />
      {awaiting.length > 0 && (
        <Card className="mb-8 border-blush bg-blush-soft/40">
          <h2 className="font-bold text-navy">Rate your teachers</h2>
          <p className="text-sm text-subtle">One rating per completed session.</p>
          <ul className="mt-4 grid gap-3 md:grid-cols-2">
            {awaiting.map((s) => { const t = byId(s.teacherId); return (
              <li key={s.id} className="neu-sm flex items-center gap-3 p-4">
                <Avatar name={t?.name ?? "?"} src={t?.avatar} size={40} className="ring-2" />
                <div className="min-w-0 flex-1"><p className="truncate font-bold text-navy">{s.skill} with {t?.name}</p><p className="text-xs text-subtle">{sessionStart(s).toLocaleDateString(undefined, { day: "numeric", month: "short" })} · {s.mode} {s.format}</p></div>
                <Button size="sm" onClick={() => setRating(s)}><Star className="h-4 w-4" /> Rate</Button>
              </li>
            ); })}
          </ul>
        </Card>
      )}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="text-center">
          <p className="text-sm font-semibold text-subtle">Your overall teaching rating</p>
          <p className="mt-2 text-5xl font-extrabold text-navy">{rs.average?.toFixed(2) ?? "-"}</p>
          <div className="mt-2 flex justify-center"><Stars value={rs.average} size={22} /></div>
          <p className="mt-2 text-sm text-subtle">{rs.count ? `${rs.count} eligible rating${rs.count > 1 ? "s" : ""}` : "No ratings yet. They appear after you teach a completed session."}</p>
          <div className="mt-6 space-y-2 text-left">
            {rs.distribution.map((d) => (
              <div key={d.stars} className="flex items-center gap-3 text-sm">
                <span className="w-8 font-semibold text-ink">{d.stars}★</span>
                <div className="neu-inset h-2.5 flex-1 overflow-hidden rounded-full"><motion.div className="h-full rounded-full bg-amber" initial={{ width: 0 }} animate={{ width: `${(d.count / maxDist) * 100}%` }} transition={{ duration: 0.8 }} /></div>
                <span className="w-6 text-right text-subtle">{d.count}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <h2 className="font-bold text-navy">By skill</h2>
          {rs.bySkill.length ? (
            <ul className="mt-4 divide-y divide-line">{rs.bySkill.map((b) => <li key={b.skill} className="flex items-center justify-between py-3"><span className="font-semibold text-ink">{b.skill}</span>{b.enough ? <span className="flex items-center gap-2"><Stars value={b.average} size={13} showValue /><span className="text-xs text-subtle">({b.count})</span></span> : <span className="text-xs text-subtle">{b.count} review · needs {MIN_SKILL_REVIEWS}</span>}</li>)}</ul>
          ) : <p className="mt-4 text-sm text-subtle">Skill-wise averages appear once you've been rated.</p>}
          <h2 className="mt-6 font-bold text-navy">By category</h2>
          <ul className="mt-3 space-y-2">{(Object.keys(RATING_LABELS) as (keyof RatingSet)[]).map((k) => <li key={k} className="flex justify-between text-sm"><span>{RATING_LABELS[k]}</span><span className="font-bold text-navy">{rs.categories[k]?.toFixed(1) ?? "-"}</span></li>)}</ul>
        </Card>
        <Card>
          <h2 className="font-bold text-navy">Most appreciated qualities</h2>
          {rs.qualities.length ? <ul className="mt-4 space-y-2.5">{rs.qualities.slice(0, 6).map((q) => <li key={q.quality} className="flex items-center justify-between text-sm"><span className="font-semibold text-ink">{q.quality}</span><Badge tone="teal">{q.count}×</Badge></li>)}</ul> : <p className="mt-4 text-sm text-subtle">Learners can tag what stood out when they rate you.</p>}
          <p className="mt-6 text-xs text-subtle">Average = sum of eligible star ratings ÷ number of eligible ratings. <Link href="/trust" className="font-semibold text-teal-strong">See how trust is calculated →</Link></p>
        </Card>
      </div>
      <div className="mt-10 mb-5"><Tabs value={tab} onChange={setTab} tabs={[{ value: "received", label: "Received", count: received.length }, { value: "given", label: "Given", count: given.length }, { value: "feedback", label: "Learner feedback for you", count: feedback.length }]} /></div>
      {tab === "feedback" ? (
        feedback.length ? (
          <ul className="grid gap-4 md:grid-cols-2">{feedback.map((f) => { const t = byId(f.teacherId); const s = db.sessions.find((x) => x.id === f.sessionId); return (
            <li key={f.id} className="neu-sm p-5">
              <p className="font-bold text-navy">{t?.name} · <span className="text-teal-strong">{s?.skill}</span></p>
              {f.progress ? <p className="mt-1 text-sm">Progress: <Stars value={f.progress} size={12} /></p> : null}
              <p className="mt-2 text-sm text-ink">{f.comment}</p>
              {f.suggestions && <p className="mt-2 text-sm text-subtle"><b>Suggestions:</b> {f.suggestions}</p>}
              <p className="mt-2 text-xs text-subtle">{f.private ? "Private to you and your teacher" : "Shared"} · never affects your public reputation</p>
            </li>
          ); })}</ul>
        ) : <Card><EmptyState icon={MessageSquareText} title="No learner feedback yet" text="Teachers can leave private feedback on your progress after a completed session." /></Card>
      ) : (tab === "received" ? received : given).length ? (
        <ul className="grid gap-4 md:grid-cols-2">{(tab === "received" ? received : given).map((r) => <ReviewItem key={r.id} r={r} mode={tab} />)}</ul>
      ) : <Card><EmptyState icon={MessageSquareText} title={tab === "received" ? "No reviews yet" : "You haven't rated anyone yet"} text={tab === "received" ? "Teach a session and your learners can rate you." : "Rate completed sessions to help others choose."} action={<Button href="/sessions" variant="secondary">Go to sessions</Button>} /></Card>}
      <ReviewModal session={rating} onClose={() => { setRating(null); if (rateId) router.replace("/reviews"); }} />
    </div>
  );
}

export default function Page() {
  return <Suspense><Reviews /></Suspense>;
}
