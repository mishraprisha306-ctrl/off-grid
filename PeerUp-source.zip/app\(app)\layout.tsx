"use client";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { AppShell } from "@/components/shell";
import { Skeleton } from "@/components/ui";
import { useStore } from "@/lib/store";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { ready, me } = useStore();
  const router = useRouter();
  const path = usePathname();
  const needsOnboarding = !!me && me.role !== "admin" && !me.onboarded && path !== "/onboarding";
  const forbiddenAdmin = !!me && me.role !== "admin" && path.startsWith("/admin");
  useEffect(() => {
    if (!ready) return;
    if (!me) router.replace(`/login?next=${encodeURIComponent(path)}`);
    else if (needsOnboarding) router.replace("/onboarding");
    else if (forbiddenAdmin) router.replace("/dashboard");
  }, [ready, me, router, path, needsOnboarding, forbiddenAdmin]);

  if (!ready || !me || needsOnboarding || forbiddenAdmin)
    return (
      <div className="min-h-dvh md:pl-[84px] lg:pl-[250px]" aria-busy="true">
        <div className="mx-auto max-w-[1400px] space-y-6 px-4 pt-24 sm:px-6 lg:px-8">
          <Skeleton className="h-10 w-72" />
          <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-32" />)}</div>
          <div className="grid gap-6 lg:grid-cols-3"><Skeleton className="h-72 lg:col-span-2" /><Skeleton className="h-72" /></div>
        </div>
      </div>
    );
  if (path === "/onboarding") return <div className="min-h-dvh px-4 py-10 sm:px-6">{children}</div>;
  return <AppShell>{children}</AppShell>;
}
