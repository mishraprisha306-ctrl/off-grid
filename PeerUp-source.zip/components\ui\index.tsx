"use client";
import { AnimatePresence, animate, motion, useInView, useReducedMotion } from "framer-motion";
import { GraduationCap, Star, X } from "lucide-react";
import Link from "next/link";
import { forwardRef, useEffect, useId, useRef, useState } from "react";
import { clsx } from "clsx";
import { initials } from "@/lib/engines";

export const cn = clsx;

/* ---------- Card ---------- */
export function Card({ className, hover, children, ...rest }: React.HTMLAttributes<HTMLDivElement> & { hover?: boolean }) {
  return (
    <div
      className={cn("neu p-6", hover && "glow-hover hover:-translate-y-0.5", className)}
      {...rest}
    >
      {children}
    </div>
  );
}

/* ---------- Button ---------- */
type Variant = "primary" | "secondary" | "accent" | "ghost" | "danger";
const variants: Record<Variant, string> = {
  primary: "bg-navy text-white shadow-[var(--shadow-raised-sm)] hover:bg-navy-600 hover:shadow-[var(--shadow-glow)]",
  secondary: "neu-sm text-ink hover:text-navy",
  accent: "bg-teal-strong text-white shadow-[var(--shadow-raised-sm)] hover:bg-[#1a6c60] hover:shadow-[var(--shadow-glow)]",
  ghost: "text-subtle hover:text-navy hover:bg-white/60",
  danger: "neu-sm text-rose hover:bg-[#fbeeed]",
};
export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg"; href?: string };
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ variant = "primary", size = "md", className, href, children, ...rest }, ref) {
  const cls = cn(
    "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-[background-color,box-shadow,transform,color] duration-200 active:scale-[0.97] active:shadow-[var(--shadow-pressed)] disabled:pointer-events-none disabled:opacity-50 select-none whitespace-nowrap",
    size === "sm" && "h-9 px-3.5 text-sm",
    size === "md" && "h-11 px-5 text-[0.95rem]",
    size === "lg" && "h-12 px-6 text-base",
    variants[variant],
    className,
  );
  if (href) return <Link href={href} className={cls}>{children}</Link>;
  return (
    <button ref={ref} className={cls} {...rest}>
      {children}
    </button>
  );
});

/* ---------- Fields ---------- */
export function Field({ label, error, hint, children, htmlFor }: { label: string; error?: string; hint?: string; children: React.ReactNode; htmlFor?: string }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={htmlFor} className="block text-sm font-semibold text-ink">{label}</label>
      {children}
      {error ? <p className="text-xs font-medium text-rose" role="alert">{error}</p> : hint ? <p className="text-xs text-subtle">{hint}</p> : null}
    </div>
  );
}
export const Input = forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...p }, ref) {
  return <input ref={ref} className={cn("field", className)} {...p} />;
});
export function Select({ className, children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={cn("field appearance-none bg-[length:16px] bg-[right_0.9rem_center] bg-no-repeat pr-9", className)} style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2384909A' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")" }} {...p}>{children}</select>;
}
export function Textarea({ className, ...p }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn("field min-h-24 resize-y", className)} {...p} />;
}

/* ---------- Badge / chips ---------- */
export function Badge({ tone = "neutral", className, children }: { tone?: "neutral" | "teal" | "navy" | "amber" | "rose" | "green"; className?: string; children: React.ReactNode }) {
  const tones = {
    neutral: "bg-[#eceef5] text-subtle",
    teal: "bg-teal-soft text-teal-strong",
    navy: "bg-[#e1e6ef] text-navy",
    amber: "bg-[#f7ecd6] text-[#8a5b0c]",
    rose: "bg-[#f8e3e1] text-[#a33f37]",
    green: "bg-[#dff0e2] text-[#2c6e3a]",
  };
  return <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold", tones[tone], className)}>{children}</span>;
}
export function MentorBadge({ small }: { small?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full bg-teal-strong font-semibold text-white", small ? "px-2 py-0.5 text-[0.7rem]" : "px-2.5 py-1 text-xs")}>
      <GraduationCap className={small ? "h-3 w-3" : "h-3.5 w-3.5"} aria-hidden /> Senior Mentor
    </span>
  );
}
export function SkillChip({ children, tone = "navy", onRemove }: { children: React.ReactNode; tone?: "navy" | "teal" | "match"; onRemove?: () => void }) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[0.8rem] font-semibold",
      tone === "navy" && "bg-[#e8eaf6] text-navy",
      tone === "teal" && "bg-teal-soft text-teal-strong",
      tone === "match" && "bg-teal-strong text-white",
    )}>
      {children}
      {onRemove && (
        <button type="button" onClick={onRemove} className="-mr-1 rounded p-0.5 hover:bg-black/10" aria-label={`Remove ${children}`}>
          <X className="h-3 w-3" />
        </button>
      )}
    </span>
  );
}

/* ---------- Avatar ---------- */
const AV = ["#1f2547", "#4c3fc8", "#6b4aa3", "#8a5b2c", "#2f5d8a", "#7a3e55", "#3f6b5a"];
export function Avatar({ name, src, size = 44, className }: { name: string; src?: string; size?: number; className?: string }) {
  const c = AV[[...name].reduce((a, ch) => a + ch.charCodeAt(0), 0) % AV.length];
  return (
    <span
      className={cn("inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full font-bold text-white ring-4 ring-white shadow-[var(--shadow-raised-sm)]", className)}
      style={{ width: size, height: size, background: c, fontSize: size * 0.36 }}
      aria-hidden
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {src ? <img src={src} alt="" className="h-full w-full object-cover" loading="lazy" /> : initials(name)}
    </span>
  );
}

/* ---------- Stars ---------- */
export function Stars({ value, size = 16, showValue, count }: { value: number | null; size?: number; showValue?: boolean; count?: number }) {
  const v = value ?? 0;
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="relative inline-flex" aria-label={value === null ? "No ratings yet" : `${v.toFixed(1)} out of 5 stars`} role="img">
        {[0, 1, 2, 3, 4].map((i) => (
          <Star key={i} style={{ width: size, height: size }} className="text-[#dcdfea]" fill="currentColor" strokeWidth={0} />
        ))}
        <span className="absolute inset-0 flex overflow-hidden" style={{ width: `${(v / 5) * 100}%` }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <Star key={i} style={{ width: size, height: size }} className="shrink-0 text-amber" fill="currentColor" strokeWidth={0} />
          ))}
        </span>
      </span>
      {showValue && (
        <span className="text-sm font-bold text-ink">
          {value === null ? <span className="font-medium text-subtle">New</span> : v.toFixed(1)}
          {count !== undefined && value !== null && <span className="ml-1 font-medium text-subtle">({count})</span>}
        </span>
      )}
    </span>
  );
}

export function StarInput({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  const [hover, setHover] = useState(0);
  const reduce = useReducedMotion();
  const shown = hover || value;
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm font-semibold text-ink">{label}</span>
      <div className="flex" role="radiogroup" aria-label={label} onMouseLeave={() => setHover(0)}>
        {[1, 2, 3, 4, 5].map((n) => (
          <motion.button
            key={n}
            type="button"
            role="radio"
            aria-checked={value === n}
            aria-label={`${n} star${n > 1 ? "s" : ""}`}
            onMouseEnter={() => setHover(n)}
            onClick={() => onChange(n)}
            whileTap={reduce ? undefined : { scale: 0.8 }}
            animate={reduce ? undefined : { scale: value === n ? [1, 1.3, 1] : 1 }}
            transition={{ duration: 0.3 }}
            className="p-0.5"
          >
            <Star className={cn("h-7 w-7 transition-colors", n <= shown ? "text-amber" : "text-[#d6d9e6]")} fill="currentColor" strokeWidth={0} />
          </motion.button>
        ))}
      </div>
    </div>
  );
}

/* ---------- Modal ---------- */
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  const id = useId();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-[#1c2a3f]/40" onClick={onClose} />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby={id}
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: "spring", damping: 28, stiffness: 320 }}
            className={cn("relative max-h-[92dvh] w-full overflow-y-auto rounded-t-[22px] bg-ivory p-6 shadow-[0_24px_60px_rgba(35,53,84,0.25)] sm:rounded-[22px]", wide ? "sm:max-w-2xl" : "sm:max-w-lg")}
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <h2 id={id} className="text-lg font-bold text-navy">{title}</h2>
              <button onClick={onClose} className="neu-sm -m-1 rounded-xl p-2 text-subtle hover:text-navy" aria-label="Close dialog">
                <X className="h-4 w-4" />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------- misc ---------- */
export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="relative inline-block text-2xl font-extrabold tracking-tight text-navy sm:text-[1.9rem]">{title}<span aria-hidden className="absolute -top-1 -right-4 h-2.5 w-2.5 rounded-full bg-blush shadow-[0_0_12px_4px_rgb(246_201_204/.9)]" /></h1>
        {subtitle && <p className="mt-1 text-[0.95rem] text-subtle">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, text, action }: { icon: React.ElementType; title: string; text: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <span className="neu-inset mb-4 flex h-16 w-16 items-center justify-center rounded-2xl text-teal-strong">
        <Icon className="h-7 w-7" />
      </span>
      <h3 className="font-bold text-navy">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-subtle">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

export function Counter({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const reduce = useReducedMotion();
  useEffect(() => {
    if (!ref.current) return;
    if (reduce || !inView) {
      ref.current.textContent = value.toFixed(decimals);
      return;
    }
    const c = animate(0, value, { duration: 1.1, ease: "easeOut", onUpdate: (v) => ref.current && (ref.current.textContent = v.toFixed(decimals)) });
    return () => c.stop();
  }, [value, decimals, inView, reduce]);
  return <span ref={ref}>{value.toFixed(decimals)}</span>;
}

export function Ring({ value, size = 64, stroke = 7, label }: { value: number; size?: number; stroke?: number; label?: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const reduce = useReducedMotion();
  return (
    <span className="relative inline-flex items-center justify-center" style={{ width: size, height: size }} role="img" aria-label={label ?? `${value}%`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#e4e6f0" strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} stroke="#7b68f0" style={{ filter: "drop-shadow(0 0 4px rgb(246 201 204 / .9))" }} strokeWidth={stroke} fill="none" strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: reduce ? c * (1 - value / 100) : c }}
          animate={{ strokeDashoffset: c * (1 - value / 100) }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </svg>
      <span className="absolute text-[0.8rem] font-extrabold text-navy" style={{ fontSize: size * 0.22 }}>{value}%</span>
    </span>
  );
}

export function Tabs<T extends string>({ value, onChange, tabs }: { value: T; onChange: (v: T) => void; tabs: { value: T; label: string; count?: number }[] }) {
  const id = useId();
  return (
    <div className="neu-inset no-scrollbar inline-flex max-w-full gap-1 overflow-x-auto rounded-2xl p-1.5" role="tablist">
      {tabs.map((t) => (
        <button key={t.value} role="tab" aria-selected={value === t.value} onClick={() => onChange(t.value)} className={cn("relative rounded-xl px-4 py-2 text-sm font-semibold whitespace-nowrap transition-colors", value === t.value ? "text-navy" : "text-subtle hover:text-navy")}>
          {value === t.value && <motion.span layoutId={`tab-${id}`} className="absolute inset-0 rounded-xl bg-ivory shadow-[var(--shadow-raised-sm)]" transition={{ type: "spring", damping: 30, stiffness: 380 }} />}
          <span className="relative">
            {t.label}
            {t.count !== undefined && <span className="ml-1.5 text-xs text-muted">{t.count}</span>}
          </span>
        </button>
      ))}
    </div>
  );
}

export const fadeUp = {
  hidden: { opacity: 0, y: 14 },
  show: (i: number = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.06, duration: 0.4, ease: [0.22, 1, 0.36, 1] as const } }),
};
