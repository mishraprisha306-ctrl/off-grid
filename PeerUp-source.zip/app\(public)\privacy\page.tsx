import { Legal } from "@/components/legal";
export const metadata = { title: "Privacy Policy" };
export default function Page() {
  return <Legal title="Privacy Policy" subtitle="What we collect, why, and the controls you have." sections={[
    ["What we collect", ["Account details: name, email, password (stored only as a secure hash by the auth provider).", "Academic details you enter: college, field, branch, year and optional student ID.", "Profile content: bio, interests, skills, availability, links, certificates and an optional photo.", "Activity: connections, session requests, messages, ratings, feedback and reports."]],
    ["How we use it", ["To match you with students whose skills complement yours.", "To run sessions, notifications and messaging between participants.", "To calculate ratings, trust scores and leaderboards from eligible activity.", "To keep the community safe through moderation of reports."]],
    ["Your controls", ["Choose whether your email, college, student ID and links are visible (Settings → Privacy).", "Choose who can message you: everyone or only connections.", "Block any user. Blocked users can't message, connect with or book you.", "Delete your account at any time from Settings. Shared session history stays anonymised for the other participant."]],
    ["Storage and security", ["In production, data lives in Supabase PostgreSQL with Row Level Security so students can only read and change what they're allowed to.", "Profile photos and certificates are stored in access-controlled storage buckets.", "The demo version stores data only in your own browser."]],
    ["Contact", ["Questions about your data? Use the Contact page."]],
  ]} />;
}
