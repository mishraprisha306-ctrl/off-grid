"use client";
import { Flame } from "lucide-react";
import { useToast } from "@/components/toast";
import { Badge, Button, Card, PageHeader, cn } from "@/components/ui";
import { CHALLENGES } from "@/lib/engines";
import { useStore } from "@/lib/store";

export default function Challenges() {
  const { db, me, now, joinChallenge, toggleChallengeDay, leaveChallenge } = useStore();
  const toast = useToast();
  if (!me) return null;
  const run = (r: { ok: boolean; error?: string }, m?: string) => (r.ok ? m && toast(m) : toast(r.error!, "error"));
  return (
    <div>
      <PageHeader title="Learning Challenges" subtitle="Optional streaks and mini projects to keep momentum." />
      <div className="grid gap-6 md:grid-cols-2">
        {CHALLENGES.map((c) => {
          const j = db.challenges.find((x) => x.userId === me.id && x.challengeId === c.id);
          const today = j ? Math.floor((now - new Date(j.startedAt).getTime()) / 864e5) + 1 : 0;
          const done = j?.daysDone.length ?? 0;
          return (
            <Card key={c.id} className={cn(j && done === c.days && "glow-live")}>
              <div className="flex items-start justify-between"><div><Badge tone="teal">{c.kind}</Badge><h2 className="mt-2 text-lg font-extrabold text-navy">{c.title}</h2><p className="text-sm text-subtle">{c.desc}</p></div><Flame className={cn("h-7 w-7", j ? "text-amber" : "text-muted")} /></div>
              {j ? (
                <>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {[...Array(c.days)].map((_, i) => {
                      const day = i + 1;
                      const on = j.daysDone.includes(day);
                      const locked = day > today;
                      return <button key={day} onClick={() => run(toggleChallengeDay(j.id, day))} disabled={locked} aria-pressed={on} aria-label={`Day ${day}${locked ? ", locked" : ""}`}
                        className={cn("flex h-11 w-11 items-center justify-center rounded-xl text-sm font-bold", on ? "bg-teal-strong text-white shadow-[0_0_12px_2px_rgb(246_201_204/.9)]" : locked ? "bg-[#f1f2f7] text-muted" : "neu-sm text-navy")}>{day}</button>;
                    })}
                  </div>
                  <p className="mt-3 text-sm text-subtle">{done === c.days ? "Challenge complete. Nice work." : `${done}/${c.days} days done · day ${Math.min(today, c.days)} today`}</p>
                  <Button size="sm" variant="ghost" className="mt-2" onClick={() => run(leaveChallenge(j.id), "Left challenge.")}>Leave challenge</Button>
                </>
              ) : <Button className="mt-5" onClick={() => run(joinChallenge(c.id), `Joined ${c.title}. Day 1 starts now!`)}>Join challenge</Button>}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
