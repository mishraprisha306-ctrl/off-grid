"use client";
import { BadgeCheck, Check, Flag, GraduationCap, LifeBuoy, Plus, ShieldOff, Trash2, X } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { SampleTag } from "@/components/domain";
import { useToast } from "@/components/toast";
import { Avatar, Badge, Button, Card, Field, Input, PageHeader, Select, Tabs } from "@/components/ui";
import { mentorCheck, participants, sessionStart, trustScore, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";

type Tab = "overview" | "users" | "reports" | "moderation" | "mentors" | "skills" | "sessions" | "analytics" | "support" | "settings";
const TABS: { value: Tab; label: string }[] = [
  { value: "overview", label: "Overview" }, { value: "users", label: "Users" }, { value: "reports", label: "Reports" }, { value: "moderation", label: "Moderation" },
  { value: "mentors", label: "Mentors & portfolios" }, { value: "skills", label: "Skills" }, { value: "sessions", label: "Sessions" }, { value: "analytics", label: "Analytics" },
  { value: "support", label: "Support" }, { value: "settings", label: "Settings & audit" },
];

function Admin() {
  const { db, me, byId, admin, updateSettings, now } = useStore();
  const toast = useToast();
  const params = useSearchParams();
  const router = useRouter();
  const tab = (params.get("tab") as Tab) ?? "overview";
  const setTab = (t: Tab) => router.replace(t === "overview" ? "/admin" : `/admin?tab=${t}`);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [sFilter, setSFilter] = useState("");
  const run = (r: { ok: boolean; error?: string }, m: string) => toast(r.ok ? m : r.error!, r.ok ? "success" : "error");
  const students = db.students.filter((s) => s.role !== "admin");
  const active = students.filter((s) => db.sessions.some((x) => participants(x).includes(s.id) && now - new Date(x.updatedAt).getTime() < 30 * 864e5) || db.messages.some((m) => m.fromId === s.id && now - new Date(m.createdAt).getTime() < 30 * 864e5));
  const openReports = db.reports.filter((r) => r.status === "open");
  const chart = useMemo(() => {
    const byField = new Map<string, number>();
    students.forEach((s) => byField.set(s.field, (byField.get(s.field) ?? 0) + 1));
    return [...byField.entries()].map(([field, count]) => ({ field, count }));
  }, [students]);
  const sessionsByStatus = ["Pending", "Accepted", "Completed", "Rejected", "Cancelled"].map((st) => ({ status: st, count: db.sessions.filter((s) => s.status === st).length }));
  const topSkills = useMemo(() => {
    const m = new Map<string, number>();
    db.sessions.filter((s) => s.status === "Completed").forEach((s) => m.set(s.skill, (m.get(s.skill) ?? 0) + 1));
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  }, [db.sessions]);
  if (!me || me.role !== "admin") return null;

  const targetLabel = (t: string, id: string) => t === "user" ? byId(id)?.name ?? "Deleted user" : t === "review" ? `Review: “${db.reviews.find((r) => r.id === id)?.comment.slice(0, 60) ?? "removed"}”` : `Message: “${db.messages.find((m) => m.id === id)?.text.slice(0, 60) ?? "removed"}”`;

  return (
    <div>
      <PageHeader title="Admin Dashboard" subtitle="Moderation, verification and platform health. Every action is recorded in the audit log." />
      <div className="mb-6"><Tabs value={tab} onChange={setTab} tabs={TABS.map((t) => ({ ...t, count: t.value === "reports" ? openReports.length : t.value === "support" ? db.support.filter((s) => s.status === "open").length : t.value === "mentors" ? students.filter((s) => s.mentorStatus === "pending").length : undefined }))} /></div>

      {tab === "overview" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[["Registered students", students.length], ["Active (30 days)", active.length], ["Open reports", openReports.length], ["Completed sessions", db.sessions.filter((s) => s.status === "Completed").length], ["Pending mentor reviews", students.filter((s) => s.mentorStatus === "pending").length], ["Unverified certificates", students.flatMap((s) => s.certificates).filter((c) => c.status === "evidence").length], ["Suspended accounts", students.filter((s) => s.suspended).length], ["Open support", db.support.filter((s) => s.status === "open").length]].map(([l, v]) => (
              <Card key={l as string}><p className="text-2xl font-extrabold text-navy">{v}</p><p className="text-sm text-subtle">{l}</p></Card>
            ))}
          </div>
          <Card><h2 className="font-bold text-navy">Latest open reports</h2><ul className="mt-3 divide-y divide-line">{openReports.slice(0, 5).map((r) => <li key={r.id} className="flex items-center justify-between gap-3 py-2 text-sm"><span className="truncate">{targetLabel(r.targetType, r.targetId)}: {r.reason}</span><Button size="sm" variant="ghost" onClick={() => setTab("reports")}>Review</Button></li>)}</ul>{!openReports.length && <p className="mt-2 text-sm text-subtle">No open reports.</p>}</Card>
        </div>
      )}

      {tab === "users" && (
        <Card className="p-0">
          <div className="border-b border-line p-4"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email or college" aria-label="Search users" /></div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs text-muted uppercase"><tr><th className="px-4 py-3">Student</th><th className="px-4 py-3">Academic</th><th className="px-4 py-3">Trust</th><th className="px-4 py-3">Status</th><th className="px-4 py-3" /></tr></thead>
              <tbody>{students.filter((s) => !q || `${s.name} ${s.email} ${s.college}`.toLowerCase().includes(q.toLowerCase())).map((s) => { const t = trustScore(s.id, db); return (
                <tr key={s.id} className="border-t border-line">
                  <td className="px-4 py-3"><div className="flex items-center gap-2.5"><Avatar name={s.name} src={s.avatar} size={32} className="ring-2" /><div><p className="flex items-center gap-2 font-semibold text-navy">{s.name}{s.sample && <SampleTag />}</p><p className="text-xs text-subtle">{s.email}{s.emailVerified ? "" : " · unverified"}</p></div></div></td>
                  <td className="px-4 py-3 text-xs text-subtle">{s.college}<br />{s.field} · {s.department} · {yearLabel(s.year)}</td>
                  <td className="px-4 py-3">{t.established ? t.total : "New"}</td>
                  <td className="px-4 py-3">{s.suspended ? <Badge tone="rose">Suspended</Badge> : <Badge tone="green">Active</Badge>}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap"><Button size="sm" variant="ghost" href={`/profile/${s.id}`}>View</Button><Button size="sm" variant={s.suspended ? "secondary" : "danger"} onClick={() => run(admin.setSuspended(s.id, !s.suspended), s.suspended ? "Account restored." : "Account suspended.")}>{s.suspended ? "Restore" : <><ShieldOff className="h-4 w-4" /> Suspend</>}</Button></td>
                </tr>
              ); })}</tbody>
            </table>
          </div>
        </Card>
      )}

      {(tab === "reports" || tab === "moderation") && (
        <div className="space-y-4">
          {db.reports.filter((r) => (tab === "reports" ? r.targetType === "user" : r.targetType !== "user")).map((r) => (
            <Card key={r.id} className="flex flex-col gap-3 md:flex-row md:items-center">
              <Flag className="h-5 w-5 shrink-0 text-rose" />
              <div className="min-w-0 flex-1">
                <p className="font-bold text-navy">{targetLabel(r.targetType, r.targetId)}</p>
                <p className="text-sm text-ink">{r.reason}</p>
                <p className="text-xs text-subtle">Reported by {byId(r.reporterId)?.name ?? "deleted user"} · {new Date(r.createdAt).toLocaleDateString()}</p>
              </div>
              <Badge tone={r.status === "open" ? "amber" : "neutral"}>{r.status}</Badge>
              {r.status === "open" && (
                <div className="flex flex-wrap gap-2">
                  {r.targetType === "user" && byId(r.targetId) && <Button size="sm" variant="danger" onClick={() => { run(admin.setSuspended(r.targetId, true), "User suspended."); admin.resolveReport(r.id, "resolved"); }}>Suspend user</Button>}
                  {r.targetType === "review" && db.reviews.some((x) => x.id === r.targetId) && <Button size="sm" variant="danger" onClick={() => run(admin.deleteReview(r.targetId), "Review removed; ratings recalculated.")}><Trash2 className="h-4 w-4" /> Remove review</Button>}
                  {r.targetType === "message" && db.messages.some((x) => x.id === r.targetId) && <Button size="sm" variant="danger" onClick={() => run(admin.deleteMessage(r.targetId), "Message removed.")}><Trash2 className="h-4 w-4" /> Remove message</Button>}
                  <Button size="sm" variant="secondary" onClick={() => run(admin.resolveReport(r.id, "resolved"), "Marked resolved.")}><Check className="h-4 w-4" /> Resolve</Button>
                  <Button size="sm" variant="ghost" onClick={() => run(admin.resolveReport(r.id, "dismissed"), "Dismissed.")}><X className="h-4 w-4" /> Dismiss</Button>
                </div>
              )}
            </Card>
          ))}
          {!db.reports.filter((r) => (tab === "reports" ? r.targetType === "user" : r.targetType !== "user")).length && <Card><p className="text-sm text-subtle">{tab === "reports" ? "No account reports." : "No reported reviews or messages."}</p></Card>}
        </div>
      )}

      {tab === "mentors" && (
        <div className="space-y-6">
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><GraduationCap className="h-5 w-5 text-teal-strong" /> Mentor eligibility review</h2>
            <ul className="mt-4 space-y-4">
              {students.filter((s) => s.mentorStatus !== "none" || mentorCheck(s, db).eligible || s.year >= db.settings.mentorMinYear).map((s) => { const c = mentorCheck(s, db); return (
                <li key={s.id} className="neu-inset rounded-2xl p-4">
                  <div className="flex flex-wrap items-center gap-3">
                    <Avatar name={s.name} src={s.avatar} size={36} className="ring-2" />
                    <span className="flex-1 font-bold text-navy">{s.name} <span className="text-xs font-medium text-subtle">· {yearLabel(s.year)} {s.department}</span></span>
                    <Badge tone={s.mentorStatus === "approved" ? "green" : s.mentorStatus === "rejected" ? "rose" : s.mentorStatus === "pending" ? "amber" : c.eligible ? "teal" : "neutral"}>{s.mentorStatus === "none" ? (c.eligible ? "Auto-eligible" : "Not eligible") : s.mentorStatus}</Badge>
                    <Button size="sm" variant="accent" onClick={() => run(admin.mentorDecision(s.id, "approved"), "Approved as Senior Mentor.")}>Approve</Button>
                    <Button size="sm" variant="danger" onClick={() => run(admin.mentorDecision(s.id, "rejected"), "Badge withheld.")}>Reject</Button>
                    {s.mentorStatus !== "none" && <Button size="sm" variant="ghost" onClick={() => run(admin.mentorDecision(s.id, "none"), "Reset to automatic.")}>Reset</Button>}
                  </div>
                  <ul className="mt-3 grid gap-1 text-xs sm:grid-cols-2">{c.criteria.map((x) => <li key={x.label} className={x.met ? "text-teal-strong" : "text-subtle"}>{x.met ? "✓" : "✗"} {x.label}</li>)}</ul>
                </li>
              ); })}
            </ul>
          </Card>
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><BadgeCheck className="h-5 w-5 text-teal-strong" /> Portfolio verification</h2>
            <ul className="mt-4 divide-y divide-line">
              {students.flatMap((s) => s.certificates.map((c) => ({ s, c }))).map(({ s, c }) => (
                <li key={c.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
                  <span className="flex-1"><b className="text-navy">{c.title}</b> <span className="text-subtle">· {s.name}</span>{c.url && <a href={c.url} target="_blank" rel="noreferrer" className="ml-2 font-semibold text-teal-strong hover:underline">Open evidence</a>}</span>
                  <Badge tone={c.status === "verified" ? "green" : c.status === "evidence" ? "amber" : "neutral"}>{c.status}</Badge>
                  {c.status !== "verified" ? <Button size="sm" variant="accent" disabled={!c.url} onClick={() => run(admin.verifyCertificate(s.id, c.id, true), "Certificate verified.")}>Verify</Button> : <Button size="sm" variant="ghost" onClick={() => run(admin.verifyCertificate(s.id, c.id, false), "Verification removed.")}>Unverify</Button>}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      {tab === "skills" && (
        <Card>
          <h2 className="font-bold text-navy">Skill categories</h2>
          <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); const r = admin.addCategory(cat); run(r, "Category added."); if (r.ok) setCat(""); }}><Input value={cat} onChange={(e) => setCat(e.target.value)} placeholder="New category" aria-label="New category" /><Button type="submit"><Plus className="h-4 w-4" /> Add</Button></form>
          <ul className="mt-4 grid gap-2 sm:grid-cols-2">{db.settings.skillCategories.map((c) => { const n = students.reduce((a, s) => a + s.teach.filter((t) => t.category === c).length, 0); return <li key={c} className="flex items-center justify-between neu-inset rounded-xl px-3 py-2 text-sm"><span className="font-semibold">{c} <span className="text-xs text-subtle">· {n} skills</span></span><button onClick={() => run(admin.removeCategory(c), "Category removed.")} className="text-muted hover:text-rose" aria-label={`Remove ${c}`}><Trash2 className="h-4 w-4" /></button></li>; })}</ul>
        </Card>
      )}

      {tab === "sessions" && (
        <Card className="p-0">
          <div className="border-b border-line p-4"><Select value={sFilter} onChange={(e) => setSFilter(e.target.value)} className="max-w-xs" aria-label="Status"><option value="">All statuses</option>{["Pending", "Accepted", "Completed", "Rejected", "Cancelled"].map((s) => <option key={s}>{s}</option>)}</Select></div>
          <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-xs text-muted uppercase"><tr><th className="px-4 py-3">Skill</th><th className="px-4 py-3">Teacher → Learner</th><th className="px-4 py-3">When</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Status</th></tr></thead>
            <tbody>{db.sessions.filter((s) => !sFilter || s.status === sFilter).sort((a, b) => +sessionStart(b) - +sessionStart(a)).slice(0, 150).map((s) => <tr key={s.id} className="border-t border-line"><td className="px-4 py-2.5 font-semibold"><Link href={`/sessions/${s.id}`} className="hover:underline">{s.skill}</Link></td><td className="px-4 py-2.5 text-subtle">{byId(s.teacherId)?.name ?? "-"} → {byId(s.learnerId)?.name ?? "-"}</td><td className="px-4 py-2.5 text-subtle">{s.date} {s.time}</td><td className="px-4 py-2.5 text-subtle">{s.mode} {s.format}</td><td className="px-4 py-2.5"><Badge tone={s.status === "Completed" ? "green" : s.status === "Accepted" ? "teal" : s.status === "Pending" ? "amber" : "neutral"}>{s.status}</Badge></td></tr>)}</tbody></table></div>
        </Card>
      )}

      {tab === "analytics" && (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card><h2 className="font-bold text-navy">Students by field</h2><div className="mt-4 h-64"><ResponsiveContainer><BarChart data={chart}><CartesianGrid vertical={false} stroke="#e6e8f0" /><XAxis dataKey="field" tick={{ fontSize: 11, fill: "#585f78" }} axisLine={false} tickLine={false} /><YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#585f78" }} axisLine={false} tickLine={false} width={24} /><Tooltip /><Bar dataKey="count" fill="#4c3fc8" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
          <Card><h2 className="font-bold text-navy">Sessions by status</h2><div className="mt-4 h-64"><ResponsiveContainer><BarChart data={sessionsByStatus}><CartesianGrid vertical={false} stroke="#e6e8f0" /><XAxis dataKey="status" tick={{ fontSize: 11, fill: "#585f78" }} axisLine={false} tickLine={false} /><YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#585f78" }} axisLine={false} tickLine={false} width={24} /><Tooltip /><Bar dataKey="count" fill="#1f2547" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
          <Card className="lg:col-span-2"><h2 className="font-bold text-navy">Most taught skills (completed sessions)</h2><ul className="mt-3 grid gap-2 sm:grid-cols-2">{topSkills.map(([s, n]) => <li key={s} className="flex justify-between neu-inset rounded-xl px-3 py-2 text-sm"><span className="font-semibold">{s}</span><span>{n}</span></li>)}</ul><p className="mt-3 text-xs text-subtle">Messages sent: {db.messages.length} · Reviews: {db.reviews.length} · Connections: {db.connections.filter((c) => c.status === "Accepted").length}</p></Card>
        </div>
      )}

      {tab === "support" && (
        <div className="space-y-4">
          {db.support.map((s) => (
            <Card key={s.id} className="flex flex-col gap-3 md:flex-row md:items-start">
              <LifeBuoy className="h-5 w-5 shrink-0 text-teal-strong" />
              <div className="flex-1"><p className="font-bold text-navy">{s.subject}</p><p className="text-sm text-ink">{s.message}</p><p className="text-xs text-subtle">{s.name} · <a href={`mailto:${s.email}`} className="text-teal-strong hover:underline">{s.email}</a> · {new Date(s.createdAt).toLocaleString()}</p></div>
              <Badge tone={s.status === "open" ? "amber" : "neutral"}>{s.status}</Badge>
              {s.status === "open" && <Button size="sm" variant="secondary" onClick={() => run(admin.closeSupport(s.id), "Closed.")}>Close</Button>}
            </Card>
          ))}
          {!db.support.length && <Card><p className="text-sm text-subtle">No support requests.</p></Card>}
        </div>
      )}

      {tab === "settings" && (
        <div className="space-y-6">
          <Card>
            <h2 className="font-bold text-navy">Senior Mentor criteria</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <Field label="Minimum year" htmlFor="a-y"><Select id="a-y" value={db.settings.mentorMinYear} onChange={(e) => { updateSettings({ mentorMinYear: Number(e.target.value) }); toast("Saved."); }}>{[2, 3, 4, 5].map((y) => <option key={y} value={y}>{yearLabel(y)}+</option>)}</Select></Field>
              <Field label="Min completed sessions" htmlFor="a-s"><Select id="a-s" value={db.settings.mentorMinSessions} onChange={(e) => { updateSettings({ mentorMinSessions: Number(e.target.value) }); toast("Saved."); }}>{[1, 3, 5, 10].map((y) => <option key={y} value={y}>{y}</option>)}</Select></Field>
              <Field label="Min average rating" htmlFor="a-r"><Select id="a-r" value={db.settings.mentorMinRating} onChange={(e) => { updateSettings({ mentorMinRating: Number(e.target.value) }); toast("Saved."); }}>{[3.5, 4, 4.3, 4.5].map((y) => <option key={y} value={y}>{y.toFixed(1)}★</option>)}</Select></Field>
            </div>
          </Card>
          <Card>
            <h2 className="font-bold text-navy">Audit log</h2>
            <ul className="mt-3 max-h-96 divide-y divide-line overflow-y-auto">{db.audit.map((a) => <li key={a.id} className="flex justify-between gap-3 py-2 text-sm"><span>{a.action}</span><span className="shrink-0 text-xs text-subtle">{byId(a.adminId)?.name} · {new Date(a.createdAt).toLocaleString()}</span></li>)}</ul>
            {!db.audit.length && <p className="mt-2 text-sm text-subtle">No admin actions yet.</p>}
          </Card>
        </div>
      )}
    </div>
  );
}

export default function Page() {
  return <Suspense><Admin /></Suspense>;
}
