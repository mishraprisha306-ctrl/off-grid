"use client";
import { Eye, EyeOff, LogIn, ShieldCheck, Zap } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { DemoSignIn } from "@/components/demo-signin";
import { GoogleButton } from "@/components/google-button";
import { useToast } from "@/components/toast";
import { Avatar, Button, Field, Input, Modal } from "@/components/ui";
import { yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";

const EMAIL = /^\S+@\S+\.\S+$/;

function LoginForm() {
  const { login, resetPassword, ready, me, db, supabase } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const toast = useToast();
  const next = params.get("next");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState<{ email?: string; pw?: string; form?: string }>({});
  const [busy, setBusy] = useState(false);
  const [forgot, setForgot] = useState(false);
  const [fEmail, setFEmail] = useState("");
  const [fState, setFState] = useState<{ sent?: boolean; error?: string }>({});

  const dest = (role?: string) => next || (role === "admin" ? "/admin" : "/dashboard");
  useEffect(() => {
    if (ready && me) router.replace(dest(me.role));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, me]);

  const submit = async (e?: React.FormEvent, creds?: { email: string; pw: string }) => {
    e?.preventDefault();
    const em = creds?.email ?? email;
    const p = creds?.pw ?? pw;
    const errs: typeof err = {};
    if (!EMAIL.test(em)) errs.email = "Enter a valid email address.";
    if (!p) errs.pw = "Enter your password.";
    setErr(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    const r = await login(em, p);
    setBusy(false);
    if (!r.ok) return setErr({ form: r.error });
    toast("Welcome back!");
  };

  return (
    <>
      <h1 className="text-[1.75rem] font-extrabold tracking-tight text-navy">Welcome back</h1>
      <p className="mt-1 text-subtle">Sign in to keep learning with your peers.</p>

      <DemoSignIn className="mt-7" />

      <div className="mt-6"><GoogleButton /></div>
      <div className="my-6 flex items-center gap-3 text-xs font-semibold tracking-wide text-muted uppercase"><span className="h-px flex-1 bg-line" /> or with email <span className="h-px flex-1 bg-line" /></div>

      <form onSubmit={submit} className="space-y-5" noValidate>
        <Field label="Email address" htmlFor="email" error={err.email}>
          <Input id="email" type="email" autoComplete="email" placeholder="you@college.edu" value={email} onChange={(e) => setEmail(e.target.value)} aria-invalid={!!err.email} />
        </Field>
        <Field label="Password" htmlFor="pw" error={err.pw}>
          <div className="relative">
            <Input id="pw" type={show ? "text" : "password"} autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} aria-invalid={!!err.pw} className="pr-11" />
            <button type="button" onClick={() => setShow((s) => !s)} className="absolute top-1/2 right-3 -translate-y-1/2 p-1 text-muted hover:text-navy" aria-label={show ? "Hide password" : "Show password"}>{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
          </div>
        </Field>
        <div className="flex justify-end"><button type="button" onClick={() => { setForgot(true); setFState({}); setFEmail(email); }} className="text-sm font-semibold text-teal-strong hover:underline">Forgot password?</button></div>
        {err.form && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err.form}</p>}
        <Button type="submit" size="lg" className="w-full" disabled={busy || !ready}><LogIn className="h-4 w-4" /> {busy ? "Signing in…" : "Sign In"}</Button>
      </form>
      <p className="mt-6 text-center text-sm text-subtle">New to PeerUp? <Link href="/signup" className="font-bold text-teal-strong hover:underline">Create an account</Link></p>

      <Modal open={forgot} onClose={() => setForgot(false)} title="Reset your password">
        {fState.sent ? (
          <div className="space-y-4">
            <p className="text-sm text-ink">If an account exists for <b>{fEmail}</b>, a reset link is on its way. Check your inbox and spam folder.</p>
            <Button className="w-full" onClick={() => setForgot(false)}>Back to sign in</Button>
          </div>
        ) : (
          <form className="space-y-4" onSubmit={async (e) => { e.preventDefault(); const r = await resetPassword(fEmail); setFState(r.ok ? { sent: true } : { error: r.error }); }}>
            <p className="text-sm text-subtle">Enter your email and we'll send you a secure link to choose a new password.</p>
            <Field label="Email address" htmlFor="femail"><Input id="femail" type="email" value={fEmail} onChange={(e) => setFEmail(e.target.value)} /></Field>
            {fState.error && <p className="rounded-xl bg-[#f7ecd6] px-4 py-3 text-sm text-[#7a520b]" role="alert">{fState.error}</p>}
            <Button type="submit" className="w-full">Send reset link</Button>
          </form>
        )}
      </Modal>
    </>
  );
}

export default function LoginPage() {
  return <Suspense><LoginForm /></Suspense>;
}
