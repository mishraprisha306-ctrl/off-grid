import { Legal } from "@/components/legal";
export const metadata = { title: "Safety Guidelines" };
export default function Page() {
  return <Legal title="Safety Guidelines" subtitle="Learning should always feel safe." sections={[
    ["Meeting offline", ["Meet on campus or in public places like libraries.", "Tell a friend where you're going for a first meeting.", "You can cancel any session. You never owe anyone a meeting."]],
    ["Online sessions", ["Use trusted meeting tools. Never share passwords or OTPs.", "Recordings require everyone's consent."]],
    ["Protect your information", ["Keep your phone number and address private until you trust someone.", "Use privacy settings to hide your email and student ID."]],
    ["If something goes wrong", ["Block the user immediately and report them.", "For emergencies, contact campus security or local authorities first."]],
  ]} />;
}
