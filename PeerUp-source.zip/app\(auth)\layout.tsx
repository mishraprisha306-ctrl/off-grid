import Link from "next/link";
import { CurveArrow } from "@/components/doodles";
import { Figures, Logo } from "@/components/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-navy p-12 text-white lg:flex">
        <span aria-hidden className="pink-orb pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full opacity-30" />
        <Logo href="/" light />
        <div className="relative mx-auto w-full max-w-sm">
          <span aria-hidden className="absolute inset-[10%] rounded-full bg-[#f6c9cc]/25 shadow-[0_0_110px_50px_rgb(246_201_204/.25)]" />
          <CurveArrow className="absolute -top-12 -left-10 h-16 w-32" color="#f6c9cc" />
          <div className="relative rounded-[36px] bg-ivory p-10 shadow-[0_30px_70px_-20px_rgb(0_0_0/.4)]"><Figures className="w-full" /></div>
        </div>
        <div className="relative">
          <p className="text-3xl leading-tight font-extrabold tracking-tight">Your skills have value.<br /><span className="text-glow text-[#f9d9cf]">Share them.</span></p>
          <p className="mt-3 max-w-md text-white/70">Teach what you know, learn what you don't, and build a reputation that's earned through real sessions.</p>
        </div>
      </section>
      <section className="flex flex-col items-center justify-center px-5 py-10 sm:px-10">
        <div className="w-full max-w-[460px]">
          <div className="mb-8 lg:hidden"><Logo href="/" /></div>
          {children}
          <p className="mt-10 text-center text-xs text-subtle"><Link href="/" className="hover:underline">← Back to home</Link></p>
        </div>
      </section>
    </div>
  );
}
