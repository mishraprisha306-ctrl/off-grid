"use client";
import { LogOut, Save, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { AvatarPicker, InterestEditor } from "@/components/profile-forms";
import { useToast } from "@/components/toast";
import { Button, Card, Field, Input, Modal, PageHeader, Select, Tabs, Textarea } from "@/components/ui";
import { yearLabel } from "@/lib/engines";
import { DEMO_PASSWORD } from "@/lib/seed";
import { useStore } from "@/lib/store";
import { FIELDS, MENTOR_CATEGORIES, type Student, YEARS } from "@/lib/types";

function Toggle({ checked, onChange, label, desc }: { checked: boolean; onChange: (v: boolean) => void; label: string; desc: string }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <span><span className="block font-semibold text-ink">{label}</span><span className="block text-sm text-subtle">{desc}</span></span>
      <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${checked ? "bg-teal-strong shadow-[0_0_12px_2px_rgb(246_201_204/.8)]" : "bg-[#dcdfeb]"}`}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-ivory shadow transition-all ${checked ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}

export default function Settings() {
  const { me, db, updateMe, updateSettings, changePassword, deleteAccount, logout, login, resetDemo, supabase } = useStore();
  const toast = useToast();
  const router = useRouter();
  const [tab, setTab] = useState<"profile" | "privacy" | "notifications" | "account">("profile");
  const [d, setD] = useState<Student>(() => structuredClone(me!));
  const [pw, setPw] = useState({ cur: "", next: "" });
  const [pwErr, setPwErr] = useState("");
  const [del, setDel] = useState(false);
  const [delText, setDelText] = useState("");
  const [reset, setReset] = useState(false);
  const [switchTo, setSwitchTo] = useState("");
  if (!me) return null;
  const run = (r: { ok: boolean; error?: string }, m: string) => toast(r.ok ? m : r.error!, r.ok ? "success" : "error");
  const saveProfile = () => {
    if (d.name.trim().length < 3) return toast("Enter your full name.", "error");
    if (d.studentId && !/^[A-Za-z0-9-\/]{3,20}$/.test(d.studentId)) return toast("Student ID: 3–20 letters, numbers, - or /.", "error");
    run(updateMe({ name: d.name.trim(), avatar: d.avatar, bio: d.bio, college: d.college, field: d.field, department: d.department, year: d.year, studentId: d.studentId || undefined, interests: d.interests, mentorCategories: d.mentorCategories, mentorAvailable: d.mentorAvailable }), "Profile saved.");
  };
  const setPriv = (patch: Partial<Student["privacy"]>) => run(updateMe({ privacy: { ...me.privacy, ...patch } }), "Privacy updated.");
  const doLogout = async () => { await logout(); router.replace("/"); };

  return (
    <div className="max-w-3xl">
      <PageHeader title="Settings" subtitle="Your profile, privacy, notifications and account." />
      <div className="mb-6"><Tabs value={tab} onChange={setTab} tabs={[{ value: "profile", label: "Edit profile" }, { value: "privacy", label: "Privacy" }, { value: "notifications", label: "Notifications" }, { value: "account", label: "Account" }]} /></div>

      {tab === "profile" && (
        <Card className="space-y-5">
          <AvatarPicker name={d.name} value={d.avatar} onChange={(avatar) => setD({ ...d, avatar })} />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Full name" htmlFor="s-n"><Input id="s-n" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} /></Field>
            <Field label="College or university" htmlFor="s-c"><Input id="s-c" value={d.college} onChange={(e) => setD({ ...d, college: e.target.value })} /></Field>
            <Field label="Educational field" htmlFor="s-f"><Select id="s-f" value={d.field} onChange={(e) => setD({ ...d, field: e.target.value as Student["field"] })}>{FIELDS.map((f) => <option key={f}>{f}</option>)}</Select></Field>
            <Field label="Branch or department" htmlFor="s-d"><Input id="s-d" value={d.department} onChange={(e) => setD({ ...d, department: e.target.value })} /></Field>
            <Field label="Academic year" htmlFor="s-y"><Select id="s-y" value={d.year} onChange={(e) => setD({ ...d, year: Number(e.target.value) })}>{YEARS.map((y) => <option key={y} value={y}>{yearLabel(y)}</option>)}</Select></Field>
            <Field label="Student ID (optional)" htmlFor="s-id"><Input id="s-id" value={d.studentId ?? ""} onChange={(e) => setD({ ...d, studentId: e.target.value })} /></Field>
          </div>
          <Field label="Short bio" htmlFor="s-b" hint={`${d.bio.length}/240`}><Textarea id="s-b" rows={3} maxLength={240} value={d.bio} onChange={(e) => setD({ ...d, bio: e.target.value })} /></Field>
          <div><p className="mb-2 text-sm font-semibold text-ink">Interests</p><InterestEditor value={d.interests} onChange={(interests) => setD({ ...d, interests })} /></div>
          <div className="neu-inset rounded-2xl p-4">
            <p className="font-semibold text-navy">Mentorship preferences</p>
            <p className="text-sm text-subtle">Used if you're a Senior Mentor, or once you become one.</p>
            <div className="mt-3 flex flex-wrap gap-2">{MENTOR_CATEGORIES.map((c) => { const on = d.mentorCategories.includes(c); return <button type="button" key={c} aria-pressed={on} onClick={() => setD({ ...d, mentorCategories: on ? d.mentorCategories.filter((x) => x !== c) : [...d.mentorCategories, c] })} className={`rounded-full px-3 py-1 text-xs font-semibold ${on ? "bg-teal-strong text-white" : "bg-ivory text-ink shadow-[var(--shadow-raised-sm)]"}`}>{c}</button>; })}</div>
            <Toggle label="Accepting mentees" desc="Show as available on the Senior Mentors page." checked={d.mentorAvailable} onChange={(v) => setD({ ...d, mentorAvailable: v })} />
          </div>
          <Button onClick={saveProfile}><Save className="h-4 w-4" /> Save profile</Button>
        </Card>
      )}

      {tab === "privacy" && (
        <Card>
          <p className="text-sm text-subtle">Choose what other students can see. Admins can always see account details for safety reviews.</p>
          <div className="mt-2 divide-y divide-line">
            <Toggle label="Show my email" desc="Visible on your public profile." checked={me.privacy.showEmail} onChange={(v) => setPriv({ showEmail: v })} />
            <Toggle label="Show my college" desc="Shown on cards, matches and your profile." checked={me.privacy.showCollege} onChange={(v) => setPriv({ showCollege: v })} />
            <Toggle label="Show my student ID" desc="Most students keep this hidden." checked={me.privacy.showStudentId} onChange={(v) => setPriv({ showStudentId: v })} />
            <Toggle label="Show portfolio links" desc="GitHub, LinkedIn and portfolio on your profile." checked={me.privacy.showLinks} onChange={(v) => setPriv({ showLinks: v })} />
            <div className="flex items-center justify-between gap-4 py-3">
              <span><span className="block font-semibold text-ink">Who can message me</span><span className="block text-sm text-subtle">People you share a session with can always message you.</span></span>
              <Select value={me.privacy.messagesFrom} onChange={(e) => setPriv({ messagesFrom: e.target.value as Student["privacy"]["messagesFrom"] })} className="w-44" aria-label="Who can message me"><option value="connections">Connections only</option><option value="everyone">Everyone</option></Select>
            </div>
          </div>
          <p className="mt-4 text-sm text-subtle">Blocked users: {me.blocked.length}. <a href="/connections" className="font-semibold text-teal-strong">Manage in Connections</a>.</p>
        </Card>
      )}

      {tab === "notifications" && (
        <Card id="notifications">
          <div className="divide-y divide-line">
            <Toggle label="Session updates" desc="Requests, acceptances, reschedules, reminders and cancellations" checked={db.settings.notify.sessions} onChange={(v) => updateSettings({ notify: { ...db.settings.notify, sessions: v } })} />
            <Toggle label="Connection requests" desc="New requests and responses" checked={db.settings.notify.connections} onChange={(v) => updateSettings({ notify: { ...db.settings.notify, connections: v } })} />
            <Toggle label="Ratings & feedback" desc="Rating reminders, new ratings and learner feedback" checked={db.settings.notify.reviews} onChange={(v) => updateSettings({ notify: { ...db.settings.notify, reviews: v } })} />
            <Toggle label="Messages" desc="New direct messages" checked={db.settings.notify.messages} onChange={(v) => updateSettings({ notify: { ...db.settings.notify, messages: v } })} />
            <Toggle label="New matches" desc="When a new mutual match appears" checked={db.settings.notify.matches} onChange={(v) => updateSettings({ notify: { ...db.settings.notify, matches: v } })} />
          </div>
          {!supabase && <p className="mt-3 text-xs text-subtle">Demo mode: preferences are stored in this browser.</p>}
        </Card>
      )}

      {tab === "account" && (
        <div className="space-y-6">
          <Card>
            <h2 className="mb-4 font-bold text-navy">Change password</h2>
            <form className="grid gap-4 sm:grid-cols-2" onSubmit={async (e) => { e.preventDefault(); const r = await changePassword(pw.cur, pw.next); if (!r.ok) return setPwErr(r.error); setPw({ cur: "", next: "" }); setPwErr(""); toast("Password changed."); }}>
              {!supabase && <Field label="Current password" htmlFor="p1"><Input id="p1" type="password" autoComplete="current-password" value={pw.cur} onChange={(e) => setPw({ ...pw, cur: e.target.value })} /></Field>}
              <Field label="New password" htmlFor="p2" error={pwErr}><Input id="p2" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></Field>
              <div><Button type="submit" variant="secondary">Update password</Button></div>
            </form>
          </Card>
          <Card>
            <h2 className="font-bold text-navy">Manage account</h2>
            <p className="mt-1 text-sm text-subtle">Signed in as {me.email}{me.emailVerified ? " · verified" : ""}.</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="secondary" onClick={doLogout}><LogOut className="h-4 w-4" /> Log out</Button>
              {me.role !== "admin" && <Button variant="danger" onClick={() => { setDel(true); setDelText(""); }}><Trash2 className="h-4 w-4" /> Delete account</Button>}
            </div>
          </Card>
          {!supabase && (
            <Card>
              <h2 className="font-bold text-navy">Demo tools</h2>
              <p className="mt-1 text-sm text-subtle">Demo data lives in this browser. Switch to another sample student to test both sides of a request.</p>
              <div className="mt-4 flex flex-col gap-3 sm:flex-row">
                <Select value={switchTo} onChange={(e) => setSwitchTo(e.target.value)} aria-label="Switch demo account" className="sm:max-w-xs"><option value="">Switch to account…</option>{db.students.filter((s) => s.id !== me.id && s.sample).map((s) => <option key={s.id} value={s.email}>{s.name}{s.role === "admin" ? " (admin)" : ""}</option>)}</Select>
                <Button variant="secondary" disabled={!switchTo} onClick={async () => { await logout(); const r = await login(switchTo, DEMO_PASSWORD); toast(r.ok ? "Switched account." : "That account no longer uses the demo password.", r.ok ? "success" : "error"); router.replace(r.ok ? "/dashboard" : "/login"); }}>Switch</Button>
                <Button variant="danger" onClick={() => setReset(true)}>Reset demo data</Button>
              </div>
            </Card>
          )}
        </div>
      )}

      <Modal open={del} onClose={() => setDel(false)} title="Delete your account?">
        <p className="text-sm text-ink">This permanently deletes your profile, skills, connections, messages, progress and resources. Upcoming sessions are cancelled. Past sessions and reviews stay as anonymised history for the other participants. This can't be undone.</p>
        <Field label='Type "DELETE" to confirm' htmlFor="del"><Input id="del" value={delText} onChange={(e) => setDelText(e.target.value)} /></Field>
        <div className="mt-6 flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setDel(false)}>Cancel</Button><Button variant="danger" className="flex-1" disabled={delText !== "DELETE"} onClick={() => { const r = deleteAccount(); if (!r.ok) return toast(r.error, "error"); toast("Account deleted.", "info"); router.replace("/"); }}>Delete account</Button></div>
      </Modal>
      <Modal open={reset} onClose={() => setReset(false)} title="Reset all demo data?">
        <p className="text-sm text-ink">Replaces every profile, session, rating and message in this browser with the original sample data and signs you out. Accounts you created are removed. This can't be undone.</p>
        <div className="mt-6 flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setReset(false)}>Cancel</Button><Button variant="danger" className="flex-1" onClick={() => { resetDemo(); setReset(false); toast("Demo data reset.", "info"); router.replace("/login"); }}>Reset data</Button></div>
      </Modal>
    </div>
  );
}
