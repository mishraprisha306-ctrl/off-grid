"use client";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/logo";
import { AvatarPicker, InterestEditor, LearnEditor, SlotEditor, TeachEditor } from "@/components/profile-forms";
import { useToast } from "@/components/toast";
import { Button, Card, Field, Input, Select, Textarea, cn } from "@/components/ui";
import { profileCompletion, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FIELDS, FORMATS, type SessionFormat, type Student, YEARS } from "@/lib/types";

const STEPS = ["About you", "Academics", "Skills", "Preferences", "Review"];

export default function Onboarding() {
  const { me, updateMe } = useStore();
  const router = useRouter();
  const toast = useToast();
  const [step, setStep] = useState(0);
  const [d, setD] = useState<Student>(() => structuredClone(me!));
  const [err, setErr] = useState("");
  if (!me) return null;
  const pct = profileCompletion(d);

  const validate = (i: number) => {
    if (i === 0 && d.name.trim().length < 3) return "Enter your full name.";
    if (i === 1 && (d.college.trim().length < 3 || d.department.trim().length < 2)) return "Add your college and department.";
    if (i === 2 && (!d.teach.length || !d.learn.length)) return "Add at least one skill you can teach and one you want to learn, so we can find matches.";
    if (i === 3 && !d.formats.length) return "Pick at least one session type.";
    return "";
  };
  const next = () => {
    const e = validate(step);
    if (e) return setErr(e);
    setErr("");
    setStep((s) => Math.min(STEPS.length - 1, s + 1));
  };
  const finish = () => {
    for (let i = 0; i < 4; i++) {
      const e = validate(i);
      if (e) { setStep(i); return setErr(e); }
    }
    const r = updateMe({ ...d, onboarded: true });
    if (!r.ok) return setErr(r.error);
    toast("Profile ready! Here are your matches.");
    router.replace("/dashboard");
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-8 flex items-center justify-between"><Logo href="/" /><span className="text-sm font-semibold text-subtle">Profile {pct}% complete</span></div>
      <ol className="mb-8 grid grid-cols-5 gap-1.5 sm:gap-2" aria-label="Onboarding steps">
        {STEPS.map((s, i) => (
          <li key={s}>
            <button onClick={() => i < step && setStep(i)} className="w-full text-left" disabled={i > step} aria-current={i === step ? "step" : undefined}>
              <span className={cn("block h-1.5 rounded-full", i <= step ? "bg-teal-strong" : "bg-[#e3e5ef]", i === step && "shadow-[0_0_10px_2px_rgb(246_201_204/.9)]")} />
              <span className={cn("mt-2 hidden text-xs font-bold sm:block", i === step ? "text-navy" : "text-subtle")}>{i + 1}. {s}</span>
            </button>
          </li>
        ))}
      </ol>
      <Card className="p-6 sm:p-8">
        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.22 }} className="space-y-5">
            {step === 0 && (
              <>
                <h1 className="text-2xl font-extrabold text-navy">Let's set up your profile</h1>
                <AvatarPicker name={d.name} value={d.avatar} onChange={(avatar) => setD({ ...d, avatar })} />
                <Field label="Full name" htmlFor="o-n"><Input id="o-n" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} /></Field>
                <Field label="Short bio (optional)" htmlFor="o-b" hint={`${d.bio.length}/240`}><Textarea id="o-b" rows={3} maxLength={240} value={d.bio} onChange={(e) => setD({ ...d, bio: e.target.value })} placeholder="What do you love learning and teaching?" /></Field>
                <div><p className="mb-2 text-sm font-semibold text-ink">Interests (optional)</p><InterestEditor value={d.interests} onChange={(interests) => setD({ ...d, interests })} /></div>
              </>
            )}
            {step === 1 && (
              <>
                <h1 className="text-2xl font-extrabold text-navy">Academic details</h1>
                <Field label="College or university" htmlFor="o-c"><Input id="o-c" value={d.college} onChange={(e) => setD({ ...d, college: e.target.value })} /></Field>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Field label="Educational field" htmlFor="o-f"><Select id="o-f" value={d.field} onChange={(e) => setD({ ...d, field: e.target.value as Student["field"] })}>{FIELDS.map((x) => <option key={x}>{x}</option>)}</Select></Field>
                  <Field label="Branch or department" htmlFor="o-d"><Input id="o-d" value={d.department} onChange={(e) => setD({ ...d, department: e.target.value })} /></Field>
                  <Field label="Academic year" htmlFor="o-y"><Select id="o-y" value={d.year} onChange={(e) => setD({ ...d, year: Number(e.target.value) })}>{YEARS.map((y) => <option key={y} value={y}>{yearLabel(y)}</option>)}</Select></Field>
                </div>
              </>
            )}
            {step === 2 && (
              <>
                <h1 className="text-2xl font-extrabold text-navy">Your skills</h1>
                <div><p className="mb-2 font-bold text-navy">Skills I can teach</p><TeachEditor value={d.teach} learn={d.learn} onChange={(teach) => setD({ ...d, teach })} /></div>
                <div><p className="mb-2 font-bold text-navy">Skills I want to learn</p><LearnEditor value={d.learn} teach={d.teach} onChange={(learn) => setD({ ...d, learn })} /></div>
              </>
            )}
            {step === 3 && (
              <>
                <h1 className="text-2xl font-extrabold text-navy">How you like to learn</h1>
                <Field label="Preferred learning mode" htmlFor="o-m"><Select id="o-m" value={d.mode} onChange={(e) => setD({ ...d, mode: e.target.value as Student["mode"] })}><option value="both">Both online and offline</option><option value="online">Online</option><option value="offline">Offline</option></Select></Field>
                <div>
                  <p className="mb-2 text-sm font-semibold text-ink">Preferred session type</p>
                  <div className="flex gap-3">{FORMATS.map((f) => (
                    <label key={f} className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={d.formats.includes(f)} onChange={(e) => setD({ ...d, formats: e.target.checked ? [...d.formats, f] : d.formats.filter((x: SessionFormat) => x !== f) })} /> {f}</label>
                  ))}</div>
                </div>
                <div><p className="mb-2 text-sm font-semibold text-ink">Availability (optional)</p><SlotEditor value={d.slots} onChange={(slots) => setD({ ...d, slots })} /></div>
              </>
            )}
            {step === 4 && (
              <>
                <h1 className="text-2xl font-extrabold text-navy">Looks great, {d.name.split(" ")[0]}!</h1>
                <dl className="grid gap-3 text-sm sm:grid-cols-2">
                  {[["College", d.college], ["Field", `${d.field} · ${d.department}`], ["Year", yearLabel(d.year)], ["Teaches", d.teach.map((t) => `${t.name} (${t.level})`).join(", ")], ["Learning", d.learn.map((t) => t.name).join(", ")], ["Availability", d.slots.length ? d.slots.map((s) => `${s.day} ${s.from}`).join(", ") : "Not set"]].map(([k, v]) => (
                    <div key={k} className="neu-inset rounded-xl p-3"><dt className="text-xs text-subtle">{k}</dt><dd className="font-semibold text-navy">{v || "-"}</dd></div>
                  ))}
                </dl>
                <p className="text-sm text-subtle">You can change any of this later in My Skills and Settings.</p>
              </>
            )}
          </motion.div>
        </AnimatePresence>
        {err && <p className="mt-5 rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{err}</p>}
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => { setErr(""); setStep((s) => Math.max(0, s - 1)); }} disabled={step === 0}><ArrowLeft className="h-4 w-4" /> Back</Button>
          <div className="flex flex-wrap gap-2">
            {(step === 0 || step === 3) && <Button variant="secondary" onClick={next}>Skip optional</Button>}
            {step < STEPS.length - 1 ? <Button onClick={next}>Continue <ArrowRight className="h-4 w-4" /></Button> : <Button variant="accent" onClick={finish}><Check className="h-4 w-4" /> Finish & go to dashboard</Button>}
          </div>
        </div>
      </Card>
    </div>
  );
}
