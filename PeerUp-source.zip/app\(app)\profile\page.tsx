"use client";
import { ProfileView } from "@/components/profile-view";
import { useStore } from "@/lib/store";

export default function MyProfile() {
  const { me } = useStore();
  return me ? <ProfileView student={me} /> : null;
}
