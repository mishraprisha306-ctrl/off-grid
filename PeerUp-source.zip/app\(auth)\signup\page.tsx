"use client";
import { Check, Eye, EyeOff, MailCheck, UserPlus } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { DemoSignIn } from "@/components/demo-signin";
import { GoogleButton } from "@/components/google-button";
import { useToast } from "@/components/toast";
import { Button, Field, Input, Select, cn } from "@/components/ui";
import { yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { FIELDS, type Field as Fld, YEARS } from "@/lib/types";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export default function SignupPage() {
  const { signup } = useStore();
  const router = useRouter();
  const toast = useToast();
  const [f, setF] = useState({ name: "", email: "", password: "", confirm: "", college: "", field: "", department: "", year: "", studentId: "" });
  const [agree, setAgree] = useState({ terms: false, privacy: false });
  const [show, setShow] = useState(false);
  const [touched, setTouched] = useState(false);
  const [formErr, setFormErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [verify, setVerify] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF((x) => ({ ...x, [k]: e.target.value }));

  const rules = [
    { ok: f.password.length >= 8, label: "8+ characters" },
    { ok: /[A-Z]/.test(f.password), label: "Uppercase letter" },
    { ok: /\d/.test(f.password), label: "Number" },
    { ok: /[^A-Za-z0-9]/.test(f.password), label: "Symbol" },
  ];
  const strength = rules.filter((r) => r.ok).length;
  const errors = useMemo(() => {
    const e: Partial<Record<keyof typeof f | "agree", string>> = {};
    if (f.name.trim().length < 3) e.name = "Enter your full name.";
    if (!EMAIL.test(f.email.trim())) e.email = "Enter a valid email address.";
    if (strength < 4) e.password = "Password doesn't meet all the rules.";
    if (f.confirm !== f.password || !f.confirm) e.confirm = "Passwords don't match.";
    if (f.college.trim().length < 3) e.college = "Enter your college or university.";
    if (!f.field) e.field = "Select your educational field.";
    if (f.department.trim().length < 2) e.department = "Enter your department or branch.";
    if (f.year === "") e.year = "Select your academic year.";
    if (f.studentId && !/^[A-Za-z0-9-\/]{3,20}$/.test(f.studentId)) e.studentId = "Use 3–20 letters, numbers, - or /.";
    if (!agree.terms || !agree.privacy) e.agree = "Please accept the Terms and the Privacy Policy.";
    return e;
  }, [f, agree, strength]);
  const show_ = (k: keyof typeof errors) => (touched ? errors[k] : undefined);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    setFormErr("");
    if (Object.keys(errors).length) return;
    setBusy(true);
    const r = await signup({ name: f.name, email: f.email, password: f.password, college: f.college, field: f.field as Fld, department: f.department, year: Number(f.year), studentId: f.studentId });
    setBusy(false);
    if (!r.ok) return setFormErr(r.error);
    if (r.info === "verify") return setVerify(true);
    toast("Account created. Let's set up your profile.");
    router.replace("/onboarding");
  };

  if (verify)
    return (
      <div className="text-center">
        <MailCheck className="mx-auto h-14 w-14 text-teal-strong" />
        <h1 className="mt-4 text-2xl font-extrabold text-navy">Verify your email</h1>
        <p className="mt-2 text-subtle">We sent a verification link to <b>{f.email}</b>. Open it to activate your account, then sign in.</p>
        <Button href="/login" className="mt-6">Go to sign in</Button>
      </div>
    );

  return (
    <>
      <h1 className="text-[1.75rem] font-extrabold tracking-tight text-navy">Create your account</h1>
      <p className="mt-1 text-subtle">Join students teaching and learning across colleges.</p>
      <DemoSignIn className="mt-6" title="Skip sign-up: continue as" />
      <div className="mt-6"><GoogleButton label="Sign up with Google" /></div>
      <div className="my-6 flex items-center gap-3 text-xs font-semibold tracking-wide text-muted uppercase"><span className="h-px flex-1 bg-line" /> or with email <span className="h-px flex-1 bg-line" /></div>

      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Full name" htmlFor="name" error={show_("name")}><Input id="name" autoComplete="name" value={f.name} onChange={set("name")} aria-invalid={!!show_("name")} /></Field>
        <Field label="College email or email address" htmlFor="email" error={show_("email")}><Input id="email" type="email" autoComplete="email" placeholder="you@college.edu" value={f.email} onChange={set("email")} aria-invalid={!!show_("email")} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Password" htmlFor="password" error={show_("password")}>
            <div className="relative">
              <Input id="password" type={show ? "text" : "password"} autoComplete="new-password" value={f.password} onChange={set("password")} aria-invalid={!!show_("password")} className="pr-11" />
              <button type="button" onClick={() => setShow(!show)} className="absolute top-1/2 right-3 -translate-y-1/2 p-1 text-muted" aria-label={show ? "Hide password" : "Show password"}>{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
            </div>
          </Field>
          <Field label="Confirm password" htmlFor="confirm" error={show_("confirm")}><Input id="confirm" type={show ? "text" : "password"} autoComplete="new-password" value={f.confirm} onChange={set("confirm")} aria-invalid={!!show_("confirm")} /></Field>
        </div>
        <div>
          <div className="flex gap-1" aria-hidden>{[0, 1, 2, 3].map((i) => <span key={i} className={cn("h-1.5 flex-1 rounded-full", i < strength ? (strength < 3 ? "bg-amber" : "bg-teal-strong") : "bg-[#e3e5ef]")} />)}</div>
          <ul className="mt-2 grid grid-cols-2 gap-1 sm:grid-cols-4">{rules.map((r) => <li key={r.label} className={cn("flex items-center gap-1 text-xs font-medium", r.ok ? "text-teal-strong" : "text-subtle")}><Check className={cn("h-3.5 w-3.5", !r.ok && "opacity-30")} />{r.label}</li>)}</ul>
        </div>
        <Field label="College or university" htmlFor="college" error={show_("college")}><Input id="college" value={f.college} onChange={set("college")} aria-invalid={!!show_("college")} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Educational field" htmlFor="field" error={show_("field")}><Select id="field" value={f.field} onChange={set("field")} aria-invalid={!!show_("field")}><option value="">Select…</option>{FIELDS.map((x) => <option key={x}>{x}</option>)}</Select></Field>
          <Field label="Department or branch" htmlFor="dept" error={show_("department")}><Input id="dept" placeholder="e.g. CSE, BA LLB, MBBS" value={f.department} onChange={set("department")} aria-invalid={!!show_("department")} /></Field>
          <Field label="Academic year" htmlFor="year" error={show_("year")}><Select id="year" value={f.year} onChange={set("year")} aria-invalid={!!show_("year")}><option value="">Select…</option>{YEARS.map((y) => <option key={y} value={y}>{yearLabel(y)}</option>)}</Select></Field>
          <Field label="Student ID (optional)" htmlFor="sid" error={show_("studentId")} hint="Hidden from others by default."><Input id="sid" value={f.studentId} onChange={set("studentId")} /></Field>
        </div>
        <div className="space-y-2 text-sm">
          <label className="flex items-start gap-2.5"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#4c3fc8]" checked={agree.terms} onChange={(e) => setAgree({ ...agree, terms: e.target.checked })} /> <span>I agree to the <Link href="/terms" target="_blank" className="font-semibold text-teal-strong hover:underline">Terms and Conditions</Link></span></label>
          <label className="flex items-start gap-2.5"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#4c3fc8]" checked={agree.privacy} onChange={(e) => setAgree({ ...agree, privacy: e.target.checked })} /> <span>I've read the <Link href="/privacy" target="_blank" className="font-semibold text-teal-strong hover:underline">Privacy Policy</Link></span></label>
          {show_("agree") && <p className="text-xs font-medium text-rose" role="alert">{errors.agree}</p>}
        </div>
        {formErr && <p className="rounded-xl bg-[#f8e3e1] px-4 py-3 text-sm font-semibold text-[#a33f37]" role="alert">{formErr}</p>}
        <Button type="submit" size="lg" variant="accent" className="w-full" disabled={busy}><UserPlus className="h-4 w-4" /> {busy ? "Creating account…" : "Create Account"}</Button>
      </form>
      <p className="mt-6 text-center text-sm text-subtle">Already have an account? <Link href="/login" className="font-bold text-teal-strong hover:underline">Sign in</Link></p>
    </>
  );
}
