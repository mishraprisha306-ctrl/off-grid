"use client";
import { Camera, Plus, Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { normSkill } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { DAYS, LEVELS, type LearnSkill, type Level, type Slot, type Student, type TeachSkill } from "@/lib/types";
import { useToast } from "./toast";
import { Avatar, Badge, Button, Input, Select, SkillChip, Textarea } from "./ui";

const SUGGEST = ["Python", "Java", "C Programming", "C++", "JavaScript", "React", "HTML", "CSS", "Web Development", "UI/UX Design", "Figma", "Graphic Design",
  "Video Editing", "Public Speaking", "Communication Skills", "Mathematics", "Calculus", "Statistics", "Chemistry", "Biology", "Anatomy", "Legal Writing",
  "Constitutional Law", "Business Strategy", "Digital Marketing", "Excel", "Accounting", "Data Science", "Machine Learning", "SQL"];

/** Compress an uploaded image to a 256px JPEG data URL (keeps localStorage small; Supabase Storage in production). */
export async function compressImage(file: File, max = 256): Promise<string> {
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("Use a JPG, PNG or WebP image.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Image must be under 5 MB.");
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.82);
}

export function AvatarPicker({ name, value, onChange }: { name: string; value?: string; onChange: (v?: string) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const toast = useToast();
  return (
    <div className="flex items-center gap-4">
      <Avatar name={name || "You"} src={value} size={84} />
      <div className="flex flex-wrap gap-2">
        <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          try { onChange(await compressImage(f)); } catch (err) { toast((err as Error).message, "error"); }
          e.target.value = "";
        }} />
        <Button type="button" size="sm" variant="secondary" onClick={() => ref.current?.click()}><Camera className="h-4 w-4" /> {value ? "Change photo" : "Upload photo"}</Button>
        {value && <Button type="button" size="sm" variant="ghost" onClick={() => onChange(undefined)}>Remove</Button>}
        <p className="w-full text-xs text-subtle">JPG, PNG or WebP, up to 5 MB. Optional.</p>
      </div>
    </div>
  );
}

export function TeachEditor({ value, onChange, learn }: { value: TeachSkill[]; onChange: (v: TeachSkill[]) => void; learn: LearnSkill[] }) {
  const { db } = useStore();
  const [d, setD] = useState<TeachSkill>({ name: "", category: "Programming", level: "Intermediate", description: "", mode: "both", link: "" });
  const [err, setErr] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const add = () => {
    const n = d.name.trim();
    if (!n) return setErr("Enter a skill name.");
    if (value.some((t) => normSkill(t.name) === normSkill(n) && t.name !== editing)) return setErr(`${n} is already in your list.`);
    if (learn.some((t) => normSkill(t.name) === normSkill(n))) return setErr(`${n} is in your learning goals. Remove it there first.`);
    if (d.link && !/^https?:\/\/\S+$/.test(d.link)) return setErr("Portfolio link must start with https://");
    const item = { ...d, name: n, description: d.description?.trim(), link: d.link?.trim() || undefined };
    onChange(editing ? value.map((t) => (t.name === editing ? item : t)) : [...value, item]);
    setD({ name: "", category: d.category, level: "Intermediate", description: "", mode: "both", link: "" });
    setEditing(null);
    setErr("");
  };
  return (
    <div className="space-y-3">
      <ul className="space-y-2">
        {value.map((t) => (
          <li key={t.name} className="flex items-start gap-3 neu-inset rounded-2xl p-3">
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-center gap-2 font-semibold text-navy">{t.name} <Badge tone={t.level === "Advanced" ? "teal" : "navy"}>{t.level}</Badge><span className="text-xs font-medium text-subtle">{t.category}</span></p>
              {t.description && <p className="mt-0.5 text-sm text-subtle">{t.description}</p>}
            </div>
            <Button type="button" size="sm" variant="ghost" onClick={() => { setD({ ...t, description: t.description ?? "", link: t.link ?? "" }); setEditing(t.name); }}>Edit</Button>
            <button type="button" onClick={() => onChange(value.filter((x) => x.name !== t.name))} className="rounded-lg p-2 text-muted hover:text-rose" aria-label={`Delete ${t.name}`}><Trash2 className="h-4 w-4" /></button>
          </li>
        ))}
      </ul>
      <div className="space-y-2 rounded-2xl border border-dashed border-[#cfd3e6] p-3">
        <div className="grid gap-2 sm:grid-cols-[1.4fr_1fr_1fr]">
          <Input list="skill-sugg" placeholder="Skill name, e.g. Python" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} aria-label="Skill name" />
          <Select value={d.category} onChange={(e) => setD({ ...d, category: e.target.value as TeachSkill["category"] })} aria-label="Category">{db.settings.skillCategories.map((c) => <option key={c}>{c}</option>)}</Select>
          <Select value={d.level} onChange={(e) => setD({ ...d, level: e.target.value as Level })} aria-label="Your level">{LEVELS.map((l) => <option key={l}>{l}</option>)}</Select>
        </div>
        <Textarea rows={2} placeholder="Short description: what you can teach and how (optional)" value={d.description} onChange={(e) => setD({ ...d, description: e.target.value })} maxLength={200} aria-label="Skill description" />
        <div className="grid gap-2 sm:grid-cols-[1fr_1.4fr_auto]">
          <Select value={d.mode} onChange={(e) => setD({ ...d, mode: e.target.value as TeachSkill["mode"] })} aria-label="Preferred mode"><option value="both">Online & offline</option><option value="online">Online only</option><option value="offline">Offline only</option></Select>
          <Input placeholder="Portfolio or project link (optional)" value={d.link} onChange={(e) => setD({ ...d, link: e.target.value })} aria-label="Portfolio link" />
          <Button type="button" variant="secondary" onClick={add}><Plus className="h-4 w-4" /> {editing ? "Save" : "Add skill"}</Button>
        </div>
        {err && <p className="text-xs font-semibold text-rose" role="alert">{err}</p>}
        <p className="text-xs text-subtle">Pick your real level for each skill. It doesn't depend on your year.</p>
      </div>
      <datalist id="skill-sugg">{[...new Set([...SUGGEST, ...db.students.flatMap((s) => s.teach.map((t) => t.name))])].map((s) => <option key={s} value={s} />)}</datalist>
    </div>
  );
}

export function LearnEditor({ value, onChange, teach }: { value: LearnSkill[]; onChange: (v: LearnSkill[]) => void; teach: TeachSkill[] }) {
  const { db } = useStore();
  const [name, setName] = useState("");
  const [cat, setCat] = useState<LearnSkill["category"]>("Programming");
  const [level, setLevel] = useState<Level>("Beginner");
  const [err, setErr] = useState("");
  const add = () => {
    const n = name.trim();
    if (!n) return;
    if (value.some((t) => normSkill(t.name) === normSkill(n))) return setErr(`${n} is already a goal.`);
    if (teach.some((t) => normSkill(t.name) === normSkill(n))) return setErr(`You already teach ${n}.`);
    onChange([...value, { name: n, category: cat, level }]);
    setName("");
    setErr("");
  };
  return (
    <div className="space-y-3">
      <div className="flex min-h-9 flex-wrap gap-2">{value.map((t) => <SkillChip key={t.name} tone="teal" onRemove={() => onChange(value.filter((x) => x.name !== t.name))}>{t.name}{t.level && <span className="opacity-60"> · now {t.level}</span>}</SkillChip>)}</div>
      <div className="grid gap-2 sm:grid-cols-[1.4fr_1fr_1fr_auto]">
        <Input list="skill-sugg" placeholder="e.g. Java" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())} aria-label="Skill to learn" />
        <Select value={cat} onChange={(e) => setCat(e.target.value as LearnSkill["category"])} aria-label="Category">{db.settings.skillCategories.map((c) => <option key={c}>{c}</option>)}</Select>
        <Select value={level} onChange={(e) => setLevel(e.target.value as Level)} aria-label="Your current level">{LEVELS.map((l) => <option key={l}>{l}</option>)}</Select>
        <Button type="button" variant="secondary" onClick={add}><Plus className="h-4 w-4" /> Add</Button>
      </div>
      {err && <p className="text-xs font-semibold text-rose" role="alert">{err}</p>}
    </div>
  );
}

export function SlotEditor({ value, onChange }: { value: Slot[]; onChange: (v: Slot[]) => void }) {
  const [d, setD] = useState<Slot>({ day: "Mon", from: "17:00", to: "19:00" });
  const [err, setErr] = useState("");
  return (
    <div className="space-y-3">
      <div className="flex min-h-9 flex-wrap gap-2">{value.map((s, i) => <SkillChip key={i} onRemove={() => onChange(value.filter((_, j) => j !== i))}>{s.day} {s.from}–{s.to}</SkillChip>)}</div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]">
        <Select value={d.day} onChange={(e) => setD({ ...d, day: e.target.value as Slot["day"] })} aria-label="Day">{DAYS.map((x) => <option key={x}>{x}</option>)}</Select>
        <Input type="time" value={d.from} onChange={(e) => setD({ ...d, from: e.target.value })} aria-label="From" />
        <Input type="time" value={d.to} onChange={(e) => setD({ ...d, to: e.target.value })} aria-label="To" />
        <Button type="button" variant="secondary" onClick={() => {
          if (d.to <= d.from) return setErr("End time must be after start time.");
          if (value.some((s) => s.day === d.day && s.from < d.to && d.from < s.to)) return setErr("That overlaps an existing slot.");
          onChange([...value, d].sort((a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || a.from.localeCompare(b.from)));
          setErr("");
        }}><Plus className="h-4 w-4" /> Add slot</Button>
      </div>
      {err && <p className="text-xs font-semibold text-rose" role="alert">{err}</p>}
    </div>
  );
}

export function InterestEditor({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [v, setV] = useState("");
  const add = () => {
    const n = v.trim();
    if (n && !value.some((x) => x.toLowerCase() === n.toLowerCase()) && value.length < 12) onChange([...value, n]);
    setV("");
  };
  return (
    <div className="space-y-2">
      <div className="flex min-h-9 flex-wrap gap-2">{value.map((x) => <SkillChip key={x} onRemove={() => onChange(value.filter((y) => y !== x))}>{x}</SkillChip>)}</div>
      <div className="flex gap-2"><Input placeholder="e.g. Hackathons, Research, Debate" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())} aria-label="Interest" /><Button type="button" variant="secondary" onClick={add}>Add</Button></div>
    </div>
  );
}

export type Draft = Student;
