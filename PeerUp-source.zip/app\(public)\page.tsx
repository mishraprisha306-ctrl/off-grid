"use client";
import { motion } from "framer-motion";
import {
  ArrowRight, BadgeCheck, BookOpen, Briefcase, Code2, Gavel, GraduationCap, HeartPulse, Lightbulb, MessageCircle, Palette, Scale, ShieldCheck,
  Sigma, Users, Video,
} from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { SampleTag } from "@/components/domain";
import { CurveArrow, LoopArrow } from "@/components/doodles";
import { Figures } from "@/components/logo";
import { Avatar, Button, Card, Counter, MentorBadge, SkillChip, Stars, cn } from "@/components/ui";
import { isMentor, ratingSummary, trustScore, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";

const fade = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as const } } };
const Section = ({ id, title, sub, children, className }: { id?: string; eyebrow?: string; title: string; sub?: string; children: React.ReactNode; className?: string }) => (
  <motion.section id={id} variants={fade} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }} className={cn("mx-auto max-w-7xl scroll-mt-24 px-5 pt-24 sm:px-8", className)}>
    <h2 className="mt-2 max-w-2xl text-3xl font-extrabold tracking-tight text-navy sm:text-[2.4rem] sm:leading-[1.1]">{title}</h2>
    {sub && <p className="mt-3 max-w-2xl text-lg text-subtle">{sub}</p>}
    <div className="mt-10">{children}</div>
  </motion.section>
);

const CATS = [
  { icon: Code2, name: "Programming", q: "Python" }, { icon: Palette, name: "Design", q: "Figma" }, { icon: Sigma, name: "Mathematics", q: "Calculus" },
  { icon: HeartPulse, name: "Medical & Health", q: "Anatomy" }, { icon: Gavel, name: "Legal Studies", q: "Legal" }, { icon: Briefcase, name: "Business", q: "Marketing" },
  { icon: Lightbulb, name: "Science", q: "Chemistry" }, { icon: Video, name: "Video Editing", q: "Video" },
];
const FAQ = [
  ["What is peer learning?", "Students teaching students. You learn from someone who recently mastered the same topic, and you teach what you're good at."],
  ["How does mutual matching work?", "If you can teach something another student wants, and they can teach something you want, you're a mutual match. One-way matches are shown separately and never called mutual."],
  ["How are ratings calculated?", "Only learners from completed sessions can rate. Your average is the sum of eligible star ratings divided by how many there are. 5, 4, 5 and 4 average to 4.5."],
  ["What is a trust score?", "A transparent 0–100 score built from ratings, completed sessions, consistency and reliability. It's never based on your academic year."],
  ["Are sessions free?", "Yes. PeerUp is a skill exchange: you trade knowledge, not money."],
];

export default function Landing() {
  const { db, ready } = useStore();
  const [faq, setFaq] = useState(0);
  const students = db.students.filter((s) => s.role !== "admin" && !s.suspended);
  const ranked = useMemo(() => students.map((s) => ({ s, r: ratingSummary(s.id, db.reviews), t: trustScore(s.id, db) })), [db, students]);
  const topTeachers = [...ranked].filter((x) => x.t.established).sort((a, b) => b.t.total - a.t.total).slice(0, 4);
  const mentors = ranked.filter((x) => isMentor(x.s, db)).sort((a, b) => (b.r.average ?? 0) - (a.r.average ?? 0)).slice(0, 3);
  const featuredSkills = ranked.flatMap((x) => x.s.teach.slice(0, 1).map((t) => ({ ...x, t2: t }))).filter((x) => x.r.count >= 3).slice(0, 6);
  const quotes = db.reviews.filter((r) => r.comment.length > 50).slice(0, 3);
  const stats = [
    { label: "Students", value: students.length },
    { label: "Skills on offer", value: new Set(students.flatMap((s) => s.teach.map((t) => t.name.toLowerCase()))).size },
    { label: "Sessions completed", value: db.sessions.filter((s) => s.status === "Completed").length },
    { label: "Colleges", value: new Set(students.map((s) => s.college)).size },
  ];

  return (
    <div>
      {/* ---------------- hero ---------------- */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 pt-14 pb-10 sm:px-8 lg:grid-cols-[1.1fr_1fr] lg:pt-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="text-sm font-semibold text-subtle">Peer learning with honest ratings</p>
            <h1 className="mt-5 text-[2.6rem] leading-[1.04] font-extrabold tracking-tight text-navy sm:text-6xl">
              Your skills have value.<br />
              <span className="relative inline-block">Share them.<span aria-hidden className="absolute -bottom-1 left-0 h-3 w-full rounded-full bg-blush/70 shadow-[0_0_18px_4px_rgb(246_201_204/.8)] -z-10" /></span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-subtle">Learn together, teach each other and grow through a community of student mentors and learners, across colleges, branches and years.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button href="/signup" size="lg" variant="accent">Get Started <ArrowRight className="h-4 w-4" /></Button>
              <Button href="/explore" size="lg" variant="secondary">Explore Skills</Button>
            </div>
            <p className="mt-5 text-sm text-subtle">Want a look first? <Link href="/login" className="font-bold text-teal-strong hover:underline">Sign in with a demo student</Link>. No sign-up needed.</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.1 }} className="relative mx-auto w-full max-w-[520px]">
            <div aria-hidden className="absolute inset-[12%] rounded-full bg-[#fbe1e0] shadow-[0_0_120px_60px_rgb(249_217_207/.7)]" />
            <div className="relative rounded-[32px] bg-ivory p-10 shadow-[0_30px_80px_-30px_rgb(31_37_71/.35)]">
              <div aria-hidden className="absolute inset-x-16 top-10 h-40 rounded-full bg-[#f6c9cc]/25 shadow-[0_0_90px_40px_rgb(246_201_204/.22)]" />
              <Figures className="relative mx-auto w-[70%]" />
              <p className="relative mt-6 text-center"><span className="text-3xl font-extrabold tracking-tight text-navy">Peer</span><span className="text-3xl font-extrabold tracking-tight text-[#6a6ff0]">Up</span></p><p className="relative mt-1 text-center text-sm font-semibold text-subtle">Two peers. One rising curve.</p>
            </div>
            <div className="absolute -top-4 -left-4 rotate-[-6deg] rounded-2xl bg-ivory p-3 shadow-[var(--shadow-raised-lg)] sm:-left-10">
              <p className="text-[0.65rem] font-bold text-subtle uppercase">Mutual match</p>
              <p className="text-sm font-extrabold text-navy">Python ⇄ Java</p>
            </div>
            <div className="absolute -right-3 -bottom-5 rotate-[4deg] rounded-2xl bg-ivory p-3 shadow-[var(--shadow-raised-lg)] sm:-right-8">
              <Stars value={4.9} size={13} />
              <p className="mt-0.5 text-xs font-semibold text-ink">“Explained it so clearly!”</p>
            </div>
            <LoopArrow className="absolute -bottom-16 left-6 hidden h-16 w-28 sm:block" />
          </motion.div>
        </div>
      </section>

      {/* ---------------- stats ---------------- */}
      <section className="mx-auto mt-10 max-w-7xl px-5 sm:px-8">
        <div className="grid grid-cols-2 gap-4 rounded-[24px] bg-ivory p-6 shadow-[var(--shadow-raised)] md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <p className="text-3xl font-extrabold text-navy">{ready ? <Counter value={s.value} /> : "-"}</p>
              <p className="text-sm text-subtle">{s.label}</p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-center text-xs text-subtle">Live counts from this demo's data, including sample profiles.</p>
      </section>

      {/* ---------------- intro ---------------- */}
      <Section eyebrow="Why peer learning" title="The best explanation often comes from someone who just figured it out." sub="Seniors remember exactly where they got stuck. Classmates speak your language. PeerUp turns that into a structured, rated exchange.">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Users, t: "Learn across fields", d: "Engineering, medical, law, management, design. Discover students far outside your own classroom." },
            { icon: ShieldCheck, t: "Trust that's earned", d: "Ratings only come from completed sessions, and trust scores are explained, not invented." },
            { icon: GraduationCap, t: "Guidance from seniors", d: "Senior Mentors are verified by real teaching activity, not just by being in a higher year." },
          ].map((b) => (
            <Card key={b.t} hover>
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-soft text-teal-strong"><b.icon className="h-5 w-5" /></span>
              <h3 className="mt-4 font-bold text-navy">{b.t}</h3>
              <p className="mt-1 text-sm text-subtle">{b.d}</p>
            </Card>
          ))}
        </div>
      </Section>

      {/* ---------------- how it works ---------------- */}
      <Section id="how" eyebrow="How it works" title="Five steps from “I wish I knew this” to “I can teach this.”">
        <ol className="grid gap-4 md:grid-cols-5">
          {["Create your student profile.", "Add skills you can teach and skills you want to learn.", "Find students with matching skills.", "Connect and arrange learning sessions.", "Learn, teach and rate your experience."].map((t, i) => (
            <li key={t} className="relative rounded-[20px] bg-ivory p-5 shadow-[var(--shadow-raised)]">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-navy text-sm font-extrabold text-white shadow-[0_0_16px_2px_rgb(246_201_204/.9)]">{i + 1}</span>
              <p className="mt-3 text-sm font-semibold text-ink">{t}</p>
            </li>
          ))}
        </ol>
      </Section>

      {/* ---------------- exchange ---------------- */}
      <Section eyebrow="Skill exchange" title="A mutual match means you both walk away smarter." sub="We only call it mutual when it works both ways. One-way opportunities are shown separately.">
        <div className="relative grid items-center gap-6 md:grid-cols-[1fr_auto_1fr]">
          {[{ n: "Rahul", t: "Python", w: "Java", c: "#F2A33A" }, { n: "Priya", t: "Java", w: "Python", c: "#6C4CF1" }].map((p, i) => (
            <Card key={p.n} className={cn("text-center", i === 1 && "md:order-3")}>
              <span className="mx-auto block h-12 w-12 rounded-full" style={{ background: p.c }} />
              <p className="mt-3 text-lg font-extrabold text-navy">{p.n}</p>
              <p className="mt-2 text-sm text-subtle">Can teach <SkillChip>{p.t}</SkillChip></p>
              <p className="mt-2 text-sm text-subtle">Wants <SkillChip tone="teal">{p.w}</SkillChip></p>
            </Card>
          ))}
          <div className="relative flex flex-col items-center gap-2 md:order-2">
            <CurveArrow className="h-14 w-28" />
            <span className="rounded-full bg-navy px-4 py-2 text-sm font-bold text-white shadow-[0_0_24px_4px_rgb(246_201_204/.8)]">100% mutual match</span>
            <CurveArrow className="h-14 w-28 rotate-180" />
          </div>
        </div>
        <p className="mt-6 text-center text-sm text-subtle">A third student who teaches HTML and wants Java is <b>not</b> a mutual match for Rahul, because Rahul doesn't want HTML.</p>
      </Section>

      {/* ---------------- categories ---------------- */}
      <Section eyebrow="Popular categories" title="Whatever you study, someone can help you. And someone needs your help.">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {CATS.map((c) => (
            <Link key={c.name} href={`/explore?q=${encodeURIComponent(c.q)}`} className="group flex items-center gap-3 rounded-[18px] bg-ivory p-4 shadow-[var(--shadow-raised-sm)] transition-transform hover:-translate-y-0.5 hover:shadow-[var(--shadow-glow)]">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl neu-inset text-teal-strong group-hover:bg-blush-soft group-hover:text-blush-ink"><c.icon className="h-5 w-5" /></span>
              <span className="text-sm font-bold text-navy">{c.name}</span>
            </Link>
          ))}
        </div>
      </Section>

      {/* ---------------- featured skill cards ---------------- */}
      <Section eyebrow="Featured skill cards" title="Real skills, rated by real sessions." sub="Featured cards come from sample profiles in this demo. Every card is labelled.">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {featuredSkills.map(({ s, r, t2 }) => (
            <Card key={s.id + t2.name} hover className="flex flex-col">
              <div className="flex items-start justify-between"><div><p className="text-xs font-bold tracking-wide text-teal-strong uppercase">{t2.category}</p><h3 className="text-lg font-extrabold text-navy">{t2.name}</h3></div><SkillChip tone="teal">{t2.level}</SkillChip></div>
              <div className="mt-3"><Stars value={r.bySkill.find((b) => b.skill === t2.name)?.average ?? r.average} size={13} showValue count={r.bySkill.find((b) => b.skill === t2.name)?.count} /></div>
              <div className="mt-4 flex items-center gap-3">
                <Avatar name={s.name} src={s.avatar} size={36} className="ring-2" />
                <div className="min-w-0"><p className="flex items-center gap-2 truncate text-sm font-bold text-navy">{s.name} <SampleTag /></p><p className="truncate text-xs text-subtle">{s.college} · {yearLabel(s.year)}</p></div>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      {/* ---------------- top teachers + mentors ---------------- */}
      <Section eyebrow="Community" title="Top-rated peer teachers and senior mentors">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <h3 className="font-bold text-navy">Top-rated peer teachers</h3>
            <ul className="mt-4 divide-y divide-line">
              {topTeachers.map(({ s, r, t }, i) => (
                <li key={s.id} className="flex items-center gap-3 py-3">
                  <span className="w-6 text-sm font-extrabold text-muted">#{i + 1}</span>
                  <Avatar name={s.name} src={s.avatar} size={38} className="ring-2" />
                  <span className="min-w-0 flex-1"><span className="block truncate font-bold text-navy">{s.name}</span><span className="block truncate text-xs text-subtle">{s.teach.map((x) => x.name).join(", ")}</span></span>
                  <span className="text-right"><Stars value={r.average} size={12} showValue /><span className="block text-xs text-subtle">Trust {t.total}</span></span>
                </li>
              ))}
            </ul>
          </Card>
          <Card>
            <h3 className="font-bold text-navy">Top senior mentors</h3>
            <ul className="mt-4 space-y-3">
              {mentors.map(({ s, r }) => (
                <li key={s.id} className="flex items-center gap-3 neu-inset rounded-2xl p-3">
                  <Avatar name={s.name} src={s.avatar} size={44} className="ring-2" />
                  <span className="min-w-0 flex-1"><span className="block truncate font-bold text-navy">{s.name}</span><span className="block truncate text-xs text-subtle">{s.field} · {s.department} · {yearLabel(s.year)}</span></span>
                  <span className="hidden sm:block"><MentorBadge small /></span>
                  <Stars value={r.average} size={12} showValue />
                </li>
              ))}
            </ul>
            <Button href="/mentors" variant="secondary" size="sm" className="mt-4">Browse mentors <ArrowRight className="h-4 w-4" /></Button>
          </Card>
        </div>
      </Section>

      {/* ---------------- benefits ---------------- */}
      <Section eyebrow="Benefits" title="Why students stick with peer learning">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { i: BookOpen, t: "Learn faster", d: "Explanations from someone who just got it." },
            { i: BadgeCheck, t: "Prove your skills", d: "Ratings and verified certificates build a real record." },
            { i: MessageCircle, t: "Grow your network", d: "Meet students from other colleges and fields." },
            { i: Scale, t: "Fair by design", d: "No self-ratings, no fake completions, no pay-to-rank." },
          ].map((b) => (
            <div key={b.t} className="neu p-5">
              <b.i className="h-6 w-6 text-teal-strong" />
              <p className="mt-3 font-bold text-navy">{b.t}</p>
              <p className="text-sm text-subtle">{b.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* ---------------- testimonials ---------------- */}
      <Section eyebrow="What learners say" title="Feedback from completed sessions" sub="These quotes come from sample reviews in the demo data, not from real students.">
        <div className="grid gap-6 md:grid-cols-3">
          {quotes.map((q) => {
            const by = db.students.find((s) => s.id === q.reviewerId);
            return (
              <Card key={q.id}>
                <Stars value={q.stars} size={14} />
                <p className="mt-3 text-ink">“{q.comment}”</p>
                <p className="mt-4 flex items-center gap-2 text-sm font-semibold text-subtle">{by?.name} · {q.skill} <SampleTag /></p>
              </Card>
            );
          })}
        </div>
      </Section>

      {/* ---------------- faq ---------------- */}
      <Section eyebrow="FAQ" title="Questions, answered">
        <div className="divide-y divide-line rounded-[20px] bg-ivory shadow-[var(--shadow-raised)]">
          {FAQ.map(([q, a], i) => (
            <div key={q}>
              <button onClick={() => setFaq(faq === i ? -1 : i)} className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-bold text-navy" aria-expanded={faq === i}>
                {q}<span className={cn("text-xl text-teal-strong transition-transform", faq === i && "rotate-45")}>+</span>
              </button>
              {faq === i && <p className="px-6 pb-5 text-subtle">{a}</p>}
            </div>
          ))}
        </div>
        <Link href="/faq" className="mt-4 inline-block text-sm font-bold text-teal-strong hover:underline">All questions →</Link>
      </Section>

      {/* ---------------- CTA ---------------- */}
      <section className="mx-auto mt-24 max-w-7xl px-5 sm:px-8">
        <div className="relative overflow-hidden rounded-[32px] bg-navy px-8 py-14 text-center text-white sm:px-16">
          <span aria-hidden className="absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-[#f6c9cc]/30 shadow-[0_0_120px_60px_rgb(246_201_204/.28)]" />
                    <h2 className="relative mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">Learn together. <span className="text-glow text-[#f9d9cf]">Grow together.</span></h2>
          <p className="relative mx-auto mt-3 max-w-xl text-white/75">Create your profile in two minutes and see your mutual matches straight away.</p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Button href="/signup" size="lg" variant="accent">Create free account</Button>
            <Button href="/login" size="lg" className="bg-white text-navy hover:bg-white/90">Try the demo</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
