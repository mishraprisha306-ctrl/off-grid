export type Level = "Beginner" | "Intermediate" | "Advanced";
export type Availability = "online" | "offline" | "both";
export type SessionMode = "Online" | "Offline";
export type SessionFormat = "One-to-One" | "Group";
export type SessionStatus = "Pending" | "Accepted" | "Rejected" | "Completed" | "Cancelled";
export type Role = "student" | "admin";

export const FIELDS = ["Engineering", "Medical", "Management", "Law", "Science", "Commerce", "Arts", "Design", "Other"] as const;
export type Field = (typeof FIELDS)[number];

export const SKILL_CATEGORIES = [
  "Programming", "Web Development", "Design", "Mathematics", "Science", "Communication", "Business & Management",
  "Legal Studies", "Medical & Health", "Finance", "Data Science", "Video Editing", "Other",
] as const;
export type SkillCategory = (typeof SKILL_CATEGORIES)[number];

export const MENTOR_CATEGORIES = ["Coding", "Academic", "Project", "Career Guidance", "Design", "Communication", "Subject-specific"] as const;

export const LEVELS: Level[] = ["Beginner", "Intermediate", "Advanced"];
export const MODES: SessionMode[] = ["Online", "Offline"];
export const FORMATS: SessionFormat[] = ["One-to-One", "Group"];
export const YEARS = [1, 2, 3, 4, 5, 0]; // 0 = Other
export const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;

export interface TeachSkill {
  name: string;
  category: SkillCategory;
  level: Level;
  description?: string;
  mode?: Availability;
  link?: string;
}
export interface LearnSkill {
  name: string;
  category: SkillCategory;
  level?: Level; // current level in the skill they want to learn
}
export interface Certificate {
  id: string;
  title: string;
  url: string;
  /** "self" = only claimed; "evidence" = link/file attached; "verified" = admin checked */
  status: "self" | "evidence" | "verified";
}
export interface Slot {
  day: (typeof DAYS)[number];
  from: string; // HH:mm
  to: string;
}
export interface Privacy {
  showEmail: boolean;
  showCollege: boolean;
  showStudentId: boolean;
  showLinks: boolean;
  messagesFrom: "everyone" | "connections";
}

export interface Student {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: Role;
  sample: boolean; // fictional demo profile, always labelled in the UI
  avatar?: string; // data URL (demo) or storage URL (Supabase)
  college: string;
  field: Field;
  department: string;
  year: number;
  studentId?: string;
  bio: string;
  interests: string[];
  teach: TeachSkill[];
  learn: LearnSkill[];
  mode: Availability;
  formats: SessionFormat[];
  slots: Slot[];
  links: { github?: string; linkedin?: string; portfolio?: string };
  certificates: Certificate[];
  mentorCategories: string[];
  mentorStatus: "none" | "pending" | "approved" | "rejected";
  mentorAvailable: boolean;
  privacy: Privacy;
  blocked: string[];
  suspended: boolean;
  emailVerified: boolean;
  joinedAt: string;
  onboarded: boolean;
}

export interface SessionResource { id: string; title: string; url: string; addedBy: string }

export interface Session {
  id: string;
  teacherId: string;
  learnerId: string;
  /** extra learners in a group session */
  groupIds: string[];
  requesterId: string;
  awaitingId: string;
  skill: string;
  date: string;
  time: string;
  duration: number;
  mode: SessionMode;
  format: SessionFormat;
  mentorship: boolean;
  objective: string;
  message?: string;
  meetingLink?: string;
  location?: string;
  notes?: string;
  resources: SessionResource[];
  status: SessionStatus;
  note?: string;
  wasAccepted: boolean;
  completedBy: string[]; // both participants confirm
  createdAt: string;
  updatedAt: string;
}

export interface RatingSet {
  teaching: number;
  knowledge: number;
  communication: number;
  experience: number;
}
export interface Review {
  id: string;
  sessionId: string;
  reviewerId: string;
  revieweeId: string;
  skill: string;
  stars: number; // overall 1–5
  ratings: RatingSet;
  qualities: string[];
  comment: string;
  helpful: string[];
  mentorship: boolean;
  createdAt: string;
  editedAt?: string;
}
export interface LearnerFeedback {
  id: string;
  sessionId: string;
  teacherId: string;
  learnerId: string;
  progress?: number;
  comment: string;
  suggestions: string;
  private: boolean;
  createdAt: string;
}
export interface Connection {
  id: string;
  fromId: string;
  toId: string;
  status: "Pending" | "Accepted";
  createdAt: string;
}
export interface Message {
  id: string;
  fromId: string;
  toId: string;
  text: string;
  read: boolean;
  createdAt: string;
}
export interface Notification {
  id: string;
  userId: string;
  kind: "connection" | "session" | "review" | "match" | "mentor" | "message" | "system";
  text: string;
  href: string;
  read: boolean;
  createdAt: string;
  connectionId?: string;
}
export interface Report {
  id: string;
  reporterId: string;
  targetType: "user" | "review" | "message";
  targetId: string;
  reason: string;
  status: "open" | "resolved" | "dismissed";
  createdAt: string;
}
export interface SupportRequest {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: "open" | "closed";
  createdAt: string;
}
export interface AuditLog { id: string; adminId: string; action: string; createdAt: string }
export interface Resource {
  id: string;
  ownerId: string;
  title: string;
  url: string;
  kind: "PDF Notes" | "Link" | "Documentation" | "Video Tutorial" | "Practice Exercise" | "Project Reference";
  skill: string;
  createdAt: string;
}
export interface Progress {
  id: string;
  userId: string;
  skill: string;
  percent: number;
  goal: string;
  notes: string;
  milestones: { text: string; done: boolean }[];
  completed: boolean;
  updatedAt: string;
}
export interface ChallengeJoin { id: string; userId: string; challengeId: string; startedAt: string; daysDone: number[] }

export interface AppSettings {
  mentorMinYear: number;
  mentorMinSessions: number;
  mentorMinRating: number;
  skillCategories: string[];
  notify: { sessions: boolean; connections: boolean; reviews: boolean; messages: boolean; matches: boolean };
}

export interface DB {
  version: number;
  students: Student[];
  sessions: Session[];
  reviews: Review[];
  feedback: LearnerFeedback[];
  connections: Connection[];
  messages: Message[];
  notifications: Notification[];
  reports: Report[];
  support: SupportRequest[];
  audit: AuditLog[];
  resources: Resource[];
  progress: Progress[];
  challenges: ChallengeJoin[];
  settings: AppSettings;
}
