"use client";
import { useEffect, useState } from "react";
import { PeerUpMark } from "./logo";

const KEY = "peerup.intro.seen";

/** Opening shot: P rises → peers pop in → ribbon draws up → arrow + sparkle → wordmark → tagline → app opens. */
export function Intro() {
  const [show, setShow] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem(KEY) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    sessionStorage.setItem(KEY, "1");
    setShow(true);
    document.documentElement.style.overflow = "hidden";
    const t1 = setTimeout(() => setLeaving(true), 3300);
    const t2 = setTimeout(() => { setShow(false); document.documentElement.style.overflow = ""; }, 4000);
    return () => { clearTimeout(t1); clearTimeout(t2); document.documentElement.style.overflow = ""; };
  }, []);

  if (!show) return null;
  const skip = () => {
    setLeaving(true);
    setTimeout(() => { setShow(false); document.documentElement.style.overflow = ""; }, 500);
  };
  const word = "PeerUp".split("");
  return (
    <div className={`intro ${leaving ? "intro-out" : ""}`} role="presentation">
      <div className="intro-glow" />
      <div className="relative flex flex-col items-center">
        <div className="intro-mark-wrap">
          <PeerUpMark className="intro-mark" animated />
        </div>
        <p className="intro-word" aria-label="PeerUp">
          {word.map((ch, i) => <span key={i} className={i >= 4 ? "intro-up" : undefined} style={{ animationDelay: `${1.75 + i * 0.06}s` }}>{ch}</span>)}
        </p>
        <p className="intro-tag"><span className="intro-line" />Learn Together. Grow Together.<span className="intro-line intro-line-r" /></p>
      </div>
      <button onClick={skip} className="intro-skip">Skip intro</button>
    </div>
  );
}
