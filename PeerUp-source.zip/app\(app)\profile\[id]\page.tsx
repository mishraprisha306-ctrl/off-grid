"use client";
import { UserX } from "lucide-react";
import { use } from "react";
import { ProfileView } from "@/components/profile-view";
import { Button, Card, EmptyState } from "@/components/ui";
import { useStore } from "@/lib/store";

export default function StudentProfile({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { byId } = useStore();
  const s = byId(id);
  if (!s) return <Card><EmptyState icon={UserX} title="Student not found" text="This profile may have been removed." action={<Button href="/discover">Discover students</Button>} /></Card>;
  return <ProfileView student={s} />;
}
