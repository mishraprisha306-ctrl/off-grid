"use client";
import { BookOpen, ChevronDown, Flag, LifeBuoy, Lock, Shield, Users } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useToast } from "@/components/toast";
import { Button, Card, Field, Input, PageHeader, Select, Textarea, cn } from "@/components/ui";
import { FAQS } from "@/lib/content";
import { useStore } from "@/lib/store";

const GUIDE = ["Complete your profile and add skills you teach and want to learn.", "Open Mutual Matches to see students whose skills complement yours.", "Connect, then request a session with a date, time, mode and objective.", "The other student accepts, rejects or proposes a new time.", "Meet online (external link) or offline in a safe place, using the Learning Room for notes.", "After the start time, both of you confirm completion.", "Learners rate the teacher; the teacher can leave private learner feedback.", "Ratings, trust scores and the leaderboard update automatically."];

export default function Help() {
  const { me, submitSupport } = useStore();
  const toast = useToast();
  const [open, setOpen] = useState(0);
  const [f, setF] = useState({ subject: "Report a problem", message: "" });
  const [err, setErr] = useState("");
  return (
    <div className="max-w-4xl">
      <PageHeader title="Help & Support" subtitle="Guides, answers and a direct line to the team." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[{ i: Users, t: "Community Guidelines", h: "/guidelines" }, { i: Shield, t: "Safety Guidelines", h: "/safety" }, { i: Lock, t: "Privacy information", h: "/privacy" }, { i: Flag, t: "Report a user", h: "/connections" }].map((x) => (
          <Link key={x.t} href={x.h} className="neu glow-hover flex items-center gap-3 p-4 hover:-translate-y-0.5"><x.i className="h-5 w-5 text-teal-strong" /><span className="text-sm font-bold text-navy">{x.t}</span></Link>
        ))}
      </div>
      <Card className="mt-6">
        <h2 className="flex items-center gap-2 font-bold text-navy"><BookOpen className="h-5 w-5 text-teal-strong" /> How to use PeerUp</h2>
        <ol className="mt-4 space-y-2">{GUIDE.map((g, i) => <li key={g} className="flex gap-3 text-sm"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-navy text-xs font-bold text-white">{i + 1}</span>{g}</li>)}</ol>
        <p className="mt-4 text-sm text-subtle">To report a specific user, open their profile and choose ⋯ → Report profile. Reviews and messages have their own Report buttons.</p>
      </Card>
      <h2 className="mt-8 mb-3 font-bold text-navy">Frequently asked questions</h2>
      <Card className="divide-y divide-line p-2">
        {FAQS.map(([q, a], i) => (
          <div key={q}>
            <button onClick={() => setOpen(open === i ? -1 : i)} className="flex w-full items-center justify-between gap-4 px-4 py-4 text-left font-semibold text-navy" aria-expanded={open === i}>{q}<ChevronDown className={cn("h-4 w-4 shrink-0 transition-transform", open === i && "rotate-180")} /></button>
            {open === i && <p className="px-4 pb-4 text-sm text-subtle">{a}</p>}
          </div>
        ))}
      </Card>
      <Card className="mt-8">
        <h2 className="flex items-center gap-2 font-bold text-navy"><LifeBuoy className="h-5 w-5 text-teal-strong" /> Contact support · report a problem</h2>
        <form className="mt-4 space-y-4" onSubmit={(e) => { e.preventDefault(); const r = submitSupport({ name: me?.name ?? "", email: me?.email ?? "", subject: f.subject, message: f.message }); if (!r.ok) return setErr(r.error); setErr(""); setF({ ...f, message: "" }); toast("Sent to the support team. They'll reply by email."); }}>
          <Field label="Topic" htmlFor="h-s"><Select id="h-s" value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })}>{["Report a problem", "Account help", "Session issue", "Safety concern", "Feature idea"].map((x) => <option key={x}>{x}</option>)}</Select></Field>
          <Field label="Message" htmlFor="h-m"><Textarea id="h-m" rows={4} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></Field>
          <Field label="Reply to" htmlFor="h-e"><Input id="h-e" value={me?.email ?? ""} disabled /></Field>
          {err && <p className="text-sm font-semibold text-rose" role="alert">{err}</p>}
          <Button type="submit">Send to support</Button>
        </form>
      </Card>
    </div>
  );
}
