import type { DB, Field, LearnSkill, Level, Review, Session, SessionFormat, SessionMode, SkillCategory, Student, TeachSkill } from "./types";
import { DAYS } from "./types";

/** sha256("pwr::demo1234"), every seeded sample account uses password demo1234 */
export const DEMO_HASH = "951c980b3edae9d80120b30536d58473e6d6418e5dd9601d75dcbdc0c0db6fc2";
export const DEMO_PASSWORD = "demo1234";
export const DEMO_EMAIL = "rahul.sharma@kiit.edu.in";
/** one-tap demo accounts shown on the sign-in page (mock auth until Supabase is connected) */
/** the PeerUp team, shown first on sign-in and get-started */
export const TEAM_ACCOUNTS = ["u-prisha", "u-anushka", "u-tanishka"];
export const DEMO_ACCOUNTS = ["u-preesha", "u-natasha", "u-aarav", "u-kabir", "u-rahul"];
export const ADMIN_EMAIL = "admin@peerup.edu";
export const DB_VERSION = 6;

const CAT: Record<string, SkillCategory> = {
  Python: "Programming", "C Programming": "Programming", Java: "Programming", "C++": "Programming",
  JavaScript: "Web Development", React: "Web Development", HTML: "Web Development", CSS: "Web Development", "Web Development": "Web Development",
  "UI/UX Design": "Design", Figma: "Design", "Graphic Design": "Design", "Data Science": "Data Science", SQL: "Data Science",
  "Machine Learning": "Data Science", Calculus: "Mathematics", "Linear Algebra": "Mathematics", Statistics: "Mathematics",
  "Public Speaking": "Communication", "Business English": "Communication", "Digital Marketing": "Business & Management",
  "Business Strategy": "Business & Management", Excel: "Finance", Accounting: "Finance", "Video Editing": "Video Editing",
  Photography: "Other", AutoCAD: "Other", Arduino: "Other", Anatomy: "Medical & Health", Biology: "Science", Chemistry: "Science",
  "Constitutional Law": "Legal Studies", "Legal Writing": "Legal Studies", "Moot Court Prep": "Legal Studies",
};
const t = (name: string, level: Level, description = "", mode: TeachSkill["mode"] = "both"): TeachSkill => ({ name, level, category: CAT[name] ?? "Other", description, mode });
const l = (name: string, level?: Level): LearnSkill => ({ name, category: CAT[name] ?? "Other", level });

interface Raw {
  id: string; name: string; year: number; field: Field; department: string; college: string;
  teach: TeachSkill[]; learn: LearnSkill[]; rating: number[]; bio: string; mode: Student["mode"];
  formats: SessionFormat[]; interests: string[]; mentorCats?: string[]; links?: Student["links"];
  /** project team members: real people, not fictional samples */
  team?: { roll: string; email: string };
}
const KIIT = "Kalinga Institute of Technology";
const DU = "Delhi University";
const NLU = "National Law University";
const AIIMS = "Regional Medical College";
const NID = "National Institute of Design";

/* Ratings arrays are the actual star values seeded for each teacher, averages are computed, never stored. */
const RAW: Raw[] = [
  // ---- PeerUp project team (one-tap demo sign-in until real auth is connected) ----
  { id: "u-prisha", name: "Prisha Mishra", year: 2, field: "Engineering", department: "CSE · Section E", college: KIIT, team: { roll: "348", email: "prisha.mishra@peerup.team" },
    teach: [t("UI/UX Design", "Advanced", "User flows, wireframes and clean Figma prototypes."), t("Figma", "Advanced"), t("Python", "Intermediate")],
    learn: [l("React", "Beginner"), l("Data Science", "Beginner")], rating: [5, 5, 4, 5],
    bio: "CSE, Section E. Part of the PeerUp team. I enjoy turning ideas into interfaces people actually like using.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Product design", "Hackathons"] },
  { id: "u-anushka", name: "Anushka Agrawal", year: 2, field: "Engineering", department: "CSE · Section B", college: KIIT, team: { roll: "94", email: "anushka.agrawal@peerup.team" },
    teach: [t("Java", "Advanced", "OOP, collections and DSA in Java."), t("C Programming", "Intermediate"), t("Public Speaking", "Intermediate")],
    learn: [l("UI/UX Design", "Beginner"), l("Machine Learning", "Beginner")], rating: [5, 4, 5, 5],
    bio: "CSE, Section B. Part of the PeerUp team. I like explaining code with small, real examples.", mode: "both", formats: ["One-to-One"], interests: ["DSA", "Debate"] },
  { id: "u-tanishka", name: "Tanishka Singh", year: 2, field: "Engineering", department: "CSE · Section G", college: KIIT, team: { roll: "501", email: "tanishka.singh@peerup.team" },
    teach: [t("React", "Advanced", "Components, hooks and building real pages."), t("JavaScript", "Advanced"), t("HTML", "Advanced")],
    learn: [l("Java", "Beginner"), l("Figma", "Beginner")], rating: [5, 5, 5, 4],
    bio: "CSE, Section G. Part of the PeerUp team. Front-end is my happy place.", mode: "online", formats: ["One-to-One", "Group"], interests: ["Web", "Open source"] },
  { id: "u-rahul", name: "Rahul Sharma", year: 2, field: "Engineering", department: "CSE", college: KIIT,
    teach: [t("Python", "Advanced", "From basics to OOP and small automation scripts."), t("C Programming", "Intermediate", "Pointers, memory and data structures in C."), t("HTML", "Intermediate")],
    learn: [l("Java", "Beginner"), l("UI/UX Design", "Beginner")], rating: [5, 5, 5, 4, 5],
    bio: "Second-year CSE student who loves writing clean Python and explaining pointers until they click.", mode: "both", formats: ["One-to-One"], interests: ["Open source", "Automation"],
    links: { github: "https://github.com/" } },
  { id: "u-priya", name: "Priya Verma", year: 3, field: "Engineering", department: "CSE", college: KIIT,
    teach: [t("Java", "Advanced", "OOP through small projects, never slides."), t("Web Development", "Advanced")], learn: [l("Python", "Beginner"), l("UI/UX Design")],
    rating: [5, 5, 5, 5, 5, 5, 4, 5, 5], bio: "Java backend intern last summer. I teach OOP through small projects.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Backend", "Hackathons"], mentorCats: ["Coding", "Project"] },
  { id: "u-aman", name: "Aman Gupta", year: 4, field: "Engineering", department: "IT", college: KIIT,
    teach: [t("React", "Advanced"), t("JavaScript", "Advanced"), t("Web Development", "Advanced")], learn: [l("Data Science")],
    rating: [5, 5, 4, 5, 5, 4, 5, 5, 4, 5, 5, 4], bio: "Final-year IT, freelance front-end developer. Happy to review your portfolio code.", mode: "online", formats: ["One-to-One", "Group"], interests: ["Freelancing"], mentorCats: ["Coding", "Career Guidance"] },
  { id: "u-sneha", name: "Sneha Patel", year: 2, field: "Design", department: "Communication Design", college: NID,
    teach: [t("Figma", "Advanced"), t("Graphic Design", "Intermediate")], learn: [l("HTML"), l("CSS")], rating: [5, 4, 5, 5, 4, 5],
    bio: "Communication design student. I want to build the interfaces I design.", mode: "offline", formats: ["One-to-One", "Group"], interests: ["Branding", "Posters"] },
  { id: "u-arjun", name: "Arjun Mehta", year: 3, field: "Engineering", department: "CSE", college: DU,
    teach: [t("Data Science", "Advanced"), t("Python", "Advanced")], learn: [l("Graphic Design")], rating: [5, 5, 4, 5, 5, 5, 4, 5],
    bio: "Kaggle notebooks, pandas and plotting. Ask me about your first ML project.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Kaggle"], mentorCats: ["Project", "Coding"] },
  { id: "u-neha", name: "Neha Singh", year: 1, field: "Engineering", department: "CSE", college: KIIT,
    teach: [t("HTML", "Advanced", "Built three websites in school."), t("CSS", "Advanced")], learn: [l("Python", "Beginner")], rating: [5, 4, 5],
    bio: "First-year, but I've been building websites since school.", mode: "online", formats: ["One-to-One"], interests: ["Web"] },
  { id: "u-kavya", name: "Kavya Iyer", year: 4, field: "Design", department: "Product Design", college: NID,
    teach: [t("UI/UX Design", "Advanced"), t("Figma", "Advanced")], learn: [l("Python"), l("Public Speaking")], rating: [5, 5, 5, 5, 5, 4, 5, 5, 5, 5, 5, 5, 4, 5],
    bio: "Product design intern at a fintech. I run portfolio critique circles on Fridays.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Fintech", "Research"], mentorCats: ["Design", "Career Guidance"] },
  { id: "u-rohan", name: "Rohan Das", year: 3, field: "Engineering", department: "ECE", college: KIIT,
    teach: [t("Arduino", "Advanced"), t("C Programming", "Advanced")], learn: [l("Machine Learning"), l("Java")], rating: [4, 5, 4, 5, 4],
    bio: "Robotics club lead. Embedded C and hardware prototyping.", mode: "offline", formats: ["One-to-One", "Group"], interests: ["Robotics"] },
  { id: "u-ishita", name: "Ishita Roy", year: 2, field: "Management", department: "BBA", college: DU,
    teach: [t("Digital Marketing", "Advanced"), t("Public Speaking", "Intermediate")], learn: [l("Excel"), l("Python")], rating: [5, 4, 5, 5],
    bio: "I run the college fest's social channels. Let's make your pitch land.", mode: "both", formats: ["One-to-One"], interests: ["Marketing", "Debate"] },
  { id: "u-vikram", name: "Vikram Nair", year: 4, field: "Science", department: "Mathematics", college: DU,
    teach: [t("Calculus", "Advanced"), t("Linear Algebra", "Advanced"), t("Statistics", "Advanced")], learn: [l("Video Editing")], rating: [5, 5, 4, 5, 5, 5, 4, 5, 5, 5, 4],
    bio: "Maths honours. I've tutored first-years through every Calculus end-sem since 2024.", mode: "both", formats: ["Group", "One-to-One"], interests: ["Teaching"], mentorCats: ["Academic", "Subject-specific"] },
  { id: "u-ananya", name: "Ananya Bose", year: 3, field: "Engineering", department: "IT", college: KIIT,
    teach: [t("SQL", "Advanced"), t("Java", "Intermediate")], learn: [l("React"), l("Photography")], rating: [5, 4, 4, 5, 5, 4],
    bio: "Databases are my thing. Normalisation explained with canteen menus.", mode: "online", formats: ["One-to-One"], interests: ["Databases"] },
  { id: "u-karan", name: "Karan Malhotra", year: 1, field: "Engineering", department: "Mechanical", college: KIIT,
    teach: [t("AutoCAD", "Intermediate"), t("Photography", "Advanced")], learn: [l("Python"), l("C Programming")], rating: [],
    bio: "New here! I shoot for the photography society and draft in AutoCAD.", mode: "offline", formats: ["One-to-One"], interests: ["Photography"] },
  { id: "u-meera", name: "Meera Joshi", year: 2, field: "Commerce", department: "B.Com", college: DU,
    teach: [t("Excel", "Advanced"), t("Accounting", "Intermediate")], learn: [l("Digital Marketing"), l("Figma")], rating: [5, 5, 4, 5],
    bio: "Finance club treasurer. Spreadsheets that don't break.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Finance"] },
  { id: "u-dev", name: "Dev Khanna", year: 3, field: "Engineering", department: "CSE", college: DU,
    teach: [t("Machine Learning", "Advanced"), t("Video Editing", "Intermediate")], learn: [l("Java"), l("Calculus")], rating: [4, 5, 4],
    bio: "ML research assistant, part-time YouTube editor.", mode: "online", formats: ["One-to-One", "Group"], interests: ["Research", "YouTube"] },
  { id: "u-aditi", name: "Aditi Rao", year: 4, field: "Law", department: "BA LLB", college: NLU,
    teach: [t("Constitutional Law", "Advanced"), t("Legal Writing", "Advanced"), t("Moot Court Prep", "Advanced")], learn: [l("Public Speaking"), l("Excel")], rating: [5, 5, 5, 4, 5, 5],
    bio: "Two-time moot court finalist. Legal drafting doesn't have to be scary.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Moots", "Policy"], mentorCats: ["Academic", "Communication"] },
  { id: "u-sameer", name: "Sameer Khan", year: 5, field: "Medical", department: "MBBS", college: AIIMS,
    teach: [t("Anatomy", "Advanced"), t("Biology", "Advanced")], learn: [l("Python"), l("Statistics")], rating: [5, 5, 4, 5, 5],
    bio: "Final-year MBBS. Anatomy with mnemonics that actually stick.", mode: "offline", formats: ["Group"], interests: ["Medicine", "Biostatistics"], mentorCats: ["Academic", "Subject-specific"] },
  { id: "u-tara", name: "Tara Menon", year: 2, field: "Science", department: "Chemistry", college: DU,
    teach: [t("Chemistry", "Advanced"), t("Biology", "Intermediate")], learn: [l("Statistics"), l("Python")], rating: [5, 4, 5],
    bio: "Organic chemistry is a story, not a list of reactions.", mode: "both", formats: ["One-to-One"], interests: ["Lab work"] },
  { id: "u-preesha", name: "Preesha Kapoor", year: 2, field: "Design", department: "Communication Design", college: NID,
    teach: [t("UI/UX Design", "Advanced", "Wireframes to clickable Figma prototypes."), t("Figma", "Advanced"), t("Public Speaking", "Intermediate")],
    learn: [l("Python", "Beginner"), l("HTML", "Beginner")], rating: [5, 5, 4, 5],
    bio: "Design student who loves turning messy ideas into clean screens. Learning to code what I design.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Product design", "Illustration"] },
  { id: "u-natasha", name: "Natasha Fernandes", year: 3, field: "Management", department: "BBA", college: DU,
    teach: [t("Digital Marketing", "Advanced", "Instagram growth and content calendars."), t("Excel", "Advanced"), t("Business English", "Intermediate")],
    learn: [l("Graphic Design"), l("Data Science")], rating: [5, 4, 5, 5, 5],
    bio: "Run the marketing for two campus startups. Happy to help with pitches and spreadsheets.", mode: "online", formats: ["One-to-One"], interests: ["Startups", "Branding"] },
  { id: "u-aarav", name: "Aarav Malhotra", year: 3, field: "Engineering", department: "CSE", college: KIIT,
    teach: [t("Python", "Advanced", "DSA in Python and competitive programming."), t("Java", "Intermediate"), t("Data Science", "Intermediate")],
    learn: [l("UI/UX Design"), l("Public Speaking")], rating: [5, 5, 5, 4, 5, 4],
    bio: "Competitive programmer, ICPC regionalist. I explain recursion with drawings.", mode: "both", formats: ["One-to-One", "Group"], interests: ["Competitive coding"] },
  { id: "u-kabir", name: "Kabir Singh", year: 2, field: "Engineering", department: "ECE", college: KIIT,
    teach: [t("HTML", "Advanced"), t("CSS", "Advanced"), t("Video Editing", "Intermediate", "Premiere Pro and CapCut for reels.")],
    learn: [l("Excel"), l("Digital Marketing"), l("Python")], rating: [4, 5, 4],
    bio: "Front-end hobbyist and the college fest's video editor.", mode: "offline", formats: ["One-to-One"], interests: ["Video", "Web"] },
];

const COMMENTS = [
  "Explained it with examples from our own syllabus. Finally makes sense.",
  "Patient and well prepared. Shared notes after the session too.",
  "Great pace. We built a small project instead of just theory.",
  "Clear explanations, answered every doubt without rushing.",
  "Very practical. I could apply it in my lab the next day.",
  "Good session overall, would have liked a bit more practice time.",
  "Knows the subject deeply and makes it approachable.",
];
const QUAL = ["Clear explanations", "Patient", "Well prepared", "Practical examples", "Punctual", "Encouraging"];

const iso = (d: Date) => d.toISOString();
const ymd = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const daysFrom = (n: number, hour = 17) => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  d.setHours(hour, 0, 0, 0);
  return d;
};
const cats = (stars: number) => {
  const c = { teaching: stars, knowledge: Math.min(5, stars + 1), communication: stars, experience: stars };
  return c;
};

export function blankStudent(p: Partial<Student> & Pick<Student, "id" | "name" | "email" | "passwordHash">): Student {
  return {
    role: "student", sample: false, college: "", field: "Engineering", department: "", year: 1, bio: "", interests: [], teach: [], learn: [],
    mode: "both", formats: ["One-to-One"], slots: [], links: {}, certificates: [], mentorCategories: [], mentorStatus: "none", mentorAvailable: true,
    privacy: { showEmail: false, showCollege: true, showStudentId: false, showLinks: true, messagesFrom: "connections" },
    blocked: [], suspended: false, emailVerified: false, joinedAt: new Date().toISOString(), onboarded: false, ...p,
  };
}

export function buildSeed(): DB {
  const students: Student[] = RAW.map((r, idx) => blankStudent({
    id: r.id, name: r.name, passwordHash: DEMO_HASH, sample: !r.team, emailVerified: true, onboarded: true, studentId: r.team?.roll,
    email: r.team ? r.team.email : r.id === "u-rahul" ? DEMO_EMAIL : `${r.name.split(" ")[0].toLowerCase()}.${r.name.split(" ")[1].toLowerCase()}@sample.peerup.edu`,
    college: r.college, field: r.field, department: r.department, year: r.year, bio: r.bio, interests: r.interests, teach: r.teach, learn: r.learn,
    mode: r.mode, formats: r.formats, links: r.links ?? {}, mentorCategories: r.mentorCats ?? [],
    slots: [{ day: DAYS[idx % 5], from: "17:00", to: "19:00" }, { day: "Sat", from: "10:00", to: "13:00" }],
    certificates: idx % 4 === 1 ? [{ id: `cert-${idx}`, title: `${r.teach[0].name} course certificate`, url: "https://example.org/certificate", status: idx % 8 === 1 ? "verified" : "evidence" }] : [],
    joinedAt: iso(daysFrom(-220 + idx * 9)),
  }));
  students.push(blankStudent({ id: "u-admin", name: "Platform Admin", email: ADMIN_EMAIL, passwordHash: DEMO_HASH, role: "admin", sample: true, emailVerified: true, onboarded: true, college: "PeerUp", department: "Operations", year: 0 }));

  const sessions: Session[] = [];
  const reviews: Review[] = [];
  let sid = 0;
  const base = (p: Partial<Session>): Session => ({
    id: "", teacherId: "", learnerId: "", groupIds: [], requesterId: "", awaitingId: "", skill: "", date: "", time: "17:00", duration: 60,
    mode: "Online", format: "One-to-One", mentorship: false, objective: "", resources: [], status: "Pending", wasAccepted: false, completedBy: [],
    createdAt: iso(new Date()), updatedAt: iso(new Date()), ...p,
  });

  for (const r of RAW) {
    const pool = RAW.filter((o) => o.id !== r.id && o.id !== "u-rahul");
    r.rating.forEach((stars, k) => {
      const learner = pool[(k * 3 + r.name.length) % pool.length];
      const skill = r.teach[k % r.teach.length].name;
      const when = daysFrom(-3 - k * 5 - (r.year % 3), 15 + (k % 4));
      const mode: SessionMode = r.mode === "offline" ? "Offline" : r.mode === "online" ? "Online" : k % 2 ? "Offline" : "Online";
      const id = `s-seed-${++sid}`;
      const mentorship = !!r.mentorCats && k % 3 === 0;
      sessions.push(base({ id, teacherId: r.id, learnerId: learner.id, requesterId: learner.id, awaitingId: r.id, skill, date: ymd(when), time: `${String(when.getHours()).padStart(2, "0")}:00`,
        mode, format: r.formats[k % r.formats.length], mentorship, objective: `Get comfortable with ${skill} fundamentals`, status: "Completed", wasAccepted: true,
        completedBy: [r.id, learner.id], location: mode === "Offline" ? "Central Library, Group Study Room 2" : undefined, meetingLink: mode === "Online" ? "https://meet.google.com/" : undefined,
        createdAt: iso(daysFrom(-8 - k * 5)), updatedAt: iso(when) }));
      reviews.push({ id: `r-seed-${sid}`, sessionId: id, reviewerId: learner.id, revieweeId: r.id, skill, stars, ratings: cats(stars), mentorship,
        qualities: [QUAL[k % QUAL.length], QUAL[(k + 2) % QUAL.length]], comment: COMMENTS[(k + r.name.length) % COMMENTS.length], helpful: k % 3 === 0 ? ["u-neha"] : [],
        createdAt: iso(daysFrom(-2 - k * 5)) });
    });
    if (r.rating.length >= 8) {
      sessions.push(base({ id: `s-seed-${++sid}`, teacherId: r.id, learnerId: pool[1].id, requesterId: pool[1].id, awaitingId: r.id, skill: r.teach[0].name,
        date: ymd(daysFrom(-20, 18)), time: "18:00", duration: 45, status: "Cancelled", wasAccepted: true, note: "Cancelled by teacher (clash with an exam).", objective: "Revision" }));
    }
  }

  const mk = (p: Partial<Session> & Pick<Session, "teacherId" | "learnerId" | "requesterId" | "skill" | "status">, day: number, hour: number, extra: Partial<Session> = {}): Session => {
    const when = daysFrom(day, hour);
    return base({ id: `s-demo-${++sid}`, awaitingId: p.requesterId === p.teacherId ? p.learnerId : p.teacherId, date: ymd(when), time: `${String(hour).padStart(2, "0")}:00`,
      wasAccepted: p.status === "Accepted" || p.status === "Completed", completedBy: p.status === "Completed" ? [p.teacherId, p.learnerId] : [],
      objective: `Work through core ${p.skill} concepts`, meetingLink: "https://meet.google.com/", createdAt: iso(daysFrom(Math.min(day, 0) - 3)), ...p, ...extra });
  };
  sessions.push(
    mk({ teacherId: "u-priya", learnerId: "u-rahul", requesterId: "u-rahul", skill: "Java", status: "Accepted" }, 1, 18, { message: "Can we start with classes and interfaces?" }),
    mk({ teacherId: "u-rahul", learnerId: "u-neha", requesterId: "u-neha", skill: "Python", status: "Accepted" }, 3, 17, { mode: "Offline", meetingLink: undefined, location: "CSE Block, Lab 4", duration: 90 }),
    mk({ teacherId: "u-kavya", learnerId: "u-rahul", requesterId: "u-rahul", skill: "UI/UX Design", status: "Accepted" }, 5, 16, { format: "Group", groupIds: ["u-sneha"], mentorship: true }),
    mk({ teacherId: "u-rahul", learnerId: "u-karan", requesterId: "u-karan", skill: "C Programming", status: "Pending" }, 4, 15, { mode: "Offline", meetingLink: undefined, location: "Library" }),
    mk({ teacherId: "u-rahul", learnerId: "u-ishita", requesterId: "u-ishita", skill: "Python", status: "Pending" }, 6, 19),
    mk({ teacherId: "u-ananya", learnerId: "u-rahul", requesterId: "u-rahul", skill: "Java", status: "Pending" }, 7, 18),
    mk({ teacherId: "u-priya", learnerId: "u-rahul", requesterId: "u-rahul", skill: "Java", status: "Completed" }, -2, 18),
    mk({ teacherId: "u-kavya", learnerId: "u-rahul", requesterId: "u-rahul", skill: "UI/UX Design", status: "Completed" }, -5, 16, { format: "Group", duration: 90, mentorship: true }),
    mk({ teacherId: "u-rahul", learnerId: "u-arjun", requesterId: "u-arjun", skill: "Python", status: "Completed" }, -1, 17, { duration: 45 }),
    mk({ teacherId: "u-rahul", learnerId: "u-sneha", requesterId: "u-sneha", skill: "HTML", status: "Completed" }, -3, 15, { mode: "Offline", duration: 90 }),
    mk({ teacherId: "u-vikram", learnerId: "u-rahul", requesterId: "u-rahul", skill: "Linear Algebra", status: "Rejected" }, -8, 11),
  );
  // Rahul's own reviews (as teacher) come from RAW above; sessions where he taught get matching learner ids
  sessions.push(
    mk({ teacherId: "u-aarav", learnerId: "u-preesha", requesterId: "u-preesha", skill: "Python", status: "Accepted" }, 2, 17),
    mk({ teacherId: "u-tanishka", learnerId: "u-prisha", requesterId: "u-prisha", skill: "React", status: "Accepted" }, 1, 17),
    mk({ teacherId: "u-anushka", learnerId: "u-tanishka", requesterId: "u-tanishka", skill: "Java", status: "Pending" }, 3, 18),
    mk({ teacherId: "u-prisha", learnerId: "u-anushka", requesterId: "u-anushka", skill: "UI/UX Design", status: "Completed" }, -3, 16),
    mk({ teacherId: "u-preesha", learnerId: "u-aarav", requesterId: "u-aarav", skill: "UI/UX Design", status: "Pending" }, 4, 16),
    mk({ teacherId: "u-natasha", learnerId: "u-kabir", requesterId: "u-kabir", skill: "Excel", status: "Accepted" }, 3, 18),
    mk({ teacherId: "u-kabir", learnerId: "u-preesha", requesterId: "u-preesha", skill: "HTML", status: "Completed" }, -2, 15),
  );
  const now = new Date();

  const notifications = [
    { kind: "session" as const, text: "Karan Malhotra requested a C Programming session with you.", href: "/sessions" },
    { kind: "session" as const, text: "Ishita Roy requested a Python session with you.", href: "/sessions" },
    { kind: "match" as const, text: "New mutual match: Priya Verma (Java ⇄ Python).", href: "/matches" },
    { kind: "review" as const, text: "Your session with Priya Verma is complete. Leave a rating.", href: "/reviews" },
    { kind: "connection" as const, text: "Dev Khanna wants to connect with you.", href: "/profile/u-dev", connectionId: "c-dev" },
    { kind: "message" as const, text: "Priya Verma sent you a message.", href: "/messages?with=u-priya" },
  ].map((n, i) => ({ id: `n-seed-${i}`, userId: "u-rahul", read: i > 3, createdAt: iso(daysFrom(-i, 12)), ...n }));

  const msg = (fromId: string, toId: string, text: string, minsAgo: number, read = true) => ({ id: `m-${fromId}-${minsAgo}`, fromId, toId, text, read, createdAt: iso(new Date(now.getTime() - minsAgo * 60000)) });

  return {
    version: DB_VERSION,
    students,
    sessions,
    reviews,
    feedback: [{ id: "f-1", sessionId: sessions.find((s) => s.teacherId === "u-priya" && s.learnerId === "u-rahul" && s.status === "Completed")!.id, teacherId: "u-priya", learnerId: "u-rahul", progress: 4,
      comment: "Rahul came prepared and asked sharp questions about interfaces.", suggestions: "Practise writing two small classes from scratch before next time.", private: true, createdAt: iso(daysFrom(-2, 20)) }],
    connections: [
      { id: "c-priya", fromId: "u-rahul", toId: "u-priya", status: "Accepted", createdAt: iso(daysFrom(-30)) },
      { id: "c-neha", fromId: "u-neha", toId: "u-rahul", status: "Accepted", createdAt: iso(daysFrom(-25)) },
      { id: "c-kavya", fromId: "u-rahul", toId: "u-kavya", status: "Accepted", createdAt: iso(daysFrom(-14)) },
      { id: "c-dev", fromId: "u-dev", toId: "u-rahul", status: "Pending", createdAt: iso(daysFrom(-1)) },
      { id: "c-arjun", fromId: "u-rahul", toId: "u-arjun", status: "Pending", createdAt: iso(daysFrom(-2)) },
      { id: "c-pa", fromId: "u-preesha", toId: "u-aarav", status: "Accepted", createdAt: iso(daysFrom(-9)) },
      { id: "c-t1", fromId: "u-prisha", toId: "u-anushka", status: "Accepted", createdAt: iso(daysFrom(-20)) },
      { id: "c-t2", fromId: "u-prisha", toId: "u-tanishka", status: "Accepted", createdAt: iso(daysFrom(-20)) },
      { id: "c-t3", fromId: "u-anushka", toId: "u-tanishka", status: "Accepted", createdAt: iso(daysFrom(-19)) },
      { id: "c-nk", fromId: "u-kabir", toId: "u-natasha", status: "Accepted", createdAt: iso(daysFrom(-6)) },
      { id: "c-pn", fromId: "u-natasha", toId: "u-preesha", status: "Pending", createdAt: iso(daysFrom(-1)) },
    ],
    messages: [
      msg("u-rahul", "u-priya", "Hi Priya! Thanks for accepting. Should I install anything before tomorrow?", 300),
      msg("u-priya", "u-rahul", "Just a JDK and VS Code with the Java extension pack. Bring a small idea you'd like to model as classes!", 280, false),
      msg("u-neha", "u-rahul", "See you at Lab 4 on Thursday 🙂", 1500),
    ],
    notifications,
    reports: [{ id: "rep-1", reporterId: "u-meera", targetType: "user", targetId: "u-dev", reason: "Missed two sessions without notice.", status: "open", createdAt: iso(daysFrom(-4)) }],
    support: [{ id: "sup-1", name: "Tara Menon", email: "tara.menon@sample.peerup.edu", subject: "Can't add certificate", message: "The upload button didn't respond on my phone.", status: "open", createdAt: iso(daysFrom(-1)) }],
    audit: [],
    resources: [
      { id: "res-1", ownerId: "u-priya", title: "Java OOP cheat sheet", url: "https://docs.oracle.com/javase/tutorial/java/concepts/", kind: "Documentation", skill: "Java", createdAt: iso(daysFrom(-10)) },
      { id: "res-2", ownerId: "u-kavya", title: "Laws of UX", url: "https://lawsofux.com/", kind: "Link", skill: "UI/UX Design", createdAt: iso(daysFrom(-6)) },
      { id: "res-3", ownerId: "u-rahul", title: "Python practice set: loops & functions", url: "https://docs.python.org/3/tutorial/", kind: "Practice Exercise", skill: "Python", createdAt: iso(daysFrom(-3)) },
    ],
    progress: [
      { id: "p-1", userId: "u-rahul", skill: "Java", percent: 35, goal: "Build a small library-management app", notes: "Interfaces vs abstract classes still fuzzy.", milestones: [{ text: "Classes & objects", done: true }, { text: "Inheritance", done: true }, { text: "Interfaces", done: false }, { text: "Collections", done: false }], completed: false, updatedAt: iso(daysFrom(-2)) },
      { id: "p-2", userId: "u-rahul", skill: "UI/UX Design", percent: 20, goal: "Redesign the club website", notes: "", milestones: [{ text: "Heuristics", done: true }, { text: "Wireframes", done: false }, { text: "Prototype in Figma", done: false }], completed: false, updatedAt: iso(daysFrom(-5)) },
    ],
    challenges: [{ id: "ch-1", userId: "u-rahul", challengeId: "code7", startedAt: iso(daysFrom(-2, 9)), daysDone: [1, 2] }],
    settings: {
      mentorMinYear: 3, mentorMinSessions: 3, mentorMinRating: 4.0,
      skillCategories: ["Programming", "Web Development", "Design", "Mathematics", "Science", "Communication", "Business & Management", "Legal Studies", "Medical & Health", "Finance", "Data Science", "Video Editing", "Other"],
      notify: { sessions: true, connections: true, reviews: true, messages: true, matches: true },
    },
  };
}
