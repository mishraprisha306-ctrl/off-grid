"use client";
import { motion } from "framer-motion";
import {
  ArrowRight, BookOpen, CalendarCheck, CalendarDays, CalendarPlus, Compass, GraduationCap, Hourglass, IdCard, Lightbulb, Plus, Presentation,
  ShieldCheck, Star, Trophy, Users,
} from "lucide-react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useMemo, useState } from "react";
import { LoopArrow } from "@/components/doodles";
import { MatchCard, ProfileModal, RequestSessionModal, SessionCard, useStats } from "@/components/domain";
import { Avatar, Button, Card, Counter, EmptyState, MentorBadge, Ring, Stars, fadeUp } from "@/components/ui";
import { type Match, allMatches, isMentor, participants, profileCompletion, ratingSummary, recommendSkills, sessionStart, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { Student } from "@/lib/types";

const ActivityChart = dynamic(() => import("@/components/activity-chart"), { ssr: false, loading: () => <div className="skeleton h-full w-full" /> });

export default function Dashboard() {
  const { db, me: maybeMe, now } = useStore();
  const me = maybeMe!;
  const stats = useStats(me.id);
  const [view, setView] = useState<Student | null>(null);
  const [req, setReq] = useState<Match | null>(null);

  const mine = db.sessions.filter((s) => participants(s).includes(me.id));
  const upcoming = mine.filter((s) => s.status === "Accepted" && sessionStart(s).getTime() + s.duration * 60_000 > now).sort((a, b) => +sessionStart(a) - +sessionStart(b));
  const pending = mine.filter((s) => s.status === "Pending" && s.awaitingId === me.id);
  const matches = useMemo(() => allMatches(me, db.students), [me, db.students]);
  const recommended = [...matches.mutual, ...matches.learn].filter((m) => m.student.field === me.field || m.kind === "mutual").slice(0, 3);
  const recs = recommended.length ? recommended : [...matches.mutual, ...matches.learn, ...matches.teach].slice(0, 3);
  const mentors = db.students
    .filter((s) => s.id !== me.id && isMentor(s, db) && s.teach.some((t) => me.learn.some((l) => l.category === t.category) || me.interests.length === 0))
    .map((s) => ({ s, r: ratingSummary(s.id, db.reviews) }))
    .sort((a, b) => Number(b.s.field === me.field) - Number(a.s.field === me.field) || (b.r.average ?? 0) - (a.r.average ?? 0))
    .slice(0, 4);
  const recentReviews = db.reviews.filter((r) => r.revieweeId === me.id).slice(0, 3);
  const activity = db.notifications.filter((n) => n.userId === me.id).slice(0, 6);
  const progress = db.progress.filter((p) => p.userId === me.id).slice(0, 3);
  const skillRecs = recommendSkills(me);
  const completion = profileCompletion(me);

  const chart = useMemo(() => {
    return [...Array(7)].map((_, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - 6 + i);
      const key = d.toDateString();
      const sum = (role: "teach" | "learn") => mine.filter((s) => s.status === "Completed" && (role === "teach" ? s.teacherId === me.id : s.teacherId !== me.id) && sessionStart(s).toDateString() === key).reduce((a, s) => a + s.duration / 60, 0);
      return { day: d.toLocaleDateString(undefined, { weekday: "short" }), Teaching: +sum("teach").toFixed(1), Learning: +sum("learn").toFixed(1) };
    });
  }, [mine, me.id, now]);

  const cards = [
    { label: "Profile completion", value: completion, suffix: "%", icon: IdCard, href: "/my-skills" },
    { label: "Skills offered", value: me.teach.length, icon: Presentation, href: "/my-skills" },
    { label: "Skills wanted", value: me.learn.length, icon: BookOpen, href: "/my-skills" },
    { label: "Mutual matches", value: matches.mutual.length, icon: Users, href: "/matches" },
    { label: "Pending requests", value: pending.length, icon: Hourglass, href: "/sessions" },
    { label: "Upcoming sessions", value: upcoming.length, icon: CalendarCheck, href: "/calendar" },
    { label: "Avg teaching rating", value: stats.rating.average ?? 0, dec: 1, none: stats.rating.average === null, icon: Star, href: "/reviews" },
    { label: "Trust score", value: stats.trust.total, none: !stats.trust.established, noneLabel: "New", icon: ShieldCheck, href: "/trust" },
  ];
  const actions = [
    { label: "Add a skill", icon: Plus, href: "/my-skills" },
    { label: "Find a mutual match", icon: Users, href: "/matches" },
    { label: "Explore mentors", icon: GraduationCap, href: "/mentors" },
    { label: "Book a session", icon: CalendarPlus, href: "/explore" },
    { label: "View leaderboard", icon: Trophy, href: "/leaderboard" },
  ];
  const hour = new Date(now).getHours();

  return (
    <div className="space-y-8">
      <motion.section variants={fadeUp} initial="hidden" animate="show" className="neu relative flex flex-col gap-6 overflow-hidden p-6 sm:flex-row sm:items-center sm:p-8">
        <span aria-hidden className="pink-orb pointer-events-none absolute -top-16 right-40 h-40 w-40 rounded-full opacity-40" />
        <LoopArrow className="pointer-events-none absolute right-[15.5rem] bottom-3 hidden h-16 w-28 lg:block" />
        <div className="relative flex-1">
          <p className="text-sm font-semibold text-blush-ink">Good {hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening"}</p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-navy sm:text-[1.9rem]">Welcome back, {me.name.split(" ")[0]}!</h1>
          <p className="mt-1 text-subtle">{me.department} · {yearLabel(me.year)} · {me.college}</p>
        </div>
        <div className="relative flex items-center gap-4">
          <Ring value={completion} size={76} label={`Profile ${completion}% complete`} />
          <div><p className="text-sm font-bold text-navy">Profile completion</p>{completion < 100 ? <Link href="/settings" className="text-sm font-semibold text-teal-strong hover:underline">Complete your profile →</Link> : <p className="text-sm text-subtle">All set!</p>}</div>
        </div>
      </motion.section>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c, i) => (
          <motion.div key={c.label} variants={fadeUp} initial="hidden" animate="show" custom={i * 0.5}>
            <Link href={c.href} className="neu glow-hover flex items-center gap-3 p-4 hover:-translate-y-0.5 sm:p-5">
              <span className="neu-inset flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-teal-strong"><c.icon className="h-5 w-5" /></span>
              <span className="min-w-0">
                <span className="block text-xl font-extrabold text-navy sm:text-2xl">{c.none ? (c.noneLabel ?? "-") : <><Counter value={c.value} decimals={c.dec ?? 0} />{c.suffix}</>}</span>
                <span className="block truncate text-xs text-subtle sm:text-sm">{c.label}</span>
              </span>
            </Link>
          </motion.div>
        ))}
      </section>

      <section className="flex flex-wrap gap-2" aria-label="Quick actions">
        {actions.map((a) => <Button key={a.label} href={a.href} variant="secondary" size="sm"><a.icon className="h-4 w-4 text-teal-strong" /> {a.label}</Button>)}
      </section>

      {pending.length > 0 && (
        <section>
          <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold text-navy">Pending requests for you</h2><Link href="/sessions" className="text-sm font-semibold text-teal-strong hover:underline">All requests</Link></div>
          <div className="space-y-4">{pending.slice(0, 2).map((s) => <SessionCard key={s.id} session={s} />)}</div>
        </section>
      )}

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <div className="mb-4 flex items-center justify-between"><h2 className="font-bold text-navy">Learning activity · last 7 days</h2><span className="text-xs text-subtle">hours in completed sessions</span></div>
          <div className="h-64"><ActivityChart data={chart} /></div>
        </Card>
        <Card>
          <div className="mb-4 flex items-center justify-between"><h2 className="font-bold text-navy">Learning progress</h2><Link href="/progress" className="text-sm font-semibold text-teal-strong hover:underline">Manage</Link></div>
          {progress.length ? (
            <ul className="space-y-4">
              {progress.map((p) => (
                <li key={p.id}>
                  <div className="flex justify-between text-sm"><span className="font-semibold text-ink">{p.skill}</span><span className="text-subtle">{p.percent}%</span></div>
                  <div className="neu-inset mt-1.5 h-2 overflow-hidden rounded-full"><motion.div className="h-full rounded-full bg-teal" initial={{ width: 0 }} animate={{ width: `${p.percent}%` }} transition={{ duration: 0.9 }} /></div>
                  {p.goal && <p className="mt-1 text-xs text-subtle">Goal: {p.goal}</p>}
                </li>
              ))}
            </ul>
          ) : <EmptyState icon={BookOpen} title="Track a skill" text="Set goals and milestones for what you're learning." action={<Button href="/progress" size="sm">Start tracking</Button>} />}
        </Card>
      </div>

      <section>
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold text-navy">Recommended students</h2><Link href="/matches" className="inline-flex items-center gap-1 text-sm font-semibold text-teal-strong hover:underline">All matches <ArrowRight className="h-4 w-4" /></Link></div>
        {recs.length ? <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{recs.map((m) => <MatchCard key={m.student.id} match={m} onView={() => setView(m.student)} onRequest={() => setReq(m)} />)}</div>
          : <Card><EmptyState icon={Compass} title="No matches yet" text="Add more skills you teach and want to learn." action={<Button href="/my-skills">Edit My Skills</Button>} /></Card>}
      </section>

      <div className="grid gap-6 xl:grid-cols-3">
        <section className="xl:col-span-2">
          <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold text-navy">Upcoming sessions</h2><Link href="/calendar" className="inline-flex items-center gap-1 text-sm font-semibold text-teal-strong hover:underline">Calendar <ArrowRight className="h-4 w-4" /></Link></div>
          {upcoming.length ? <div className="space-y-4">{upcoming.slice(0, 3).map((s) => <SessionCard key={s.id} session={s} />)}</div>
            : <Card><EmptyState icon={CalendarDays} title="Nothing scheduled" text="Request a session with a match or mentor." action={<Button href="/matches">Find a match</Button>} /></Card>}
        </section>
        <section>
          <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold text-navy">Recommended mentors</h2><Link href="/mentors" className="text-sm font-semibold text-teal-strong hover:underline">View all</Link></div>
          <div className="no-scrollbar -mx-4 flex gap-4 overflow-x-auto px-4 pt-1 pb-4 xl:mx-0 xl:flex-col xl:overflow-visible xl:px-0">
            {mentors.map(({ s, r }) => (
              <button key={s.id} onClick={() => setView(s)} className="neu glow-hover flex w-64 shrink-0 items-center gap-3 p-4 text-left hover:-translate-y-0.5 xl:w-auto">
                <Avatar name={s.name} src={s.avatar} size={44} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-bold text-navy">{s.name}</span>
                  <span className="block truncate text-xs text-subtle">{s.field} · {s.teach.map((t) => t.name).join(", ")}</span>
                  <span className="mt-1 flex items-center gap-2"><Stars value={r.average} size={12} showValue /><MentorBadge small /></span>
                </span>
              </button>
            ))}
            {!mentors.length && <p className="text-sm text-subtle">No mentors in your areas yet.</p>}
          </div>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card>
          <h2 className="font-bold text-navy">Recent activity</h2>
          <ul className="mt-3 space-y-3">{activity.map((n) => <li key={n.id}><Link href={n.href} className="block text-sm text-ink hover:text-teal-strong">{n.text}</Link><span className="text-xs text-subtle">{new Date(n.createdAt).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span></li>)}</ul>
          {!activity.length && <p className="mt-3 text-sm text-subtle">No activity yet.</p>}
        </Card>
        <Card>
          <div className="flex items-center justify-between"><h2 className="font-bold text-navy">Recent reviews</h2><Link href="/reviews" className="text-sm font-semibold text-teal-strong hover:underline">All</Link></div>
          <ul className="mt-3 space-y-4">{recentReviews.map((r) => <li key={r.id}><Stars value={r.stars} size={12} /><p className="mt-1 line-clamp-2 text-sm text-ink">“{r.comment}”</p><p className="text-xs text-subtle">{r.skill}</p></li>)}</ul>
          {!recentReviews.length && <p className="mt-3 text-sm text-subtle">Teach a session to receive your first review.</p>}
        </Card>
        <Card>
          <h2 className="flex items-center gap-2 font-bold text-navy"><Lightbulb className="h-4 w-4 text-amber" /> Skill recommendations</h2>
          <ul className="mt-3 space-y-2.5">{skillRecs.map((r) => <li key={r.skill} className="flex items-center justify-between gap-2"><span><span className="font-semibold text-navy">{r.skill}</span><span className="block text-xs text-subtle">because you're into {r.because}</span></span><Button size="sm" variant="ghost" href={`/explore?q=${encodeURIComponent(r.skill)}`}>Find</Button></li>)}</ul>
          {!skillRecs.length && <p className="mt-3 text-sm text-subtle">Add skills and interests to get recommendations.</p>}
        </Card>
      </div>

      <ProfileModal student={view} onClose={() => setView(null)} />
      <RequestSessionModal open={!!req} other={req?.student ?? null} onClose={() => setReq(null)} role={req?.theyTeach.length ? "learn" : "teach"} skill={req?.theyTeach[0] ?? req?.iTeach[0]} />
    </div>
  );
}
