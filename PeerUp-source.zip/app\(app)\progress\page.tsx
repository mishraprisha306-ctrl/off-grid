"use client";
import { CheckCircle2, Plus, Target, Trash2, TrendingUp } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/components/toast";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, PageHeader, Textarea, cn } from "@/components/ui";
import { participants, sessionStart } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { Progress } from "@/lib/types";

type Draft = Omit<Progress, "id" | "userId" | "updatedAt"> & { id?: string };
const blank = (skill = ""): Draft => ({ skill, percent: 0, goal: "", notes: "", milestones: [], completed: false });

export default function ProgressPage() {
  const { db, me, saveProgress, removeProgress } = useStore();
  const toast = useToast();
  const [edit, setEdit] = useState<Draft | null>(null);
  const [ms, setMs] = useState("");
  const [err, setErr] = useState("");
  if (!me) return null;
  const items = db.progress.filter((p) => p.userId === me.id);
  const current = items.filter((p) => !p.completed);
  const done = items.filter((p) => p.completed);
  const history = db.sessions.filter((s) => s.status === "Completed" && participants(s).includes(me.id) && s.teacherId !== me.id).sort((a, b) => +sessionStart(b) - +sessionStart(a));
  const untracked = me.learn.filter((l) => !items.some((p) => p.skill.toLowerCase() === l.name.toLowerCase()));
  const quick = (p: Progress, i: number) => {
    const milestones = p.milestones.map((m, j) => (j === i ? { ...m, done: !m.done } : m));
    const r = saveProgress({ ...p, milestones });
    if (!r.ok) toast(r.error, "error");
  };

  const Item = ({ p }: { p: Progress }) => (
    <Card>
      <div className="flex items-start justify-between gap-3">
        <div><h3 className="text-lg font-extrabold text-navy">{p.skill}</h3>{p.goal && <p className="flex items-center gap-1.5 text-sm text-subtle"><Target className="h-3.5 w-3.5" /> {p.goal}</p>}</div>
        {p.completed ? <Badge tone="green"><CheckCircle2 className="h-3 w-3" /> Completed</Badge> : <span className="text-2xl font-extrabold text-navy">{p.percent}%</span>}
      </div>
      <div className="neu-inset mt-3 h-2.5 overflow-hidden rounded-full"><div className="h-full rounded-full bg-teal transition-[width] duration-500" style={{ width: `${p.percent}%` }} /></div>
      {p.milestones.length > 0 && <ul className="mt-4 space-y-2">{p.milestones.map((m, i) => <li key={i}><label className="flex items-center gap-2.5 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={m.done} onChange={() => quick(p, i)} /><span className={cn(m.done && "text-subtle line-through")}>{m.text}</span></label></li>)}</ul>}
      {p.notes && <p className="mt-3 neu-inset rounded-xl p-3 text-sm text-ink">{p.notes}</p>}
      <div className="mt-4 flex gap-2"><Button size="sm" variant="secondary" onClick={() => { setEdit({ ...p }); setErr(""); }}>Edit</Button><Button size="sm" variant="ghost" onClick={() => removeProgress(p.id)} aria-label={`Delete ${p.skill}`}><Trash2 className="h-4 w-4" /></Button></div>
    </Card>
  );

  return (
    <div>
      <PageHeader title="Learning Progress" subtitle="Goals, milestones and notes for what you're learning." action={<Button onClick={() => { setEdit(blank()); setErr(""); }}><Plus className="h-4 w-4" /> Track a skill</Button>} />
      {untracked.length > 0 && <div className="mb-6 flex flex-wrap items-center gap-2 text-sm"><span className="text-subtle">From your learning goals:</span>{untracked.map((l) => <button key={l.name} onClick={() => setEdit(blank(l.name))} className="rounded-full bg-ivory px-3 py-1 font-semibold text-navy shadow-[var(--shadow-raised-sm)] hover:shadow-[var(--shadow-glow)]">+ {l.name}</button>)}</div>}
      <h2 className="mb-4 font-bold text-navy">Currently learning</h2>
      {current.length ? <div className="grid gap-6 md:grid-cols-2">{current.map((p) => <Item key={p.id} p={p} />)}</div> : <Card><EmptyState icon={TrendingUp} title="Nothing tracked yet" text="Add a skill with milestones and watch your progress fill up." action={<Button onClick={() => setEdit(blank())}>Track a skill</Button>} /></Card>}
      {done.length > 0 && <><h2 className="mt-10 mb-4 font-bold text-navy">Completed skills</h2><div className="grid gap-6 md:grid-cols-2">{done.map((p) => <Item key={p.id} p={p} />)}</div></>}
      <h2 className="mt-10 mb-4 font-bold text-navy">Learning history</h2>
      <Card className="p-0">
        <ul className="divide-y divide-line">{history.map((s) => <li key={s.id} className="flex items-center justify-between px-6 py-3 text-sm"><span className="font-semibold text-ink">{s.skill}</span><span className="text-subtle">{sessionStart(s).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })} · {s.duration} min</span></li>)}</ul>
        {!history.length && <p className="p-6 text-sm text-subtle">Completed sessions you attended will appear here.</p>}
      </Card>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? `Edit ${edit.skill}` : "Track a skill"}>
        {edit && (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); const r = saveProgress(edit); if (!r.ok) return setErr(r.error); toast("Progress saved."); setEdit(null); }}>
            <Field label="Skill" htmlFor="pg-s"><Input id="pg-s" value={edit.skill} onChange={(e) => setEdit({ ...edit, skill: e.target.value })} /></Field>
            <Field label="Learning goal" htmlFor="pg-g"><Input id="pg-g" placeholder="e.g. Build a small app" value={edit.goal} onChange={(e) => setEdit({ ...edit, goal: e.target.value })} /></Field>
            <div>
              <p className="mb-2 text-sm font-semibold text-ink">Milestones</p>
              <ul className="mb-2 space-y-1.5">{edit.milestones.map((m, i) => <li key={i} className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={m.done} onChange={() => setEdit({ ...edit, milestones: edit.milestones.map((x, j) => (j === i ? { ...x, done: !x.done } : x)) })} /><span className="flex-1">{m.text}</span><button type="button" onClick={() => setEdit({ ...edit, milestones: edit.milestones.filter((_, j) => j !== i) })} className="text-muted hover:text-rose" aria-label="Remove milestone"><Trash2 className="h-3.5 w-3.5" /></button></li>)}</ul>
              <div className="flex gap-2"><Input placeholder="Add a milestone" value={ms} onChange={(e) => setMs(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); if (ms.trim()) { setEdit({ ...edit, milestones: [...edit.milestones, { text: ms.trim(), done: false }] }); setMs(""); } } }} aria-label="Milestone" /><Button type="button" variant="secondary" onClick={() => { if (ms.trim()) { setEdit({ ...edit, milestones: [...edit.milestones, { text: ms.trim(), done: false }] }); setMs(""); } }}>Add</Button></div>
            </div>
            {!edit.milestones.length && <Field label={`Progress: ${edit.percent}%`} htmlFor="pg-p"><input id="pg-p" type="range" min={0} max={100} step={5} value={edit.percent} onChange={(e) => setEdit({ ...edit, percent: Number(e.target.value) })} className="w-full accent-[#4c3fc8]" /></Field>}
            <Field label="Personal notes" htmlFor="pg-n"><Textarea id="pg-n" rows={3} value={edit.notes} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-[#4c3fc8]" checked={edit.completed} onChange={(e) => setEdit({ ...edit, completed: e.target.checked })} /> Mark this skill as completed</label>
            {err && <p className="text-sm font-semibold text-rose">{err}</p>}
            <Button type="submit" className="w-full">Save</Button>
          </form>
        )}
      </Modal>
    </div>
  );
}
