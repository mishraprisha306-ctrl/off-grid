"use client";
import { Award, Ban, BadgeCheck, CalendarPlus, Flag, GraduationCap, Lock, MessageCircle, MoreHorizontal, Pencil } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { MIN_SKILL_REVIEWS, achievements, participants, sessionStart, yearLabel } from "@/lib/engines";
import { useStore } from "@/lib/store";
import type { Student } from "@/lib/types";
import { ConnectButton, ReportModal, RequestSessionModal, SampleTag, TrustPill, useStats } from "./domain";
import { useToast } from "./toast";
import { Avatar, Badge, Button, Card, MentorBadge, Modal, Ring, SkillChip, Stars, Tabs, cn } from "./ui";

export function ProfileView({ student }: { student: Student }) {
  const { me, db, byId, block } = useStore();
  const toast = useToast();
  const router = useRouter();
  const { rating, mentorRating, trust, mentor } = useStats(student.id);
  const [book, setBook] = useState<null | "session" | "mentor">(null);
  const [tab, setTab] = useState<"reviews" | "teaching" | "learning">("reviews");
  const [menu, setMenu] = useState(false);
  const [report, setReport] = useState(false);
  const [confirmBlock, setConfirmBlock] = useState(false);
  const own = me?.id === student.id;
  const blockedMe = student.blocked.includes(me?.id ?? "");
  const done = db.sessions.filter((s) => s.status === "Completed" && participants(s).includes(student.id));
  const taught = done.filter((s) => s.teacherId === student.id);
  const attended = done.filter((s) => s.teacherId !== student.id);
  const reviews = db.reviews.filter((r) => r.revieweeId === student.id);
  const ach = achievements(student, db).filter((a) => a.got);
  const progress = own ? db.progress.filter((p) => p.userId === student.id) : [];
  const show = (flag: boolean) => own || flag;

  if (blockedMe && !own) return <Card className="py-16 text-center"><Lock className="mx-auto h-8 w-8 text-muted" /><p className="mt-3 font-bold text-navy">This profile isn't available.</p></Card>;

  return (
    <div className="space-y-6">
      <Card className="relative overflow-hidden p-0">
        <div className="relative h-28 bg-navy sm:h-32"><span aria-hidden className="absolute top-6 right-16 h-20 w-20 rounded-full bg-[#f6c9cc]/30 shadow-[0_0_60px_24px_rgb(246_201_204/.3)]" /></div>
        <div className="flex flex-col gap-5 px-6 pb-6 sm:flex-row sm:items-end sm:px-8">
          <div className="-mt-12"><Avatar name={student.name} src={student.avatar} size={104} /></div>
          <div className="flex-1">
            <h1 className="flex flex-wrap items-center gap-2 text-2xl font-extrabold text-navy">{student.name}{student.sample && <SampleTag />}</h1>
            <p className="text-subtle">{student.field} · {student.department} · {yearLabel(student.year)}{show(student.privacy.showCollege) ? ` · ${student.college}` : ""}</p>
            {show(student.privacy.showEmail) && <p className="text-sm text-subtle">{student.email}</p>}
            {own && student.studentId && <p className="text-xs text-subtle">Student ID {student.studentId} {student.privacy.showStudentId ? "(public)" : "(only you)"}</p>}
            <div className="mt-2 flex flex-wrap items-center gap-2"><Stars value={rating.average} showValue count={rating.count} />{mentor && <MentorBadge small />}<TrustPill id={student.id} /></div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {own ? (
              <><Button href="/settings"><Pencil className="h-4 w-4" /> Edit profile</Button><Button variant="secondary" href="/my-skills">My Skills</Button></>
            ) : me?.role !== "admin" ? (
              <>
                <Button variant="accent" onClick={() => setBook("session")}><CalendarPlus className="h-4 w-4" /> Request session</Button>
                {mentor && <Button variant="secondary" onClick={() => setBook("mentor")} disabled={!student.mentorAvailable}><GraduationCap className="h-4 w-4" /> Request mentorship</Button>}
                <ConnectButton student={student} size="md" />
                <Button variant="secondary" href={`/messages?with=${student.id}`} aria-label="Message"><MessageCircle className="h-4 w-4" /></Button>
                <div className="relative">
                  <Button variant="ghost" onClick={() => setMenu(!menu)} aria-label="More actions" aria-expanded={menu}><MoreHorizontal className="h-5 w-5" /></Button>
                  {menu && <div className="absolute right-0 z-10 mt-1 w-44 rounded-xl bg-ivory p-1 shadow-[var(--shadow-raised-lg)]"><button onClick={() => { setMenu(false); setReport(true); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-[#e5e9f2]"><Flag className="h-4 w-4" /> Report profile</button><button onClick={() => { setMenu(false); setConfirmBlock(true); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose hover:bg-[#e5e9f2]"><Ban className="h-4 w-4" /> Block</button></div>}
                </div>
              </>
            ) : null}
          </div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <h2 className="font-bold text-navy">About</h2>
            <p className="mt-2 text-ink">{student.bio || <span className="text-subtle">No bio yet.</span>}</p>
            {student.interests.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{student.interests.map((i) => <Badge key={i}>{i}</Badge>)}</div>}
            {show(student.privacy.showLinks) && Object.values(student.links).some(Boolean) && <p className="mt-4 flex flex-wrap gap-4 text-sm">{Object.entries(student.links).filter(([, v]) => v).map(([k, v]) => <a key={k} href={v} target="_blank" rel="noreferrer noopener" className="font-semibold text-teal-strong capitalize hover:underline">{k} ↗</a>)}</p>}
          </Card>
          <div className="grid gap-6 sm:grid-cols-2">
            <Card>
              <h2 className="font-bold text-navy">Skills they can teach</h2>
              <ul className="mt-3 divide-y divide-line">
                {student.teach.map((t) => {
                  const sk = rating.bySkill.find((b) => b.skill === t.name);
                  return (
                    <li key={t.name} className="py-2.5">
                      <div className="flex items-center justify-between gap-2 text-sm"><span className="font-semibold">{t.name} <span className="text-xs font-medium text-subtle">· {t.level}</span></span>{sk ? (sk.enough ? <span className="flex items-center gap-1"><Stars value={sk.average} size={11} showValue /><span className="text-xs text-subtle">({sk.count})</span></span> : <span className="text-xs text-subtle">{sk.count}/{MIN_SKILL_REVIEWS} reviews</span>) : <span className="text-xs text-subtle">New skill</span>}</div>
                      {t.description && <p className="text-xs text-subtle">{t.description}</p>}
                    </li>
                  );
                })}
                {!student.teach.length && <li className="py-2 text-sm text-subtle">None listed.</li>}
              </ul>
              <p className="mt-2 text-xs text-subtle">Skill levels are self-reported.</p>
            </Card>
            <Card>
              <h2 className="font-bold text-navy">Skills they want to learn</h2>
              <div className="mt-3 flex flex-wrap gap-1.5">{student.learn.map((t) => <SkillChip key={t.name} tone="teal">{t.name}</SkillChip>)}</div>
              <h3 className="mt-5 text-sm font-bold text-navy">Availability</h3>
              <p className="mt-1 text-sm text-subtle">{student.mode === "both" ? "Online & offline" : student.mode} · {student.formats.join(", ")}</p>
              <ul className="mt-1 text-sm text-subtle">{student.slots.map((s, i) => <li key={i}>{s.day} {s.from}–{s.to}</li>)}</ul>
            </Card>
          </div>
          {student.certificates.length > 0 && (
            <Card>
              <h2 className="font-bold text-navy">Certificates & evidence</h2>
              <ul className="mt-3 space-y-2">{student.certificates.map((c) => <li key={c.id} className="flex items-center justify-between gap-3 text-sm"><span className="font-semibold text-ink">{c.title}</span>{c.status === "verified" ? <Badge tone="green"><BadgeCheck className="h-3 w-3" /> Verified by admin</Badge> : c.status === "evidence" ? <Badge tone="amber">Evidence attached · not verified</Badge> : <Badge>Self-reported</Badge>}</li>)}</ul>
            </Card>
          )}
          <Card>
            <Tabs value={tab} onChange={setTab} tabs={[{ value: "reviews", label: "Reviews", count: reviews.length }, { value: "teaching", label: "Teaching history", count: taught.length }, { value: "learning", label: own ? "Learning progress" : "Learning history", count: own ? progress.length : attended.length }]} />
            <div className="mt-5">
              {tab === "reviews" && (reviews.length ? <ul className="space-y-4">{reviews.slice(0, 8).map((r) => <li key={r.id} className="border-b border-line pb-4 last:border-0 last:pb-0"><div className="flex items-center justify-between"><span className="text-sm font-bold text-ink">{byId(r.reviewerId)?.name ?? "Former member"} · <span className="text-teal-strong">{r.skill}</span>{r.mentorship && <Badge tone="teal" className="ml-2">Mentorship</Badge>}</span><Stars value={r.stars} size={12} /></div><p className="mt-1 text-sm text-subtle">“{r.comment}”</p></li>)}</ul> : <p className="text-sm text-subtle">No reviews yet.</p>)}
              {tab === "teaching" && (taught.length ? <ul className="divide-y divide-line">{taught.map((s) => <li key={s.id} className="flex justify-between py-2 text-sm"><span className="font-semibold">{s.skill}{s.mentorship && " · mentorship"}</span><span className="text-subtle">{sessionStart(s).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}</span></li>)}</ul> : <p className="text-sm text-subtle">No completed teaching sessions yet.</p>)}
              {tab === "learning" && (own ? (progress.length ? <ul className="space-y-3">{progress.map((p) => <li key={p.id}><div className="flex justify-between text-sm"><span className="font-semibold">{p.skill}</span><span>{p.percent}%</span></div><div className="neu-inset mt-1 h-2 overflow-hidden rounded-full"><div className="h-full bg-teal" style={{ width: `${p.percent}%` }} /></div></li>)}</ul> : <p className="text-sm text-subtle">Track skills on the <Link href="/progress" className="font-semibold text-teal-strong">Learning Progress</Link> page.</p>)
                : attended.length ? <ul className="divide-y divide-line">{attended.map((s) => <li key={s.id} className="flex justify-between py-2 text-sm"><span className="font-semibold">{s.skill}</span><span className="text-subtle">{sessionStart(s).toLocaleDateString(undefined, { day: "numeric", month: "short" })}</span></li>)}</ul> : <p className="text-sm text-subtle">No sessions attended yet.</p>)}
            </div>
          </Card>
        </div>
        <div className="space-y-6">
          <Card className="text-center">
            {trust.established ? <Ring value={trust.total} size={96} stroke={9} label={`Trust score ${trust.total}`} /> : <span className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-blush-soft text-sm font-bold text-blush-ink shadow-[0_0_28px_4px_rgb(246_201_204/.7)]">New</span>}
            <p className="mt-2 font-bold text-navy">Trust score</p>
            <p className="text-xs text-subtle">{trust.established ? "From verified sessions and ratings" : "Building trust: needs more rated sessions"}</p>
            <div className="mt-4 grid grid-cols-3 gap-2">
              <div className="neu-inset rounded-xl py-2"><p className="font-extrabold text-navy">{done.length}</p><p className="text-[0.65rem] text-subtle">Completed</p></div>
              <div className="neu-inset rounded-xl py-2"><p className="font-extrabold text-navy">{taught.length}</p><p className="text-[0.65rem] text-subtle">Taught</p></div>
              <div className="neu-inset rounded-xl py-2"><p className="font-extrabold text-navy">{attended.length}</p><p className="text-[0.65rem] text-subtle">Attended</p></div>
            </div>
            {own && <Link href="/trust" className="mt-3 inline-block text-xs font-semibold text-teal-strong hover:underline">How is this calculated?</Link>}
          </Card>
          {mentor && (
            <Card>
              <h2 className="flex items-center gap-2 font-bold text-navy"><GraduationCap className="h-4 w-4 text-teal-strong" /> Mentor profile</h2>
              <p className="mt-2 text-sm">Mentor rating: {mentorRating.count ? <Stars value={mentorRating.average} size={12} showValue count={mentorRating.count} /> : <span className="text-subtle">no mentorship reviews yet</span>}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">{student.mentorCategories.map((c) => <Badge key={c} tone="teal">{c}</Badge>)}</div>
              <p className={cn("mt-2 text-sm font-semibold", student.mentorAvailable ? "text-teal-strong" : "text-subtle")}>{student.mentorAvailable ? "Accepting mentees" : "Not accepting mentees right now"}</p>
            </Card>
          )}
          <Card>
            <h2 className="flex items-center gap-2 font-bold text-navy"><Award className="h-4 w-4 text-amber" /> Achievements</h2>
            {ach.length ? <ul className="mt-3 flex flex-wrap gap-2">{ach.map((a) => <li key={a.id}><Badge tone="teal">{a.label}</Badge></li>)}</ul> : <p className="mt-2 text-sm text-subtle">None yet.</p>}
          </Card>
        </div>
      </div>
      {!own && <RequestSessionModal open={!!book} other={student} mentorship={book === "mentor"} title={book === "mentor" ? `Request mentorship from ${student.name.split(" ")[0]}` : undefined} onClose={() => setBook(null)} />}
      <ReportModal open={report} onClose={() => setReport(false)} targetType="user" targetId={student.id} label={student.name} />
      <Modal open={confirmBlock} onClose={() => setConfirmBlock(false)} title={`Block ${student.name}?`}>
        <p className="text-sm text-ink">They won't be able to message, connect with or book you. Pending requests between you are cancelled. You can unblock them in Connections.</p>
        <div className="mt-6 flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => setConfirmBlock(false)}>Cancel</Button><Button variant="danger" className="flex-1" onClick={() => { const r = block(student.id); toast(r.ok ? "User blocked." : r.error!, r.ok ? "info" : "error"); setConfirmBlock(false); router.push("/connections"); }}>Block</Button></div>
      </Modal>
    </div>
  );
}
