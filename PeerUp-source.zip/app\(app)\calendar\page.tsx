"use client";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { Badge, Button, Card, PageHeader, cn } from "@/components/ui";
import { participants, sessionStart } from "@/lib/engines";
import { useStore } from "@/lib/store";
import { DAYS } from "@/lib/types";

export default function Calendar() {
  const { db, me, now } = useStore();
  const [offset, setOffset] = useState(0);
  const base = new Date(now);
  const month = new Date(base.getFullYear(), base.getMonth() + offset, 1);
  const startPad = (month.getDay() + 6) % 7; // Monday first
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const mine = useMemo(() => (me ? db.sessions.filter((s) => participants(s).includes(me.id) && (s.status === "Accepted" || s.status === "Pending" || s.status === "Completed")) : []), [db.sessions, me]);
  const byDay = useMemo(() => {
    const m = new Map<string, typeof mine>();
    for (const s of mine) {
      const k = sessionStart(s).toDateString();
      m.set(k, [...(m.get(k) ?? []), s].sort((a, b) => a.time.localeCompare(b.time)));
    }
    return m;
  }, [mine]);
  const [sel, setSel] = useState<string>(new Date(now).toDateString());
  if (!me) return null;
  const selected = byDay.get(sel) ?? [];
  const todayKey = new Date(now).toDateString();
  const tone = { Accepted: "bg-teal-strong text-white", Pending: "bg-[#f7ecd6] text-[#7a520b]", Completed: "bg-[#e3f2e6] text-[#2c6e3a]" } as const;

  return (
    <div>
      <PageHeader title="Calendar" subtitle="Your accepted, pending and completed sessions, plus your weekly availability." action={<Button href="/my-skills" variant="secondary">Edit availability</Button>} />
      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <Card className="p-4 sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <button onClick={() => setOffset(offset - 1)} className="neu-sm rounded-xl p-2" aria-label="Previous month"><ChevronLeft className="h-4 w-4" /></button>
            <h2 className="text-lg font-extrabold text-navy">{month.toLocaleDateString(undefined, { month: "long", year: "numeric" })}</h2>
            <button onClick={() => setOffset(offset + 1)} className="neu-sm rounded-xl p-2" aria-label="Next month"><ChevronRight className="h-4 w-4" /></button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-muted uppercase">{DAYS.map((d) => <div key={d} className="py-1">{d}</div>)}</div>
          <div className="grid grid-cols-7 gap-1">
            {[...Array(startPad)].map((_, i) => <div key={`p${i}`} />)}
            {[...Array(days)].map((_, i) => {
              const date = new Date(month.getFullYear(), month.getMonth(), i + 1);
              const key = date.toDateString();
              const items = byDay.get(key) ?? [];
              return (
                <button key={key} onClick={() => setSel(key)} aria-label={`${date.toDateString()}, ${items.length} sessions`} aria-pressed={sel === key}
                  className={cn("flex min-h-[72px] flex-col items-stretch rounded-xl p-1.5 text-left transition-colors sm:min-h-[92px]", sel === key ? "neu-inset ring-2 ring-teal" : "hover:bg-[#e5e9f2]")}>
                  <span className={cn("mb-1 inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold", key === todayKey ? "bg-navy text-white shadow-[0_0_10px_2px_rgb(246_201_204/.9)]" : "text-ink")}>{i + 1}</span>
                  {items.slice(0, 2).map((s) => <span key={s.id} className={cn("mb-0.5 hidden truncate rounded px-1 py-0.5 text-[0.65rem] font-semibold sm:block", tone[s.status as keyof typeof tone])}>{s.time} {s.skill}</span>)}
                  {items.length > 0 && <span className="mt-auto text-[0.65rem] font-bold text-teal-strong sm:hidden">● {items.length}</span>}
                  {items.length > 2 && <span className="hidden text-[0.65rem] text-subtle sm:block">+{items.length - 2} more</span>}
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex flex-wrap gap-3 text-xs"><span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-teal-strong" />Accepted</span><span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-[#f0c36b]" />Pending</span><span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-[#8fc79b]" />Completed</span></div>
        </Card>
        <div className="space-y-6">
          <Card>
            <h2 className="font-bold text-navy">{new Date(sel).toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })}</h2>
            <ul className="mt-3 space-y-3">
              {selected.map((s) => (
                <li key={s.id}>
                  <Link href={`/sessions/${s.id}`} className="block neu-inset rounded-2xl p-3 hover:bg-[#e3e7f0]">
                    <p className="flex items-center justify-between font-bold text-navy">{s.skill}<Badge tone={s.status === "Accepted" ? "teal" : s.status === "Pending" ? "amber" : "green"}>{s.status}</Badge></p>
                    <p className="text-sm text-subtle">{s.time} · {s.duration} min · {s.mode} {s.format}</p>
                  </Link>
                </li>
              ))}
              {!selected.length && <li className="text-sm text-subtle">No sessions this day.</li>}
            </ul>
          </Card>
          <Card>
            <h2 className="font-bold text-navy">Your weekly availability</h2>
            <ul className="mt-3 space-y-1.5 text-sm">{me.slots.map((s, i) => <li key={i} className="flex justify-between"><span className="font-semibold">{s.day}</span><span className="text-subtle">{s.from}–{s.to}</span></li>)}</ul>
            {!me.slots.length && <p className="mt-2 text-sm text-subtle">Add slots so others know when to book you.</p>}
            <p className="mt-3 text-xs text-subtle">Booking is blocked if it overlaps an accepted session for either person.</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
