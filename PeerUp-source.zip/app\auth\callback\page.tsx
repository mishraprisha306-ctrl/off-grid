"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { auth, isSupabaseConfigured } from "@/lib/auth";

/** Landing point for email verification and Google OAuth redirects. */
export default function Callback() {
  const router = useRouter();
  const [msg, setMsg] = useState("Signing you in…");
  useEffect(() => {
    if (!isSupabaseConfigured) {
      setMsg("This link needs Supabase to be configured.");
      return;
    }
    // supabase-js picks the session out of the URL automatically; then the store maps it to a profile.
    auth.currentUser().then((u) => {
      if (u) window.location.replace("/dashboard");
      else setMsg("This link has expired or was already used. Please sign in.");
    });
  }, [router]);
  return <div className="grid min-h-dvh place-items-center p-6 text-center text-subtle">{msg}</div>;
}
