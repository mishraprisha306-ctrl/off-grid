import Link from "next/link";
import { useId } from "react";

/**
 * PeerUp mark, redrawn as vector from the supplied logo: a "P" whose bowl holds two
 * peers, crossed by a rising ribbon that ends in an arrow, plus a sparkle.
 * Every part has a class so the opening shot can animate it independently.
 */
export function PeerUpMark({ className, animated }: { className?: string; animated?: boolean }) {
  const id = useId().replace(/:/g, "");
  const a = (c: string) => (animated ? c : undefined);
  return (
    <svg viewBox="0 0 200 200" className={className} role="img" aria-label="PeerUp logo">
      <defs>
        <linearGradient id={`p-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#7cc8fb" />
          <stop offset=".55" stopColor="#6a8ff2" />
          <stop offset="1" stopColor="#a585f7" />
        </linearGradient>
        <linearGradient id={`r-${id}`} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#4b8df0" />
          <stop offset="1" stopColor="#8a5cf0" />
        </linearGradient>
      </defs>
      {/* the P */}
      <g className={a("pu-p")}>
        <path d="M34 40a22 22 0 0 1 22-22h52a56 56 0 0 1 0 112H84v42a10 10 0 0 1-10 10H48a14 14 0 0 1-14-14Z" fill={`url(#p-${id})`} />
        <circle cx="104" cy="76" r="36" fill="#fff" />
      </g>
      {/* two peers */}
      <g className={a("pu-peer-a")}>
        <circle cx="92" cy="66" r="11" fill="#4f8ef0" />
        <path d="M70 104c0-14 10-22 22-22s22 8 22 22Z" fill="#4f8ef0" />
      </g>
      <g className={a("pu-peer-b")}>
        <circle cx="118" cy="62" r="12" fill="#a27df6" />
        <path d="M96 104c0-15 10-24 22-24s22 9 22 24Z" fill="#a27df6" opacity=".95" />
      </g>
      {/* rising ribbon + arrow */}
      <path className={a("pu-ribbon")} pathLength={1} d="M58 166C70 128 96 112 124 106s30-12 42-30" fill="none" stroke={`url(#r-${id})`} strokeWidth="13" strokeLinecap="round" />
      <path className={a("pu-arrow")} d="M150 66l28-8-6 29Z" fill="#7a5df1" />
      {/* sparkle */}
      <path className={a("pu-spark")} d="M176 18c1.2 7 3.8 9.6 10.8 10.8-7 1.2-9.6 3.8-10.8 10.8-1.2-7-3.8-9.6-10.8-10.8 7-1.2 9.6-3.8 10.8-10.8Z" fill="#6a7ff2" />
    </svg>
  );
}

/** kept for older imports: renders the PeerUp mark */
export function Figures({ className }: { className?: string; glow?: boolean }) {
  return <PeerUpMark className={className} />;
}

export function LogoMark({ size = 38 }: { size?: number }) {
  return (
    <span className="relative inline-flex shrink-0 items-center justify-center rounded-[30%] bg-white" style={{ width: size, height: size, boxShadow: "0 0 0 1px #eceef5, 0 6px 16px -6px rgb(244 190 196 / .9)" }}>
      <PeerUpMark className="w-[82%]" />
    </span>
  );
}

export function Wordmark({ light, className }: { light?: boolean; className?: string }) {
  return (
    <span className={`font-extrabold tracking-tight ${className ?? ""}`}>
      <span className={light ? "text-white" : "text-navy"}>Peer</span>
      <span className="bg-[linear-gradient(90deg,#4b8df0,#8a5cf0)] bg-clip-text text-transparent">Up</span>
    </span>
  );
}

export function Logo({ href = "/dashboard", compact, light }: { href?: string; compact?: boolean; light?: boolean }) {
  return (
    <Link href={href} className="flex items-center gap-2.5" aria-label="PeerUp home">
      <LogoMark />
      {!compact && (
        <span className="leading-none">
          <Wordmark light={light} className="block text-[1.2rem]" />
          <span className={`block text-[0.64rem] font-semibold tracking-wide ${light ? "text-white/70" : "text-subtle"}`}>Learn Together. Grow Together.</span>
        </span>
      )}
    </Link>
  );
}
