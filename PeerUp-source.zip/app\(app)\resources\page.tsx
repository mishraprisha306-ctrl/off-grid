"use client";
import { BookOpen, ExternalLink, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/components/toast";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, PageHeader, Select, Tabs } from "@/components/ui";
import { useStore } from "@/lib/store";
import type { Resource } from "@/lib/types";

const KINDS: Resource["kind"][] = ["PDF Notes", "Link", "Documentation", "Video Tutorial", "Practice Exercise", "Project Reference"];

export default function Resources() {
  const { db, me, byId, addResource, removeResource } = useStore();
  const toast = useToast();
  const [tab, setTab] = useState<"all" | "mine">("all");
  const [kind, setKind] = useState("");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState<{ title: string; url: string; kind: Resource["kind"]; skill: string; ok: boolean }>({ title: "", url: "", kind: "Link", skill: "", ok: false });
  const [err, setErr] = useState("");
  if (!me) return null;
  const list = db.resources.filter((r) => (tab === "all" || r.ownerId === me.id) && (!kind || r.kind === kind) && (!q || `${r.title} ${r.skill}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <div>
      <PageHeader title="Learning Resources" subtitle="Notes, docs, tutorials and exercises shared by students." action={<Button onClick={() => { setOpen(true); setErr(""); }}><Plus className="h-4 w-4" /> Share a resource</Button>} />
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Tabs value={tab} onChange={setTab} tabs={[{ value: "all", label: "All", count: db.resources.length }, { value: "mine", label: "Mine", count: db.resources.filter((r) => r.ownerId === me.id).length }]} />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by title or skill" className="sm:max-w-xs" aria-label="Search resources" />
        <Select value={kind} onChange={(e) => setKind(e.target.value)} className="sm:max-w-[200px]" aria-label="Type"><option value="">All types</option>{KINDS.map((k) => <option key={k}>{k}</option>)}</Select>
      </div>
      {list.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {list.map((r) => (
            <Card key={r.id} hover className="flex flex-col">
              <div className="flex items-start justify-between gap-2"><Badge tone="teal">{r.kind}</Badge><span className="text-xs text-subtle">{r.skill}</span></div>
              <h3 className="mt-3 font-bold text-navy">{r.title}</h3>
              <p className="mt-1 text-xs text-subtle">Shared by {byId(r.ownerId)?.name ?? "former member"}</p>
              <div className="mt-auto flex gap-2 pt-4">
                <Button size="sm" variant="secondary" href={r.url}><ExternalLink className="h-4 w-4" /> Open</Button>
                {(r.ownerId === me.id || me.role === "admin") && <Button size="sm" variant="ghost" onClick={() => { const x = removeResource(r.id); toast(x.ok ? "Removed." : x.error!, x.ok ? "info" : "error"); }} aria-label="Remove resource"><Trash2 className="h-4 w-4" /></Button>}
              </div>
            </Card>
          ))}
        </div>
      ) : <Card><EmptyState icon={BookOpen} title="No resources here" text="Share a helpful link, set of notes or practice exercise." action={<Button onClick={() => setOpen(true)}>Share one</Button>} /></Card>}
      <Modal open={open} onClose={() => setOpen(false)} title="Share a learning resource">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if (!f.ok) return setErr("Please confirm you have the right to share this."); const r = addResource({ title: f.title, url: f.url, kind: f.kind, skill: f.skill || "General" }); if (!r.ok) return setErr(r.error); toast("Resource shared."); setOpen(false); setF({ title: "", url: "", kind: "Link", skill: "", ok: false }); }}>
          <Field label="Title" htmlFor="r-t"><Input id="r-t" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
          <Field label="Link" htmlFor="r-u" hint="Link to a file you host (Drive, GitHub…) or a public page."><Input id="r-u" placeholder="https://…" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type" htmlFor="r-k"><Select id="r-k" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value as Resource["kind"] })}>{KINDS.map((k) => <option key={k}>{k}</option>)}</Select></Field>
            <Field label="Skill" htmlFor="r-s"><Input id="r-s" value={f.skill} onChange={(e) => setF({ ...f, skill: e.target.value })} placeholder="e.g. Java" /></Field>
          </div>
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#4c3fc8]" checked={f.ok} onChange={(e) => setF({ ...f, ok: e.target.checked })} /> I created this or have permission to share it, and it contains no recording made without consent.</label>
          {err && <p className="text-sm font-semibold text-rose" role="alert">{err}</p>}
          <Button type="submit" className="w-full">Share</Button>
        </form>
      </Modal>
    </div>
  );
}
