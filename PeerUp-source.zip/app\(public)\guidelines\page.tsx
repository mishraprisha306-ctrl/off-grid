import { Legal } from "@/components/legal";
export const metadata = { title: "Community Guidelines" };
export default function Page() {
  return <Legal title="Community Guidelines" subtitle="Be kind, be honest, show up." sections={[
    ["Be respectful", ["No harassment, hate speech, sexual content or bullying.", "Keep messages about learning and scheduling."]],
    ["Be honest", ["Represent your skills and level truthfully. Self-reported skills are labelled; verified credentials are checked by admins.", "No fake reviews, rating swaps or pressuring someone for a rating."]],
    ["Be reliable", ["Show up on time or reschedule early. Reliability counts toward your trust score."]],
    ["Report problems", ["Use Report on profiles, reviews or messages. Reports are confidential and reviewed by moderators."]],
  ]} />;
}
