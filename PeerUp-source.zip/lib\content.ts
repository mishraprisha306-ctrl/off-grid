export const FAQS: [string, string][] = [
  ["What is peer learning?", "Students teaching students. You learn from someone who recently mastered the topic, and you teach what you're good at in return."],
  ["How do I create my profile?", "Sign up with your email, then follow the short onboarding: photo, academic details, interests, skills you teach and want to learn, and when you're free. Optional steps can be skipped and edited later."],
  ["How do I add skills?", "Open My Skills. For each teaching skill you choose your own level (Beginner, Intermediate or Advanced), whatever your year, plus a description, preferred mode and optional portfolio link."],
  ["How does mutual matching work?", "You're a mutual match when you can teach at least one skill the other student wants AND they can teach at least one skill you want. Skill names are normalised (e.g. “UI/UX” = “UI/UX Design”). The match % averages how much of each wish list is covered. One-way matches are listed separately."],
  ["Can juniors learn from seniors?", "Yes. Senior Mentors offer academic, project and career guidance. You can also request mentorship from any eligible mentor."],
  ["How are ratings calculated?", "Only learners in a completed session can rate the teacher, once per session, never themselves. Average = sum of eligible star ratings ÷ number of eligible ratings. Skill-wise averages use only that skill's sessions and need at least 2 reviews to be shown."],
  ["What is a trust score?", "A 0–100 score: ratings (up to 50), completed teaching sessions (up to 20), consistency of positive feedback (up to 15) and reliability (up to 15). New members are shown as “building trust” rather than given a low number. Academic year never affects it."],
  ["How can I become a Senior Mentor?", "Meet the published criteria: seniority (or proven Advanced experience), enough completed teaching sessions, a strong average from enough reviews, and no unresolved conduct reports. You can also request an admin review from your profile."],
  ["Are sessions free?", "Yes. PeerUp is an exchange of knowledge, not money."],
  ["Is my information private?", "You choose what's public: email, college, student ID, links and who can message you. See Settings → Privacy."],
];
