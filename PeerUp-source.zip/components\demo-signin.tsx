"use client";
import { ShieldCheck, Users } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { yearLabel } from "@/lib/engines";
import { ADMIN_EMAIL, DEMO_ACCOUNTS, DEMO_PASSWORD, TEAM_ACCOUNTS } from "@/lib/seed";
import { useStore } from "@/lib/store";
import type { Student } from "@/lib/types";
import { useToast } from "./toast";
import { Avatar, cn } from "./ui";

/**
 * One-tap sign-in for the mockup (no backend yet). Signs in through the same
 * local auth as the form, so every page behaves exactly as for a real account.
 */
export function DemoSignIn({ title = "Sign in as", className }: { title?: string; className?: string }) {
  const { db, login, ready, supabase } = useStore();
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState("");
  if (supabase) return null; // real auth is configured: no shortcuts
  const pick = (ids: string[]) => ids.map((id) => db.students.find((s) => s.id === id)).filter((s): s is Student => !!s);
  const team = pick(TEAM_ACCOUNTS);
  const others = pick(DEMO_ACCOUNTS);

  const go = async (email: string, id: string, name: string) => {
    setBusy(id);
    const r = await login(email, DEMO_PASSWORD);
    setBusy("");
    if (!r.ok) return toast(r.error, "error");
    toast(`Signed in as ${name}.`);
    router.replace(id === "u-admin" ? "/admin" : "/dashboard");
  };

  return (
    <section className={cn("neu p-5", className)} aria-labelledby="demo-h">
      <h2 id="demo-h" className="flex items-center gap-2 font-bold text-navy"><Users className="h-4 w-4 text-teal-strong" /> {title}</h2>
      <p className="mt-1 text-sm text-subtle">One tap, no details needed. These are demo accounts until real login is connected.</p>

      <p className="mt-4 mb-2 text-xs font-bold text-subtle">PeerUp team</p>
      <ul className="space-y-2.5">
        {team.map((s) => (
          <li key={s.id}>
            <button onClick={() => go(s.email, s.id, s.name)} disabled={!ready || !!busy}
              className="neu-sm flex w-full items-center gap-3 p-3 text-left transition-shadow hover:shadow-[var(--shadow-glow)] active:shadow-[var(--shadow-pressed)] disabled:opacity-60">
              <Avatar name={s.name} src={s.avatar} size={42} className="ring-2" />
              <span className="min-w-0 flex-1 leading-tight">
                <span className="block truncate font-bold text-navy">{s.name}</span>
                <span className="block truncate text-xs text-subtle">Roll {s.studentId} · {s.department}</span>
              </span>
              <span className="shrink-0 rounded-lg bg-teal-strong px-3 py-1.5 text-xs font-bold text-white">{busy === s.id ? "Signing in…" : "Sign in"}</span>
            </button>
          </li>
        ))}
      </ul>

      <details className="mt-4 group">
        <summary className="cursor-pointer text-sm font-semibold text-teal-strong">More demo students</summary>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          {others.map((s) => (
            <li key={s.id}>
              <button onClick={() => go(s.email, s.id, s.name)} disabled={!ready || !!busy} className="neu-sm flex w-full items-center gap-2.5 p-2.5 text-left hover:shadow-[var(--shadow-glow)] disabled:opacity-60">
                <Avatar name={s.name} src={s.avatar} size={32} className="ring-2" />
                <span className="min-w-0 leading-tight"><span className="block truncate text-sm font-bold text-ink" title={s.name}>{s.name.split(" ")[0]}</span><span className="block truncate text-xs text-subtle">{s.department} · {yearLabel(s.year)}</span></span>
              </button>
            </li>
          ))}
        </ul>
        <button onClick={() => go(ADMIN_EMAIL, "u-admin", "Platform admin")} disabled={!ready || !!busy} className="mt-3 flex items-center gap-2 text-sm text-subtle hover:text-navy">
          <ShieldCheck className="h-4 w-4" /> Sign in as platform admin
        </button>
      </details>
    </section>
  );
}
