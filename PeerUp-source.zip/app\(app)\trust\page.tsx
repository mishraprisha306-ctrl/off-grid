"use client";
import { CheckCircle2, CircleDashed, ShieldCheck } from "lucide-react";
import { useStats } from "@/components/domain";
import { Card, PageHeader, Ring } from "@/components/ui";
import { TRUST_RULES } from "@/lib/engines";
import { useStore } from "@/lib/store";

export default function Trust() {
  const { me } = useStore();
  const { trust: t } = useStats(me!.id);
  const rows = [
    { l: "Average rating", v: t.ratingPts, max: 50, how: `avg ÷ 5 × 50, weighted by evidence until ${TRUST_RULES.minReviews} reviews`, now: t.average === null ? "No ratings yet (counted as 0, never as 5★)" : `${t.average.toFixed(2)}★ from ${t.reviewCount} review${t.reviewCount === 1 ? "" : "s"}` },
    { l: "Completed sessions", v: t.sessionPts, max: 20, how: `20 × ln(1 + n) ÷ ln(${TRUST_RULES.sessionCap + 1}), full at ${TRUST_RULES.sessionCap} sessions`, now: `${t.completedTeaching} completed teaching session${t.completedTeaching === 1 ? "" : "s"}` },
    { l: "Consistency", v: t.consistencyPts, max: 15, how: `share of reviews rated ${TRUST_RULES.consistencyMin}★+ × 15, after ${TRUST_RULES.minReviews} reviews`, now: t.reviewCount >= TRUST_RULES.minReviews ? "Based on your reviews" : `Unlocks at ${TRUST_RULES.minReviews} reviews` },
    { l: "Reliability", v: t.reliabilityPts, max: 15, how: `completed ÷ (completed + cancelled after accepting) × 15, after ${TRUST_RULES.minCommitted}`, now: t.committed ? `${t.completedTeaching} of ${t.committed} commitments delivered` : "No accepted sessions yet" },
  ];
  return (
    <div className="max-w-4xl">
      <PageHeader title="Trust Score" subtitle="A transparent score from your real teaching activity. Recalculated every time a session or rating changes." />
      <Card className="flex flex-col items-center gap-6 sm:flex-row">
        {t.established ? <Ring value={t.total} size={120} stroke={10} label={`Trust score ${t.total}`} /> : <span className="flex h-[120px] w-[120px] flex-col items-center justify-center rounded-full bg-blush-soft text-center shadow-[0_0_40px_6px_rgb(246_201_204/.6)]"><span className="text-lg font-extrabold text-blush-ink">New</span><span className="text-xs text-blush-ink">{t.total} pts so far</span></span>}
        <div>
          <p className="text-xl font-extrabold text-navy">{t.established ? `${t.total} / 100` : "Building trust"}</p>
          <p className="mt-1 text-subtle">{t.established ? "Your score is established and shown on your profile and the leaderboard." : `New members aren't shown a low number. Your score is shown once you have ${TRUST_RULES.minReviews} completed teaching sessions and ${TRUST_RULES.minReviews} reviews; until then you appear as “New · building trust”.`}</p>
          <p className="mt-2 text-sm text-subtle">Academic year and the Senior Mentor badge never affect this score.</p>
        </div>
      </Card>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {rows.map((r) => (
          <Card key={r.l}>
            <div className="flex items-center justify-between"><h2 className="font-bold text-navy">{r.l}</h2><span className="text-lg font-extrabold text-navy">{r.v.toFixed(1)}<span className="text-sm text-subtle"> / {r.max}</span></span></div>
            <div className="neu-inset mt-3 h-2.5 overflow-hidden rounded-full"><div className="h-full rounded-full bg-teal" style={{ width: `${(r.v / r.max) * 100}%` }} /></div>
            <p className="mt-3 text-sm text-ink">{r.now}</p>
            <p className="mt-1 text-xs text-subtle">Formula: {r.how}</p>
          </Card>
        ))}
      </div>
      <Card className="mt-6">
        <h2 className="flex items-center gap-2 font-bold text-navy"><ShieldCheck className="h-5 w-5 text-teal-strong" /> What protects the score</h2>
        <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
          {["Only completed sessions count; rejected and cancelled ones never do.", "Completion needs both teacher and learner to confirm.", "Ratings come only from learners in that session, once each.", "You can never rate yourself.", "Missing ratings count as zero, not five stars.", "Moderators can remove fraudulent reviews."].map((x) => <li key={x} className="flex gap-2"><CheckCircle2 className="h-4 w-4 shrink-0 text-teal-strong" />{x}</li>)}
          {!t.verified && <li className="flex gap-2 text-subtle"><CircleDashed className="h-4 w-4 shrink-0" />You'll appear on the leaderboard after your first rated session.</li>}
        </ul>
      </Card>
    </div>
  );
}
